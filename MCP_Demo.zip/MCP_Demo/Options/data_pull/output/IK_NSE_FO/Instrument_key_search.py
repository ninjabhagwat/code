import json
import pandas as pd

# Path to your NSE.json file
NSE_JSON = r"C:\Niranjan\Personal\Stock_Price_pridiction\NSE.json"

# Load NSE.json
print("📂 Loading NSE.json ...")
with open(NSE_JSON, 'r') as f:
    data = json.load(f)

print(f"✅ Total instruments loaded: {len(data)}")

# Define the target indices (case-insensitive)
target_indices = ["NIFTY 50", "BANKNIFTY", "FINNIFTY", "MIDCPNIFTY"]

# Filter the data
filtered = []
for item in data:
    seg = item.get("segment", "")
    symbol = (item.get("trading_symbol") or "").upper().strip()
    if seg == "NSE_INDEX" and symbol in target_indices:
        filtered.append({
            "Symbol": item.get("trading_symbol"),
            "Segment": item.get("segment"),
            "Instrument Key": item.get("instrument_key")
        })

# Display the result
print("\n🎯 Found Indices:")
for entry in filtered:
    print(entry)

# Save to CSV (optional)
if filtered:
    output_file = r"C:\Niranjan\Personal\MCP_Demo\Options\data_pull\output\IK_NSE_FO\extracted_instrument_keys_nse_FO_filtered.csv"
    pd.DataFrame(filtered).to_csv(output_file, index=False)
    print(f"\n💾 Saved filtered indices to: {output_file}")
else:
    print("\n⚠️ No matching indices found in NSE.json")