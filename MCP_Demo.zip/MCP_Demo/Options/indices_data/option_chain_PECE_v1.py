import requests
import json
import pandas as pd
from datetime import datetime, timedelta
import time
import os

# ================= CONFIG ==================
ACCESS_TOKEN = input("eyJ0eXAiOiJKV1QiLCJrZXlfaWQiOiJza192MS4wIiwiYWxnIjoiSFMyNTYifQ.eyJzdWIiOiI0MkJOVUMiLCJqdGkiOiI2OGUzNTc4ZWNlOWM3OTZhZmM4YzQ4MzciLCJpc011bHRpQ2xpZW50IjpmYWxzZSwiaXNQbHVzUGxhbiI6ZmFsc2UsImlhdCI6MTc1OTcyOTU1MCwiaXNzIjoidWRhcGktZ2F0ZXdheS1zZXJ2aWNlIiwiZXhwIjoxNzU5Nzg4MDAwfQ.FMx7rEIjneyXMj7HMYpC9JY-3gKtGU0-jWNtVnn8RRE").strip()
INDICES = ["NIFTY", "BANKNIFTY", "FINNIFTY", "MIDCPNIFTY"]
START_DATE_STR = input("Enter start date (YYYY-MM-DD): ").strip()
if not START_DATE_STR:
    START_DATE_STR = datetime.now().strftime("%Y-%m-%d")

START_DATE = datetime.strptime(START_DATE_STR, "%Y-%m-%d")
TODAY = datetime.now()
FUTURE_DAYS = 15  # include nearby upcoming expiries
END_DATE = TODAY + timedelta(days=FUTURE_DAYS)

NSE_JSON = r"C:\Niranjan\Personal\Stock_Price_pridiction\NSE.json"
OUT_DIR = r"C:\Niranjan\Personal\MCP_Demo\Options\option_chain_indices"
os.makedirs(OUT_DIR, exist_ok=True)

RATE_LIMIT_DELAY = 0.4  # seconds between API calls
# ===========================================

# Load NSE.json
with open(NSE_JSON, "r") as f:
    all_data = json.load(f)

df_all = pd.DataFrame(all_data)

# Helper to batch API calls
def batch(iterable, size=100):
    for i in range(0, len(iterable), size):
        yield iterable[i:i+size]

# Loop through each index
for idx_name in INDICES:
    print(f"\n🔍 Processing {idx_name}...")

    # Filter options for this index
    df_opts = df_all[
        (df_all["segment"] == "NSE_FO") &
        (df_all["instrument_type"].isin(["OPTIDX", "OPTSTK"])) &
        (df_all["name"].str.contains(idx_name, case=False, na=False))
    ].copy()

    if df_opts.empty:
        print(f"⚠️ No options found for {idx_name}, skipping...")
        continue

    df_opts["expiry_dt"] = pd.to_datetime(df_opts["expiry"], errors="coerce")
    df_range = df_opts[
        (df_opts["expiry_dt"] >= START_DATE) & (df_opts["expiry_dt"] <= END_DATE)
    ].copy()

    if df_range.empty:
        print(f"⚠️ No expiries found for {idx_name} between {START_DATE.date()} → {END_DATE.date()}")
        continue

    expiries = sorted(df_range["expiry_dt"].dropna().unique())
    print(f"✅ Found {len(expiries)} expiries for {idx_name}")

    all_records = []

    # Fetch quotes for all expiries
    for exp in expiries:
        exp_str = exp.strftime("%Y-%m-%d")
        df_exp = df_range[df_range["expiry_dt"] == exp].copy()
        instrument_keys = df_exp["instrument_key"].tolist()
        symbol_map = dict(zip(df_exp["instrument_key"], df_exp["trading_symbol"]))
        print(f"  📆 Fetching expiry {exp_str} ({len(instrument_keys)} contracts)...")

        for chunk in batch(instrument_keys, 100):
            url = "https://api.upstox.com/v3/market-quote/quotes"
            params = {"instrument_key": ",".join(chunk)}
            headers = {"Accept": "application/json", "Authorization": f"Bearer {ACCESS_TOKEN}"}

            try:
                r = requests.get(url, headers=headers, params=params)
                if r.status_code != 200:
                    print(f"  ⚠️ Error {r.status_code}: {r.text}")
                    time.sleep(RATE_LIMIT_DELAY)
                    continue
                data = r.json().get("data", {})
            except Exception as e:
                print(f"  ⚠️ Exception: {e}")
                time.sleep(RATE_LIMIT_DELAY)
                continue

            for ik, d in data.items():
                q = d.get("quote", {})
                oi_data = q.get("oi", {})
                market = q.get("market", {})
                all_records.append({
                    "trading_symbol": symbol_map.get(ik),
                    "instrument_key": ik,
                    "expiry": exp_str,
                    "strike": d.get("strike_price"),
                    "option_type": d.get("option_type"),
                    "ltp": q.get("last_price"),
                    "bid": market.get("bid", {}).get("price"),
                    "ask": market.get("ask", {}).get("price"),
                    "volume": q.get("volume"),
                    "open_interest": oi_data.get("open_interest"),
                    "change_in_oi": oi_data.get("change_in_oi"),
                    "timestamp": q.get("timestamp")
                })
            time.sleep(RATE_LIMIT_DELAY)

    if all_records:
        df_out = pd.DataFrame(all_records)
        df_out = df_out.sort_values(by=["expiry", "strike", "option_type"])
        out_file = os.path.join(OUT_DIR, f"option_chain_{idx_name}.csv")
        df_out.to_csv(out_file, index=False)
        print(f"📁 Saved {len(df_out)} rows → {out_file}")
    else:
        print(f"⚠️ No data fetched for {idx_name}")

print("\n✅ All indices processed successfully.")
