import argparse
import math
from pathlib import Path
import pandas as pd
import numpy as np

# Default paths you provided
INTRADAY_15M = r"C:\Niranjan\Personal\Stock_Price_pridiction\intraday_15min_latest.csv"
DAILY_SWING = r"C:\Niranjan\Personal\MCP_Demo\upstox-mcp-server\historical_candles_latest.csv"
DEFAULT_OUT = r"C:\Niranjan\Personal\MCP_Demo\upstox-mcp-server\AI_Py_Impl\output\actionable_signals_best.csv"

def validate_df(df):
    expected = {"datetime", "open", "high", "low", "close", "volume", "trading_symbol"}
    missing = expected - set(c.lower() for c in df.columns)
    if missing:
        raise ValueError(f"Missing columns: {missing}")
    return df

def compute_atr(df, period=14):
    high = df["high"].astype(float)
    low = df["low"].astype(float)
    close = df["close"].astype(float)
    prev_close = close.shift(1)
    tr = pd.concat([high - low, (high - prev_close).abs(), (low - prev_close).abs()], axis=1).max(axis=1)
    atr = tr.rolling(period, min_periods=1).mean()
    return atr

def score_stock(df, interval="15m"):
    # expects df sorted ascending by datetime
    close = df["close"].astype(float)
    high = df["high"].astype(float)
    low = df["low"].astype(float)
    vol = df["volume"].astype(float).replace(0, np.nan).fillna(0)
    returns = close.pct_change().fillna(0)

    atr = compute_atr(df, period=14).iloc[-1]
    vol_mean20 = vol.rolling(20, min_periods=1).mean().iloc[-1] + 1e-9
    vol_surge = vol.iloc[-1] / vol_mean20

    ema_short = close.ewm(span=8, adjust=False).mean().iloc[-1]
    ema_long = close.ewm(span=34, adjust=False).mean().iloc[-1]
    ema_score = 1.0 if ema_short > ema_long else 0.0

    momentum = returns.tail(3).sum()  # short momentum
    price = close.iloc[-1] if len(close) else 0.0
    # normalized contributions
    vol_contrib = min(vol_surge, 3) / 3.0  # 0..1
    atr_contrib = (atr / (price + 1e-9)) * 10.0  # rough % -> scaled
    atr_contrib = max(0.0, min(atr_contrib, 3.0)) / 3.0
    momentum_contrib = (momentum * 100.0 + 5.0) / 10.0  # rough map -> may be negative/positive
    momentum_contrib = max(0.0, min(momentum_contrib, 1.0))
    ema_contrib = ema_score

    # weights tuned for intraday-ish behavior; you can change via args later
    w_vol, w_atr, w_mom, w_ema = 0.35, 0.30, 0.25, 0.10
    score = 100.0 * (w_vol * vol_contrib + w_atr * atr_contrib + w_mom * momentum_contrib + w_ema * ema_contrib)
    return float(score), {
        "vol_surge": float(vol_surge),
        "atr": float(atr),
        "ema_short": float(ema_short),
        "ema_long": float(ema_long),
        "momentum": float(momentum),
        "price": float(price),
    }

def build_signal_row(sym, side, entry, stop, take, score, confidence, signal_time):
    return {
        "trading_symbol": sym,
        "side": side,
        "entry": entry,
        "stop_loss": stop,
        "take_profit": take,
        "position_size": "",      # leave blank; position sizing calculated later with exact lot rules
        "risk_perc": "",          # leave blank (you have fixed risk INR = 500)
        "signal_time": signal_time,
        "confidence": round(confidence, 2),
        "_selected_score": round(score, 4),
    }

def run_scan(input_path, mode="intraday", top_n=20, min_candles_intraday=500, min_candles_daily=60, out_path=DEFAULT_OUT):
    df = pd.read_csv(input_path)
    df.columns = [c.strip() for c in df.columns]
    df = validate_df(df)
    df["datetime"] = pd.to_datetime(df["datetime"])
    df = df.sort_values(["trading_symbol", "datetime"])
    results = []
    grouped = df.groupby("trading_symbol")
    min_candles = min_candles_intraday if mode in ("intraday", "15m") else min_candles_daily

    for sym, g in grouped:
        if len(g) < min_candles:
            continue
        # keep last N rows for feature stability
        last = g.tail(500 if mode in ("intraday", "15m") else 250).reset_index(drop=True)
        try:
            score, meta = score_stock(last, interval=mode)
        except Exception:
            continue
        if math.isnan(score):
            continue
        # decide side and compute stop/tp heuristics
        price = meta["price"]
        atr = meta["atr"] if meta["atr"] > 0 else max(0.001, price * 0.002)
        side = "BUY" if meta["ema_short"] > meta["ema_long"] else "SELL"
        if side == "BUY":
            entry = price
            stop = max(0.0, price - atr * 1.0)
            take = price + atr * 2.0
        else:
            entry = price
            stop = min(1e12, price + atr * 1.0)
            take = price - atr * 2.0
        confidence = min(1.0, score / 100.0 + 0.05)  # small floor bump
        signal_time = last["datetime"].iloc[-1].isoformat()
        results.append((sym, score, confidence, side, entry, stop, take, signal_time, meta))

    if not results:
        print("No symbols passed filters (insufficient history or data).")
        return

    # rank & select
    df_out = pd.DataFrame([build_signal_row(r[0], r[3], r[4], r[5], r[6], r[1], r[2], r[7]) for r in results])
    df_out = df_out.sort_values(by="_selected_score", ascending=False).head(top_n)

    # ensure out dir exists
    out_p = Path(out_path)
    out_p.parent.mkdir(parents=True, exist_ok=True)
    df_out.to_csv(out_path, index=False)
    print(f"Wrote top {len(df_out)} signals to {out_path}")

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--mode", choices=["intraday", "15m", "daily", "swing"], default="intraday")
    p.add_argument("--input", default=INTRADAY_15M, help="input CSV path")
    p.add_argument("--top", type=int, default=20)
    p.add_argument("--out", default=DEFAULT_OUT)
    p.add_argument("--min_candles_intraday", type=int, default=500)
    p.add_argument("--min_candles_daily", type=int, default=60)
    args = p.parse_args()
    run_scan(args.input, mode=args.mode, top_n=args.top,
             min_candles_intraday=args.min_candles_intraday,
             min_candles_daily=args.min_candles_daily,
             out_path=args.out)

if __name__ == "__main__":
    main()