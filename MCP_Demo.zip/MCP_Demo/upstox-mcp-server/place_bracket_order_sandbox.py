"""
examples/place_bracket_order_sandbox.py

Sandbox-first helper that:
- Reads the latest signal for a symbol from elliott-wave-indicator/examples/outputs/signals.csv
- Resolves the instrument_key (tries common instruments endpoints; you may need to adapt to exact Upstox API)
- Prepares a bracket-style order payload (main order + stoploss/takeprofit fields) according to common Upstox patterns
- Prints the payload and optionally submits to the sandbox place-order endpoint (dry-run by default)

Safety: default is dry-run. Test and inspect payload before executing live trades.
"""

import os
import json
import argparse
from typing import Optional
import requests
import pandas as pd
from math import ceil

from dotenv import load_dotenv
load_dotenv()

print(os.getenv("UPSTOX_ACCESS_TOKEN"))

# Defaults and environment-driven config
BASE_URL = os.getenv("UPSTOX_BASE_URL", "https://sandbox-api.upstox.com")
# support common env names and sandbox-specific names the user supplied
TOKEN = os.getenv("UPSTOX_ACCESS_TOKEN") 
# or os.getenv("SANDBOX_APP_ACCESS_TOKEN")
CLIENT_ID = os.getenv("UPSTOX_CLIENT_ID") or os.getenv("SANDBOX_APP_API_KEY") or os.getenv("SANDBOX_APP_API_KEY")
CLIENT_SECRET = os.getenv("UPSTOX_CLIENT_SECRET") or os.getenv("SANDBOX_APP_API_SECRET")
# DEFAULT_SIGNALS = os.path.join(os.path.dirname(__file__), '..', 'elliott-wave-indicator', 'examples', 'outputs', 'actionable_signals_generated_best.csv')
DEFAULT_SIGNALS=r'C:\Niranjan\Personal\MCP_Demo\upstox-mcp-server\elliott-wave-indicator\examples\outputs\actionable_signals_generated_best.csv'
SANDBOX_APP_ACCESS_TOKEN = os.getenv("SANDBOX_APP_ACCESS_TOKEN")
LIVE_URL = os.getenv("LIVE_URL") or os.getenv("UPSTOX_LIVE_URL")

# Build headers at runtime so TOKEN can be updated or masked
def build_headers(token: Optional[str]):
    h = {
        "Content-Type": "application/json",
        "Accept": "application/json",
    }
    if token:
        h["Authorization"] = f"Bearer {token}"
    return h

HEADERS = build_headers(TOKEN)


def load_latest_signal(signals_csv: str, symbol: Optional[str] = None) -> Optional[dict]:
    if not os.path.exists(signals_csv):
        print("signals.csv not found:", signals_csv)
        return None
    # Read permissively (avoid forcing first column to be datetime)
    try:
        df = pd.read_csv(signals_csv, dtype=str)
    except Exception as e:
        print(f"Failed to read signals CSV {signals_csv}: {e}")
        return None

    if df.empty:
        print("Signals CSV is empty")
        return None

    # Normalize column names to lower-case mapping for lookup
    col_map = {c.lower(): c for c in df.columns}

    # If symbol provided, filter first to narrow down selection
    if symbol:
        if 'trading_symbol' in col_map:
            df = df[df[col_map['trading_symbol']].astype(str).str.strip().str.lower() == str(symbol).strip().lower()]
        elif 'symbol' in col_map:
            df = df[df[col_map['symbol']].astype(str).str.strip().str.lower() == str(symbol).strip().lower()]
        else:
            # try any column that contains 'symbol' as fallback
            sym_cols = [c for c in df.columns if 'symbol' in c.lower()]
            if sym_cols:
                df = df[df[sym_cols[0]].astype(str).str.strip().str.lower() == str(symbol).strip().lower()]

    if df.empty:
        print("No matching signals in", signals_csv)
        return None

    # Detect a datetime-like column to sort by (prefer signal_time, signal_time_ist, datetime)
    datetime_candidates = [c for c in df.columns if 'signal' in c.lower() and 'time' in c.lower()]
    if not datetime_candidates:
        # fallback to common names
        for name in ('signal_time', 'signal_time_ist', 'datetime', 'timestamp'):
            if name in col_map:
                datetime_candidates.append(col_map[name])
    dt_col = datetime_candidates[0] if datetime_candidates else None

    if dt_col and dt_col in df.columns:
        # parse datetimes permissively
        try:
            parsed = pd.to_datetime(df[dt_col], errors='coerce', utc=True)
            df['_parsed_signal_time'] = parsed
            # drop rows that couldn't parse if most rows parse
            if df['_parsed_signal_time'].isna().all():
                # if parsing failed for all, remove the parsed column
                df = df.drop(columns=['_parsed_signal_time'], errors='ignore')
            else:
                # sort by parsed time descending and pick the latest
                df = df.sort_values(by='_parsed_signal_time')
                row = df.iloc[-1].to_dict()
        except Exception:
            # fallback: just take last row
            row = df.iloc[-1].to_dict()
    else:
        # no datetime column - fallback to last row in file
        row = df.iloc[-1].to_dict()

    # normalize keys and coerce numeric fields where appropriate
    signal = {
        'symbol': symbol or (row.get('trading_symbol') or row.get('symbol')),
        'side': (row.get('side') or row.get('entry_type') or 'BUY').upper(),
        'entry': float(row.get('entry')) if row.get('entry') not in (None, '') else None,
        'sl': float(row.get('stop_loss') or row.get('stoploss') or row.get('stop') or 0) if (row.get('stop_loss') or row.get('stoploss') or row.get('stop')) not in (None, '') else None,
        'tp': float(row.get('take_profit') or row.get('takeprofit') or row.get('tp') or 0) if (row.get('take_profit') or row.get('takeprofit') or row.get('tp')) not in (None, '') else None,
        'position_size': row.get('position_size') or row.get('position_size_int') or row.get('position_size_int'),
        'risk_perc': row.get('risk_perc') or row.get('risk') or row.get('risk_pct') or None,
        'raw_row': row,
    }
    return signal

CSV_PATH = r"C:\Niranjan\Personal\Stock_Price_pridiction\extracted_instrument_keys_nse_eq_filtered.csv"

def resolve_instrument_key(symbol: str) -> Optional[str]:
    """
    Resolve trading_symbol -> instrument_key using local CSV.
    Returns the instrument_key as a string, or None if not found.
    """
    if not os.path.exists(CSV_PATH):
        print(f"❌ CSV file not found: {CSV_PATH}")
        return None

    try:
        df = pd.read_csv(CSV_PATH, dtype=str)  # read as string to preserve format
        row = df[df['trading_symbol'].str.strip().str.upper() == symbol.strip().upper()]
        if not row.empty:
            key = row.iloc[0]['instrument_key']
            print(f"✅ Found {symbol}: {key}")
            return key
        else:
            print(f"⚠️ Symbol '{symbol}' not found in CSV")
            return None
    except Exception as e:
        print(f"❌ Error reading CSV: {e}")
        return None



def resolve_from_csv(symbol: str, segment: str = "NSE_EQ") -> Optional[str]:
    """Try to resolve from local or online instruments.csv."""
    csv_url = "https://assets.upstox.com/market-quote/instruments/exchange/NSE/instruments.csv"
    local_path = r"C:\Niranjan\Upstox_Data\instruments.csv"

    try:
        try:
            print("🌐 Fetching instruments from Upstox URL...")
            csv_text = requests.get(csv_url, timeout=10, proxies={'http': None, 'https': None}).text
            df = pd.read_csv(StringIO(csv_text))
        except Exception as e:
            print(f"⚠️ Online fetch failed ({e}). Trying local CSV...")
            df = pd.read_csv(local_path)

        row = df[(df['trading_symbol'] == symbol) & (df['segment'] == segment)]
        if not row.empty:
            key = row.iloc[0]['instrument_key']
            print(f"✅ Found in CSV: {symbol} → {key}")
            return key
        else:
            print(f"⚠️ Symbol '{symbol}' not found in CSV (segment={segment}).")
            return None
    except Exception as e:
        print(f"❌ Error reading CSV fallback: {e}")
        return None


# def resolve_instrument_key(symbol: str) -> Optional[str]:
#     """Try to resolve symbol -> instrument key using Upstox instruments endpoints.
#     This attempts a few common endpoints. You may need to adapt to the exact API path in Upstox docs.
#     Returns instrument_key or None.
#     """
#     if not TOKEN:
#         print("No UPSTOX_ACCESS_TOKEN in env; cannot call instruments endpoint. Returning None.")
#         return None

#     candidates = [
#         ("/v2/instruments/search", {"query": symbol}),
#         ("/instruments", {"search": symbol}),
#         ("/v2/instruments", {"symbol": symbol}),
#     ]
#     for endpoint, params in candidates:
#         url = BASE_URL.rstrip('/') + endpoint
#         try:
#             resp = requests.get(url, headers=build_headers(TOKEN), params=params, timeout=10)
#             if resp.status_code == 200:
#                 data = resp.json()
#                 # heuristics: look for keys like instrument_key, instrument_token, key, token
#                 if isinstance(data, dict) and 'data' in data:
#                     items = data['data']
#                 elif isinstance(data, list):
#                     items = data
#                 elif isinstance(data, dict):
#                     items = [data]
#                 else:
#                     items = []
#                 if not items:
#                     continue
#                 # pick first matching item that contains an instrument key/token
#                 for it in items:
#                     for k in ('instrument_key', 'instrumentToken', 'instrument_token', 'token', 'key'):
#                         if k in it and it[k]:
#                             print(f"Resolved instrument key via {endpoint} using field {k}")
#                             return str(it[k])
#                     # sometimes object nests instrument details under 'instrument'
#                     if 'instrument' in it and isinstance(it['instrument'], dict):
#                         inst = it['instrument']
#                         for k in ('instrument_key', 'instrumentToken', 'instrument_token', 'token', 'key'):
#                             if k in inst and inst[k]:
#                                 print(f"Resolved instrument key via {endpoint} nested instrument.{k}")
#                                 return str(inst[k])
#             else:
#                 # non-200 - skip quietly for resilience
#                 print(f"Error calling {endpoint}: {resp.status_code} {resp.text}; skipping")
#                 continue
#         except Exception as e:
#             print(f"Error calling {endpoint}: {e}; skipping")
#             # network/timeout errors - continue trying others
#             continue
#     print("Unable to resolve instrument key from Upstox API. Provide instrument_key manually if needed.")
#     return None


def compute_qty_from_signal(account_size: float, signal: dict) -> int:
    entry = signal.get('entry')
    sl = signal.get('sl')
    ps = signal.get('position_size')
    # prefer explicit numeric position_size if >=1 -> treat as qty
    if ps not in (None, ''):
        try:
            psv = float(ps)
            if psv >= 1:
                qty = int(round(psv))
                print(f"Using position_size from signal as qty: {qty}")
                return qty
            # otherwise treat as cash allocation
            if entry and entry > 0:
                qty = int(psv // entry)
                print(f"Using position_size from signal as cash allocation -> qty {qty}")
                return max(qty, 0)
        except Exception:
            pass
    # fallback to risk percent (from signal or default 1%)
    risk = None
    try:
        if signal.get('risk_perc') not in (None, ''):
            risk = float(signal.get('risk_perc'))
    except Exception:
        risk = None
    if risk is None:
        risk = 1.0
    if entry is None or sl is None:
        print("Missing entry or stoploss for risk-based sizing -> returning 0")
        return 0
    risk_amount = account_size * (risk / 100.0)
    per_unit_risk = abs(entry - sl)
    if per_unit_risk <= 0:
        return 0
    qty = int(risk_amount // per_unit_risk)
    max_by_cash = int(account_size // entry) if entry and entry > 0 else 0
    qty = max(0, min(qty, max_by_cash))
    print(f"Risk-based sizing -> qty {qty} (risk {risk}%)")
    return qty


def _round_up_to_tick(value: Optional[float], tick: float = 0.05) -> Optional[float]:
    """Round value up to the nearest `tick` (e.g. 0.05). Returns None if input is None."""
    if value is None:
        return None
    try:
        mult = int(1.0 / tick)
    except Exception:
        mult = round(1.0 / tick)
    try:
        return float(ceil(float(value) * mult) / mult)
    except Exception:
        return float(value)


def build_bracket_payload(instrument_key: str, signal: dict, qty: int, product: str = 'NRML') -> dict:
    # Map internal product to Upstox product codes: 'D' = Delivery, 'I' = Intraday
    product_map = {'NRML': 'I', 'CNC': 'D', 'MIS': 'I'}
    prod_code = product_map.get(product, product)

    txn_type = 'BUY' if signal.get('side', 'BUY').upper().startswith('B') else 'SELL'

    # ensure entry/trigger prices conform to tick size
    entry_price = _round_up_to_tick(signal.get('entry'))
    trigger_price = _round_up_to_tick(signal.get('sl'))

    # Build payload matching requested format
    payload = {
        'instrument_token': instrument_key,
        'quantity': int(qty),
        'price': entry_price,
        'order_type': 'LIMIT',
        'product': prod_code,
        'transaction_type': txn_type,
        'validity': 'DAY',
        'trigger_price': trigger_price,
        'tag': 'elliott-scanner-bracket',
        'is_amo': False,
        'slice': False,
    }
    # Remove keys with None values to keep payload compact
    payload = {k: v for k, v in payload.items() if v is not None}
    return payload


def build_gtt_payload(instrument_key: str, signal: dict, qty: int, product: str = 'NRML') -> dict:
    """Build a GTT MULTIPLE payload using entry/stoploss/target from the signal.
    Matches the sample format:
    {
      "type": "MULTIPLE",
      "quantity": 28,
      "product": "D",
      "instrument_token": "NSE_EQ|INE095A01012",
      "transaction_type": "BUY",
      "rules": [ ... ],
      "tag": "elliott-scanner-bracket"
    }
    """
    product_map = {'NRML': 'D', 'CNC': 'D', 'MIS': 'I'}
    prod_code = product_map.get(product, product)
    txn_type = 'BUY' if signal.get('side', 'BUY').upper().startswith('B') else 'SELL'

    entry = signal.get('entry')
    sl = signal.get('sl')
    tp = signal.get('tp')

    rules = []
    # ENTRY rule: immediate trigger at entry price
    if entry is not None:
        rules.append({
            'strategy': 'ENTRY',
            'trigger_type': 'IMMEDIATE',
            'trigger_price': _round_up_to_tick(float(entry))
        })
    # STOPLOSS rule
    if sl is not None:
        rules.append({
            'strategy': 'STOPLOSS',
            'trigger_type': 'IMMEDIATE',
            'trigger_price': _round_up_to_tick(float(sl)),
            'trailing_gap': 3.83
        })
    # TARGET rule
    if tp is not None:
        rules.append({
            'strategy': 'TARGET',
            'trigger_type': 'IMMEDIATE',
            'trigger_price': _round_up_to_tick(float(tp))
        })

    payload = {
        'type': 'MULTIPLE',
        'quantity': int(qty),
        'product': prod_code,
        'instrument_token': instrument_key,
        'transaction_type': txn_type,
        'rules': rules,
        'tag': 'elliott-scanner-bracket'
    }
    return payload


# def place_order(payload: dict, is_gtt: bool = False) -> dict:
#     if not TOKEN:
#         raise RuntimeError('UPSTOX_ACCESS_TOKEN not set in env')
#     # choose base URL: for GTT prefer LIVE_URL if configured, otherwise fallback to BASE_URL
#     if is_gtt:
#         base = (LIVE_URL or BASE_URL).rstrip('/')
#         # GTT endpoint path (may vary by API version)
#         endpoint = LIVE_URL + '/v3/order/gtt/place'
#     else:
#         base = BASE_URL.rstrip('/')
#         endpoint = base + '/v3/order/place'
#     headers = build_headers(TOKEN)
#     print(f"Placing request to endpoint: {endpoint}")
#     r = requests.post(endpoint, headers=headers, json=payload, timeout=20)
#     try:
#         r.raise_for_status()
#     except Exception:
#         # print response details for debugging
#         try:
#             print('Order failed:', r.status_code, r.text)
#         except Exception:
#             pass
#         raise
#     return r.json()

def place_order(payload: dict, is_gtt: bool = False) -> dict:
    """
    Places an order using the appropriate token and endpoint:
    - Sandbox token for regular bracket orders.
    - Live token for GTT orders (live endpoint required).
    """
    # Pick token & base URL
    if is_gtt:
        token = os.getenv("UPSTOX_ACCESS_TOKEN")
        print(token)
        base = (os.getenv("LIVE_URL") or "https://api.upstox.com").rstrip('/')
        endpoint = base + '/v3/order/gtt/place'
        if not token:
            raise RuntimeError("Live token (UPSTOX_ACCESS_TOKEN_LIVE) required for GTT orders.")
    else:
        token = os.getenv("UPSTOX_ACCESS_TOKEN")
        base = (os.getenv("UPSTOX_BASE_URL") or "https://sandbox-api.upstox.com").rstrip('/')
        endpoint = base + '/v3/order/place'
        if not token:
            raise RuntimeError("Sandbox token (UPSTOX_ACCESS_TOKEN) required for bracket orders.")

    headers = build_headers(token)
    print(f"Placing request to endpoint: {endpoint}")
    r = requests.post(endpoint, headers=headers, json=payload, timeout=20)

    try:
        r.raise_for_status()
    except requests.HTTPError:
        try:
            print('Order failed:', r.status_code, r.text)
        except Exception:
            pass
        raise
    return r.json()


def main():
    
    p = argparse.ArgumentParser()
    p.add_argument('--symbol', type=str, default=None, help='Symbol to trade (e.g. INFY). If omitted, picks latest from signals.csv')
    p.add_argument('--signals', type=str, default=DEFAULT_SIGNALS)
    p.add_argument('--account-size', type=float, default=10000.0)
    p.add_argument('--product', choices=['NRML', 'MIS', 'CNC'], default='NRML')
    # legacy dry-run flag kept for compatibility; prefer explicit --execute to run orders
    p.add_argument('--dry-run', action='store_true', default=False, help='(legacy) Keep script in dry-run mode (no execution)')
    p.add_argument('--execute', action='store_true', default=False, help='Execute the prepared order (otherwise dry-run).')
    p.add_argument('--instrument-key', type=str, default=None, help='Optionally provide instrument_key to bypass instruments lookup')
    p.add_argument('--gtt', action='store_true', default=False, help='Create a GTT MULTIPLE payload instead of a regular bracket order')
    args = p.parse_args()

    sig = load_latest_signal(args.signals, args.symbol)
    if not sig:
        print('No signal found; aborting')
        return
    print('Using signal for', sig.get('symbol'))
    qty = compute_qty_from_signal(args.account_size, sig)
    if qty <= 0:
        print('Computed quantity 0; aborting')
        return

    # Prefer CLI instrument-key, then UPSTOX_INSTRUMENT_KEY env, then resolver
    inst_key = args.instrument_key or os.getenv('UPSTOX_INSTRUMENT_KEY') or os.getenv('SANDBOX_APP_INSTRUMENT_KEY')
    if inst_key:
        print('Using provided instrument_key from CLI/env (not calling instruments API)')
    else:
        inst_key = resolve_instrument_key(sig.get('symbol'))
    if not inst_key:
        print('Instrument key resolution failed. You must provide instrument_key manually or adapt the resolver to your Upstox instruments API.')
        return

    if args.gtt:
        payload = build_gtt_payload(inst_key, sig, qty, product=args.product)
    else:
        payload = build_bracket_payload(inst_key, sig, qty, product=args.product)
    print('Prepared payload (preview):')
    print(json.dumps(payload, indent=2))

    # Execution control: run only when --execute is provided. Default behavior is dry-run.
    if not args.execute:
        print('\nDry-run enabled: no order was sent to the sandbox. Re-run with --execute to execute the order (only after careful review).')
        return

    print('Sending order to', LIVE_URL)
    resp = place_order(payload, is_gtt=args.gtt)
    print('Order response:')
    print(json.dumps(resp, indent=2))


if __name__ == '__main__':
    main()
