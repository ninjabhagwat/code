import asyncio
from mcp.server import Server
from mcp.server.stdio import stdio_server
from handlers.upstox_handler import UpstoxHandler

# Create server instance
server = Server("upstox-mcp-server")

# Initialize Upstox handler
upstox_handler = UpstoxHandler()

# Register handlers
server.list_tools = upstox_handler.list_tools
server.call_tool = upstox_handler.call_tool

async def main():
    """Run the MCP server"""
    async with stdio_server() as streams:
        await server.run(*streams)

if __name__ == "__main__":
    asyncio.run(main())