import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

class Settings:
    UPSTOX_API_KEY = os.getenv("UPSTOX_API_KEY")
    UPSTOX_API_SECRET = os.getenv("UPSTOX_API_SECRET")
    UPSTOX_ACCESS_TOKEN = os.getenv("UPSTOX_ACCESS_TOKEN")
    UPSTOX_REDIRECT_URI = os.getenv("UPSTOX_REDIRECT_URI")
    UPSTOX_BASE_URL = "https://api.upstox.com/v2"
    
    @classmethod
    def validate(cls):
        """Validate that required settings are present"""
        if not cls.UPSTOX_API_KEY:
            raise ValueError("UPSTOX_API_KEY environment variable is required")
        if not cls.UPSTOX_ACCESS_TOKEN:
            raise ValueError("UPSTOX_ACCESS_TOKEN environment variable is required")

settings = Settings()