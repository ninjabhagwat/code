import aiohttp
import requests
from typing import Dict, Any
from config.settings import settings


class ApiClient:
    def __init__(self, api_key, api_secret, access_token):
        self.api_key = api_key
        self.api_secret = api_secret
        self.access_token = access_token
        self.base_url = "https://api.upstox.com"

    def _get_headers(self):
        return {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.access_token}"
        }

    def get_market_data(self, symbol):
        url = f"{self.base_url}/marketdata/{symbol}"
        response = requests.get(url, headers=self._get_headers())
        return self._process_response(response)

    def _process_response(self, response):
        if response.status_code == 200:
            return response.json()
        else:
            response.raise_for_status()


class UpstoxAPIClient:
    """Upstox API client for making HTTP requests"""

    def __init__(self):
        self.base_url = settings.UPSTOX_BASE_URL
        self.headers = {
            "Authorization": f"Bearer {settings.UPSTOX_ACCESS_TOKEN}",
            "Accept": "application/json"
        }

    async def _make_request(self, method: str, endpoint: str, params: Dict = None) -> Dict[str, Any]:
        """Make HTTP request to Upstox API"""
        url = f"{self.base_url}{endpoint}"

        async with aiohttp.ClientSession() as session:
            async with session.request(method, url, headers=self.headers, params=params) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    raise Exception(f"API request failed: {response.status} - {await response.text()}")

    async def get_profile(self) -> Dict[str, Any]:
        """Get user profile information"""
        return await self._make_request("GET", "/user/profile")

    async def get_positions(self) -> Dict[str, Any]:
        """Get current trading positions"""
        return await self._make_request("GET", "/portfolio/long-term-positions")

    async def get_holdings(self) -> Dict[str, Any]:
        """Get long-term holdings"""
        return await self._make_request("GET", "/portfolio/long-term-holdings")

    async def get_market_quote(self, instrument_key: str) -> Dict[str, Any]:
        """Get market quote for a symbol"""
        return await self._make_request("GET", "/market-quote/ltp", {"instrument_key": instrument_key})

    async def get_funds(self) -> Dict[str, Any]:
        """Get account funds information"""
        return await self._make_request("GET", "/user/get-funds-and-margin")