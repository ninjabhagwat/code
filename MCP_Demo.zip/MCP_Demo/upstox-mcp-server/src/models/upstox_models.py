from pydantic import BaseModel
from typing import List, Optional, Dict, Any

class MarketData:
    def __init__(self, symbol, last_price, volume, timestamp):
        self.symbol = symbol
        self.last_price = last_price
        self.volume = volume
        self.timestamp = timestamp

class UserInfo:
    def __init__(self, user_id, name, email, balance):
        self.user_id = user_id
        self.name = name
        self.email = email
        self.balance = balance

class Order:
    def __init__(self, order_id, symbol, quantity, price, order_type, status):
        self.order_id = order_id
        self.symbol = symbol
        self.quantity = quantity
        self.price = price
        self.order_type = order_type
        self.status = status

class Portfolio:
    def __init__(self, user_id, holdings):
        self.user_id = user_id
        self.holdings = holdings  # List of MarketData instances

class Trade:
    def __init__(self, trade_id, order_id, timestamp, quantity, price):
        self.trade_id = trade_id
        self.order_id = order_id
        self.timestamp = timestamp
        self.quantity = quantity
        self.price = price

class UserProfile(BaseModel):
    """User profile data model"""
    user_id: str
    user_name: str
    email: str
    exchanges: List[str]
    products: List[str]
    order_types: List[str]
    user_type: str

class Position(BaseModel):
    """Trading position data model"""
    instrument_token: str
    exchange: str
    trading_symbol: str
    product: str
    quantity: int
    average_price: float
    last_price: float
    pnl: float
    day_change: float
    day_change_percentage: float

class Holding(BaseModel):
    """Holdings data model"""
    instrument_token: str
    exchange: str
    trading_symbol: str
    quantity: int
    average_price: float
    last_price: float
    pnl: float
    day_change: float
    day_change_percentage: float

class MarketQuote(BaseModel):
    """Market quote data model"""
    instrument_token: str
    exchange: str
    trading_symbol: str
    last_price: float
    ohlc: Dict[str, float]
    net_change: float
    percentage_change: float
    volume: int

class Funds(BaseModel):
    """Account funds data model"""
    equity: Dict[str, float]
    commodity: Dict[str, float]