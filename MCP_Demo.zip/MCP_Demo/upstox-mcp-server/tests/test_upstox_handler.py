import asyncio
import unittest
import pytest
from unittest.mock import AsyncMock, patch
from src.handlers.upstox_handler import UpstoxHandler

class TestUpstoxHandler(unittest.TestCase):

    def setUp(self):
        self.handler = UpstoxHandler(api_key='test_api_key', api_secret='test_api_secret', redirect_uri='http://localhost')

    def test_authenticate(self):
        response = self.handler.authenticate()
        self.assertTrue(response['success'])

    def test_fetch_market_data(self):
        market_data = self.handler.fetch_market_data()
        self.assertIsInstance(market_data, dict)
        self.assertIn('data', market_data)

    def test_fetch_user_info(self):
        user_info = self.handler.fetch_user_info()
        self.assertIsInstance(user_info, dict)
        self.assertIn('user_id', user_info)

    @pytest.mark.asyncio
    async def test_list_tools(self, handler):
        """Test that tools are listed correctly"""
        tools = await handler.list_tools()

        assert len(tools) == 5
        tool_names = [tool.name for tool in tools]
        assert "get_profile" in tool_names
        assert "get_positions" in tool_names
        assert "get_holdings" in tool_names
        assert "get_market_quote" in tool_names
        assert "get_funds" in tool_names

    @pytest.mark.asyncio
    async def test_get_profile_success(self, handler):
        """Test successful profile retrieval"""
        mock_data = {"user_id": "test123", "user_name": "Test User"}

        with patch.object(handler.api_client, 'get_profile', new_callable=AsyncMock) as mock_get:
            mock_get.return_value = mock_data

            result = await handler.call_tool("get_profile", {})

            assert len(result) == 1
            assert "test123" in result[0].text
            mock_get.assert_called_once()

    @pytest.mark.asyncio
    async def test_get_market_quote_with_instrument(self, handler):
        """Test market quote with instrument key"""
        mock_data = {"last_price": 100.50, "symbol": "RELIANCE"}
        instrument_key = "NSE_EQ|INE002A01018"

        with patch.object(handler.api_client, 'get_market_quote', new_callable=AsyncMock) as mock_get:
            mock_get.return_value = mock_data

            result = await handler.call_tool("get_market_quote", {"instrument_key": instrument_key})

            assert len(result) == 1
            assert "100.50" in result[0].text
            mock_get.assert_called_once_with(instrument_key)

    @pytest.mark.asyncio
    async def test_invalid_tool_name(self, handler):
        """Test handling of invalid tool name"""
        result = await handler.call_tool("invalid_tool", {})

        assert len(result) == 1
        assert "Error:" in result[0].text
        assert "Unknown tool" in result[0].text

if __name__ == '__main__':
    unittest.main()