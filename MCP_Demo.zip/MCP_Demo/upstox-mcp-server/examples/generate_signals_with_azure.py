"""
examples/generate_signals_with_azure.py

Generate future actionable signals using Azure OpenAI and write an actionable_signals.csv
that can be consumed by place_bracket_order_sandbox.py.

Environment variables required:
 - AZURE_OPENAI_KEY        : your Azure OpenAI API key
 - AZURE_OPENAI_ENDPOINT   : your Azure OpenAI endpoint, e.g. https://myresource.openai.azure.com
 - AZURE_OPENAI_DEPLOYMENT : the deployment name for your model (e.g. gpt-4-deploy)
 - AZURE_OPENAI_API_VERSION: optional, defaults to 2023-05-15

Usage:
  python generate_signals_with_azure.py --symbol ICICIBANK --backtest <path-to-backtest.csv>

This script is best-effort: it sends a clear prompt and expects the model to return a JSON
array of signal objects. The script attempts to robustly extract JSON from the model output
and write actionable_signals.csv compatible with the sandbox order script.
"""

import os
import re
import json
import argparse
from datetime import datetime, timezone
import requests
import pandas as pd
from dotenv import load_dotenv

load_dotenv()
# default actionable output path used by place_bracket_order_sandbox.py
DEFAULT_OUT = os.path.join(os.path.dirname(__file__), '..', 'elliott-wave-indicator', 'examples', 'outputs', 'actionable_signals.csv')

# Prefer the historically used env var names but allow variants
AZ_KEY = os.getenv('AZURE_OPENAI_KEY') or os.getenv('AZURE_OPENAI_API_KEY')
AZ_ENDPOINT = os.getenv('AZURE_OPENAI_ENDPOINT')
AZ_DEPLOY = os.getenv('AZURE_OPENAI_DEPLOYMENT_NAME')
AZ_API_VERSION = os.getenv('AZURE_OPENAI_API_VERSION', '2023-05-15')

# do not print secret values; print masked/summary values for diagnostics
print('Azure endpoint:', AZ_ENDPOINT)
print('Azure deployment:', AZ_DEPLOY)


def build_prompt(symbol: str, backtest_sample: dict | None, num_sign als: int = 1) -> str:
    """Construct a prompt describing expected CSV/JSON output.
    The model is asked to return a JSON array of objects with the following keys:
    trading_symbol, side (BUY/SELL), entry, stop_loss, take_profit, position_size,
    risk_perc, signal_time (ISO8601), confidence (0-1)
    """
    ctx = f"Symbol: {symbol}\n"
    if backtest_sample:
        # include a short context from backtest last row
        ctx += "Backtest sample row (latest):\n"
        for k, v in backtest_sample.items():
            ctx += f"- {k}: {v}\n"
    else:
        ctx += "No backtest provided; generate candidate signal based on typical heuristics.\n"

    instructions = (
        "Produce a JSON array with exactly {n} objects. Each object must have the following keys:\n"
        "trading_symbol, side, entry, stop_loss, take_profit, position_size, risk_perc, signal_time, confidence.\n"
        "- trading_symbol: the symbol string (e.g. ICICIBANK)\n"
        "- side: BUY or SELL (uppercase)\n"
        "- entry, stop_loss, take_profit: numeric prices (floats), stop_loss may be null if not applicable\n"
        "- position_size: integer quantity (can be 0 to indicate compute by risk)\n"
        "- risk_perc: number (percent) to size position if position_size is 0\n"
        "- signal_time: ISO8601 timestamp (include timezone, e.g. 2025-10-08T12:34:56+05:30)\n"
        "- confidence: float between 0 and 1 representing model confidence\n"
        "Return only valid JSON (no surrounding explanation). If you cannot generate the full array, return an empty array []."
    )

    return ctx + "\n" + instructions.format(n=num_signals)


def call_azure_chat(prompt: str, deployment: str, api_key: str, endpoint: str, api_version: str = '2023-05-15') -> str:
    """Call Azure OpenAI chat completions and return the assistant content as text."""
    url = endpoint.rstrip('/') + f"/openai/deployments/{deployment}/chat/completions?api-version={api_version}"
    headers = {
        'api-key': api_key,
        'Content-Type': 'application/json'
    }
    body = {
        'messages': [
            {'role': 'system', 'content': 'You are a helpful assistant that outputs clean JSON arrays when asked.'},
            {'role': 'user', 'content': prompt}
        ],
        'max_tokens': 800,
        'temperature': 0.2,
        'n': 1,
    }
    resp = requests.post(url, headers=headers, json=body, timeout=60)
    resp.raise_for_status()
    j = resp.json()
    # Azure returns choices -> message -> content
    try:
        return j['choices'][0]['message']['content']
    except Exception:
        # fallback: try to stringify the full response
        return json.dumps(j)


def extract_json(text: str) -> list:
    """Try to extract a JSON array from free-form model text.
    Returns a Python list (possibly empty) or raises ValueError.
    """
    # quick attempt: direct load
    text = text.strip()
    try:
        data = json.loads(text)
        if isinstance(data, list):
            return data
        # if it's an object wrap in list
        if isinstance(data, dict):
            return [data]
    except Exception:
        pass

    # attempt to find a JSON array using regex
    m = re.search(r"(\[\s*\{.*\}\s*\])", text, flags=re.S)
    if m:
        chunk = m.group(1)
        try:
            return json.loads(chunk)
        except Exception:
            pass

    # try to find a top-level array by locating first '[' and last ']'
    if '[' in text and ']' in text:
        start = text.index('[')
        end = text.rindex(']')
        chunk = text[start:end+1]
        try:
            return json.loads(chunk)
        except Exception:
            pass

    # give up
    raise ValueError('Unable to extract JSON array from model output')


def ensure_fields(records: list, symbol: str) -> pd.DataFrame:
    """Normalize model records and ensure required fields exist; returns DataFrame."""
    norm = []
    for r in records:
        if not isinstance(r, dict):
            continue
        rec = {}
        rec['trading_symbol'] = r.get('trading_symbol') or r.get('symbol') or symbol
        rec['side'] = (r.get('side') or 'BUY').upper()
        rec['entry'] = float(r.get('entry')) if r.get('entry') not in (None, '', 'null') else None
        rec['stop_loss'] = float(r.get('stop_loss') or r.get('sl') or r.get('stop') or 0) if (r.get('stop_loss') or r.get('sl') or r.get('stop')) not in (None, '', 'null') else None
        rec['take_profit'] = float(r.get('take_profit') or r.get('tp') or 0) if (r.get('take_profit') or r.get('tp')) not in (None, '', 'null') else None
        # position_size may be string or numeric
        try:
            ps = r.get('position_size')
            rec['position_size'] = int(ps) if ps not in (None, '', 'null') else ''
        except Exception:
            rec['position_size'] = ''
        try:
            rec['risk_perc'] = float(r.get('risk_perc')) if r.get('risk_perc') not in (None, '', 'null') else ''
        except Exception:
            rec['risk_perc'] = ''
        # signal_time: accept provided or use now UTC
        st = r.get('signal_time')
        if st in (None, '', 'null'):
            rec['signal_time'] = datetime.now(timezone.utc).isoformat()
        else:
            rec['signal_time'] = str(st)
        # optional confidence
        try:
            rec['confidence'] = float(r.get('confidence')) if r.get('confidence') not in (None, '', 'null') else ''
        except Exception:
            rec['confidence'] = ''
        norm.append(rec)
    if not norm:
        return pd.DataFrame()
    df = pd.DataFrame(norm)
    # reorder columns to match expected actionable_signals.csv style
    cols = ['trading_symbol','side','entry','stop_loss','take_profit','position_size','risk_perc','signal_time','confidence']
    for c in cols:
        if c not in df.columns:
            df[c] = ''
    return df[cols]


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--symbol', required=False, help='Optional single symbol to generate for; if omitted, symbols are read from signals.csv')
    p.add_argument('--backtest', required=False, help='Optional backtest CSV to provide context to the model')
    p.add_argument('--out', default=DEFAULT_OUT, help='Output actionable_signals.csv')
    p.add_argument('--num', type=int, default=1, help='Number of signals to request from model per symbol')
    p.add_argument('--deployment', type=str, default=None, help='Azure deployment name (overrides env)')
    args = p.parse_args()

    deployment = args.deployment or AZ_DEPLOY
    if not AZ_KEY or not AZ_ENDPOINT or not deployment:
        print('Missing Azure OpenAI configuration. Set AZURE_OPENAI_KEY, AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_DEPLOYMENT env vars or pass --deployment')
        return

    # Determine symbols: if provided use that, otherwise read signals.csv to collect unique symbols
    symbols = []
    if args.symbol:
        symbols = [args.symbol.strip().upper()]
    else:
        # try common signals locations
        cand_paths = [
            os.path.join(os.path.dirname(__file__), '..', 'elliott-wave-indicator', 'examples', 'outputs', 'signals.csv'),
            os.path.join(os.path.dirname(__file__), '..', 'elliott-wave-indicator', 'signals.csv'),
            os.path.join(os.path.dirname(__file__), '..', 'elliott-wave-indicator', 'examples', 'outputs', 'actionable_signals.csv')
        ]
        sig_df = None
        for pth in cand_paths:
            if os.path.exists(pth):
                try:
                    sig_df = pd.read_csv(pth, dtype=str)
                    print('Loaded symbols from', pth)
                    break
                except Exception:
                    continue
        if sig_df is None or sig_df.empty:
            print('No signals.csv found to infer symbols; please provide --symbol or place signals.csv in expected location')
            return
        # pick common symbol columns
        sym_cols = [c for c in sig_df.columns if c.lower() in ('trading_symbol','tradingsymbol','symbol','ticker','asset_symbol')]
        if not sym_cols:
            # fallback: any column with 'symbol' in name
            sym_cols = [c for c in sig_df.columns if 'symbol' in c.lower() or 'ticker' in c.lower()]
        vals = set()
        for sc in sym_cols:
            vals.update(sig_df[sc].dropna().astype(str).str.strip().str.upper().unique().tolist())
        symbols = sorted([v for v in vals if v])

    if not symbols:
        print('No symbols to process; exiting')
        return

    # Prepare auxiliary data paths
    actionable_path = os.path.join(os.path.dirname(__file__), '..', 'elliott-wave-indicator', 'examples', 'outputs', 'actionable_signals.csv')
    historical_path = os.path.join(os.path.dirname(__file__), '..', 'historical_candles_latest.csv')
    backtest_default = os.path.join(os.path.dirname(__file__), '..', 'elliott-wave-indicator', 'examples', 'outputs', 'backtest_results_from_actionable.csv')

    all_results = []
    for sym in symbols:
        # collect backtest sample for this symbol
        back_sample = None
        back_path = args.backtest or backtest_default
        if back_path and os.path.exists(back_path):
            try:
                bdf = pd.read_csv(back_path, dtype=str)
                # try to filter by symbol column if present
                sym_cols = [c for c in bdf.columns if c.lower() in ('trading_symbol','symbol','tradingsymbol','ticker')]
                if sym_cols:
                    mask = None
                    for sc in sym_cols:
                        cur = bdf[sc].astype(str).str.strip().str.upper()
                        cur_mask = cur == sym
                        mask = cur_mask if mask is None else (mask | cur_mask)
                    bdf = bdf.loc[mask] if mask is not None else bdf
                if not bdf.empty:
                    back_sample = bdf.iloc[-1].to_dict()
            except Exception as e:
                print('Failed to read backtest CSV for', sym, e)

        # collect recent actionable rows for symbol (for prompt context)
        actionable_rows = None
        if os.path.exists(actionable_path):
            try:
                adf = pd.read_csv(actionable_path, dtype=str)
                sym_cols = [c for c in adf.columns if c.lower() in ('trading_symbol','symbol','tradingsymbol','ticker')]
                if sym_cols:
                    mask = None
                    for sc in sym_cols:
                        cur = adf[sc].astype(str).str.strip().str.upper()
                        cur_mask = cur == sym
                        mask = cur_mask if mask is None else (mask | cur_mask)
                    sub = adf.loc[mask] if mask is not None else adf
                else:
                    sub = adf
                if not sub.empty:
                    actionable_rows = sub.tail(5).to_dict(orient='records')
            except Exception:
                actionable_rows = None

        # collect simple historical sample (last close) for symbol
        hist_sample = None
        if os.path.exists(historical_path):
            try:
                hdf = pd.read_csv(historical_path, dtype=str)
                # find symbol column and date/close
                sym_cols_h = [c for c in hdf.columns if c.lower() in ('trading_symbol','symbol','tradingsymbol','ticker')]
                date_cols = [c for c in hdf.columns if 'date' in c.lower() or 'time' in c.lower() or 'timestamp' in c.lower()]
                price_cols = [c for c in hdf.columns if c.lower() in ('close','last','price')]
                if sym_cols_h:
                    mask = None
                    for sc in sym_cols_h:
                        cur = hdf[sc].astype(str).str.strip().str.upper()
                        cur_mask = cur == sym
                        mask = cur_mask if mask is None else (mask | cur_mask)
                    hsub = hdf.loc[mask] if mask is not None else hdf
                else:
                    hsub = hdf
                if not hsub.empty:
                    # pick last row and provide date/close if available
                    last = hsub.tail(1).iloc[0]
                    hist_sample = { 'date': last[date_cols[0]] if date_cols else None, 'close': last[price_cols[0]] if price_cols else None }
            except Exception:
                hist_sample = None

        # build a contextual prompt that includes actionable rows and historical sample
        ctx_prompt = build_prompt(sym, back_sample, num_signals=args.num)
        if actionable_rows:
            ctx_prompt += "\nRecent actionable_signals (latest rows):\n"
            for r in actionable_rows:
                ctx_prompt += json.dumps(r) + "\n"
        if hist_sample:
            ctx_prompt += "\nHistorical sample (latest):\n"
            ctx_prompt += json.dumps(hist_sample) + "\n"

        # allow env-var prompt override
        final_prompt = os.getenv('AZURE_OPENAI_PROMPT') or ctx_prompt

        print('Sending prompt to Azure OpenAI for', sym)
        try:
            content = call_azure_chat(final_prompt, deployment, AZ_KEY, AZ_ENDPOINT, AZ_API_VERSION)
        except requests.HTTPError as e:
            resp = getattr(e, 'response', None)
            if resp is not None:
                try:
                    print('Azure API error for', sym, resp.status_code, resp.text)
                except Exception:
                    print('Azure API HTTPError:', e)
            else:
                print('Azure API call failed:', e)
            continue
        except Exception as e:
            print('Azure API call failed for', sym, e)
            continue

        try:
            records = extract_json(content)
        except Exception as e:
            print('Failed to parse model output as JSON for', sym, e)
            print('Raw model output:\n', content)
            continue

        sdf = ensure_fields(records, sym)
        if sdf.empty:
            print('Model returned no valid records for', sym)
            continue
        all_results.append(sdf)

    if not all_results:
        print('No signals generated')
        return

    out_df = pd.concat(all_results, ignore_index=True)
    out_dir = os.path.dirname(args.out)
    os.makedirs(out_dir, exist_ok=True)
    out_df.to_csv(args.out, index=False)
    print(f'Wrote {len(out_df)} signal(s) to {args.out}')


if __name__ == '__main__':
    main()
