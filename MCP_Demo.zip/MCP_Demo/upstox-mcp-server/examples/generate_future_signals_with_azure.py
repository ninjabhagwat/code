r"""
generate_future_signals_with_azure.py

Hybrid signal generator that uses deterministic features (from historical candles and existing
Elliott-wave signals) + Azure OpenAI to propose actionable future trading signals whose datetime must be
grater than the latest datetime of each stock since the signal is future one and use is going to use it in current session
for trading 
.

Output:
 - examples/outputs/actionable_signals_generated.csv  (all generated candidates)
 - examples/outputs/actionable_signals_generated_best.csv (top-N selected)

Usage (PowerShell):
  python .\upstox-mcp-server\examples\generate_future_signals_with_azure.py --top 5

Requires Azure env vars (optional - script can still compute features if not set):
 - AZURE_OPENAI_KEY or AZURE_OPENAI_API_KEY
 - AZURE_OPENAI_ENDPOINT
 - AZURE_OPENAI_DEPLOYMENT (or AZURE_OPENAI_DEPLOYMENT_VERSION)
"""

import os
import json
import math
import argparse
from datetime import datetime, timezone
import pandas as pd
import numpy as np
import requests

ROOT = r"c:\Niranjan\Personal\MCP_Demo\upstox-mcp-server"
OUT_DIR = os.path.join(ROOT, 'elliott-wave-indicator', 'examples', 'outputs')
HIST_PATH = os.path.join(ROOT, 'historical_candles_latest.csv')
PER_SYMBOL_SIGNALS_GLOB = os.path.join(OUT_DIR, '*_signals.csv')
COMBINED_ACTIONABLE = os.path.join(OUT_DIR, 'actionable_signals.csv')
OUT_GENERATED = os.path.join(OUT_DIR, 'actionable_signals_generated.csv')
OUT_BEST = os.path.join(OUT_DIR, 'actionable_signals_generated_best.csv')
ELLIOT_IMG_DIR = os.path.join(OUT_DIR, 'elliot_wave')

# Azure config
# Load .env from repository root if present so keys like AZURE_OPENAI_API_KEY are picked up
dotenv_path = r'C:\Niranjan\Personal\MCP_Demo\upstox-mcp-server\examples\.env'
loaded_dotenv = False
try:
    from dotenv import load_dotenv
    # try multiple candidate .env locations (repo root, parent, current working dir)
    candidates = [dotenv_path, os.path.join(os.path.dirname(ROOT), '.env'), os.path.join(os.getcwd(), '.env')]
    for p in candidates:
        if os.path.exists(p):
            load_dotenv(p)
            loaded_dotenv = True
            break
    if not loaded_dotenv:
        # fallback: let load_dotenv search the environment
        try:
            load_dotenv()
            loaded_dotenv = True
        except Exception:
            loaded_dotenv = False
except Exception:
    # python-dotenv not installed or failed to load; attempt a simple manual .env parser
    candidates = [dotenv_path, os.path.join(os.path.dirname(ROOT), '.env'), os.path.join(os.getcwd(), '.env')]
    for p in candidates:
        if not os.path.exists(p):
            continue
        try:
            with open(p, 'r', encoding='utf-8') as fh:
                for line in fh:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    if '=' not in line:
                        continue
                    k, v = line.split('=', 1)
                    k = k.strip()
                    v = v.strip()
                    # remove optional surrounding quotes
                    if (v.startswith('"') and v.endswith('"')) or (v.startswith("'") and v.endswith("'")):
                        v = v[1:-1]
                    if k and v:
                        os.environ.setdefault(k, v)
            break
        except Exception:
            continue

# Ensure proxy environment variables are visible to requests (dotenv may have set these)
for p in ('HTTP_PROXY', 'HTTPS_PROXY', 'http_proxy', 'https_proxy'):
    val = os.getenv(p)
    if val:
        os.environ[p] = val

# Accept multiple possible env var names to be robust against different .env conventions
AZ_KEY = os.getenv('AZURE_OPENAI_API_KEY') or os.getenv('AZURE_OPENAI_KEY')
AZ_ENDPOINT = os.getenv('AZURE_OPENAI_ENDPOINT') or os.getenv('AZ_ENDPOINT')
AZ_DEPLOY = os.getenv('AZURE_OPENAI_DEPLOYMENT') or os.getenv('AZURE_OPENAI_DEPLOYMENT_NAME') or os.getenv('AZURE_OPENAI_DEPLOYMENT_VERSION')
AZ_API_VERSION = '2025-01-01-preview'

# helpers

def call_azure_chat_simple(prompt: str, deployment: str, api_key: str, endpoint: str, api_version: str = AZ_API_VERSION, timeout: int = 60) -> str:
    if not (api_key and endpoint and deployment):
        raise RuntimeError('Azure OpenAI not configured')
    # construct URL using provided endpoint and deployment
    url = f"{endpoint.rstrip('/')}/openai/deployments/{deployment}/chat/completions?api-version={api_version}"
    headers = {'api-key': api_key, 'Content-Type': 'application/json'}
    body = {
        'messages': [
            {'role': 'system', 'content': 'You are a precise signal generator. Return only a JSON array.'},
            {'role': 'user', 'content': prompt}
        ],
        'max_tokens': 800,
        'temperature': 0.0,
        'n': 1
    }
    r = requests.post(url, headers=headers, json=body, timeout=timeout)
    r.raise_for_status()
    j = r.json()
    try:
        return j['choices'][0]['message']['content']
    except Exception:
        return json.dumps(j)


def extract_json_from_model(text: str) -> list:
    txt = str(text).strip()
    # direct parse
    try:
        j = json.loads(txt)
        return j if isinstance(j, list) else ([j] if isinstance(j, dict) else [])
    except Exception:
        pass

    # crude fallback: try to find a JSON array substring
    start = txt.find('[')
    end = txt.rfind(']')
    if start != -1 and end != -1 and end > start:
        try:
            return json.loads(txt[start:end+1])
        except Exception:
            pass

    # If array end missing (truncated), try to repair by closing at last complete object '}'
    if start != -1:
        last_obj_end = txt.rfind('}')
        if last_obj_end != -1 and last_obj_end > start:
            candidate = txt[start:last_obj_end+1] + ']'
            try:
                return json.loads(candidate)
            except Exception:
                # try removing trailing commas between objects (simple heuristic)
                cand2 = candidate.replace(',\n}', '\n}')
                try:
                    return json.loads(cand2)
                except Exception:
                    pass

    # nothing could be parsed
    return []


def compute_features_from_history(hist_df: pd.DataFrame) -> dict:
    """Compute simple per-symbol features: last_close, atr14, vol20, ret1, ma20"""
    out = {}
    if hist_df.empty:
        return out
    # expected columns: symbol / trading_symbol / timestamp / open high low close
    col_candidates = [c for c in hist_df.columns]
    # try common names
    symbol_col = None
    for candidate in ('symbol','trading_symbol','ticker','instrument'):
        if candidate in col_candidates:
            symbol_col = candidate
            break
    time_col = None
    for candidate in ('timestamp','time','datetime','date'):
        if candidate in col_candidates:
            time_col = candidate
            break
    price_col = None
    for candidate in ('close','Close','price'):
        if candidate in col_candidates:
            price_col = candidate
            break
    high_col = None
    low_col = None
    for candidate in ('high','High'):
        if candidate in col_candidates:
            high_col = candidate
            break
    for candidate in ('low','Low'):
        if candidate in col_candidates:
            low_col = candidate
            break
    if not symbol_col or not price_col:
        return out
    # group
    for sym, g in hist_df.groupby(hist_df[symbol_col].astype(str).str.strip().str.upper()):
        try:
            g2 = g.sort_values(by=time_col) if time_col in g.columns else g
            close = pd.to_numeric(g2[price_col], errors='coerce').dropna()
            if close.empty:
                continue
            last = float(close.iloc[-1])
            ret1 = float((close.pct_change().iloc[-1]) if len(close) > 1 else 0.0)
            vol20 = float(close.pct_change().rolling(window=20, min_periods=1).std().iloc[-1])
            ma20 = float(close.rolling(window=20, min_periods=1).mean().iloc[-1])
            # ATR approximation if high/low present
            atr14 = None
            if high_col and low_col and high_col in g2.columns and low_col in g2.columns:
                high = pd.to_numeric(g2[high_col], errors='coerce')
                low = pd.to_numeric(g2[low_col], errors='coerce')
                tr = (high - low).abs()
                atr14 = float(tr.rolling(window=14, min_periods=1).mean().iloc[-1])
            out[sym] = {'last_close': last, 'ret1': ret1, 'vol20': vol20, 'ma20': ma20, 'atr14': atr14}
        except Exception:
            continue
    return out


def read_recent_elliott_signals(outputs_dir: str, symbol: str, n: int = 5) -> list:
    path = os.path.join(outputs_dir, f"{symbol}_signals.csv")
    if not os.path.exists(path):
        return []
    try:
        df = pd.read_csv(path, dtype=str)
        return df.tail(n).to_dict(orient='records')
    except Exception:
        return []


def build_prompt_for_symbols(symbols: list, features_map: dict, recent_signals_map: dict, backtest_map: dict=None, max_per_symbol: int = 5) -> str:
    prompt = (
        '''You are a senior quantitative trader with 20 years of profitable trading and research experience. Use the provided structured context for each symbol (last_close, ATR, short-term volatility, MA, recent Elliott-wave-derived signals, and any available backtest summary) and produce high-quality, actionable future trading signals.

Output requirements (must be followed exactly)
- Return ONLY a JSON array (no commentary, no explanation, no extra tokens).
- Array elements must be JSON objects with these fields and types:
  {
    "trading_symbol": string,            // e.g. "RELIANCE"
    "side": "BUY" | "SELL",
    "entry": number,                     // price (float)
    "stop_loss": number,                 // price (float)
    "take_profit": number | null,        // price (float) or null if not provided
    "position_size": integer,            // integer quantity (model may provide indicative qty)
    "risk_perc": number,                 // percent of portfolio risked for this trade (0-100)
    "signal_time": ISO8601 string (UTC), // e.g. 2025-10-10T09:20:00Z
    "confidence": number,                // 0.0 - 1.0
    "reason": string                     // short (1-3 sentence) rationale: which signals/features led to this
  }

Hard constraints and validation rules (enforce these)
- Return at most N signals overall if requested (otherwise up to 1 per symbol). If you cannot produce any valid signals, return [].
- entry must be a realistic executable price near market: within ±5% of last_close by default. If you exceed 5% you MUST include a clear numeric justification in `reason`.
- stop_loss must be > 0 and must be on the opposite side of entry (for BUY: stop_loss < entry; for SELL: stop_loss > entry). If this is violated, exclude the signal.
- take_profit, if provided, should be on the same side as the expected move and sensible relative to stop_loss (positive risk:reward).
- confidence must be in [0,1]. Use lower values for speculative/low-liquidity ideas.
- position_size must be an integer. Provide indicative position_size consistent with the provided risk_perc (if both given). If only position_size provided, set risk_perc to explain implied risk.
- signal_time must be an ISO UTC timestamp not in the past (relative to the provided current_time) or use current time if immediate.
- Exclude signals that conflict with clear risk rules (e.g., entry or SL equals 0 or NaN).

Risk management & sizing guidance (follow but model must return both fields)
- Default suggested risk_perc per signal: 0.25%–1.0% of portfolio for intraday/scalp; up to 2% for strong setups. Indicate a reason if you exceed these defaults.
- position_size should be consistent with a simple formula:
  qty = floor( (account_value * (risk_perc/100)) / abs(entry - stop_loss) )
  (If account_value is not provided, return position_size as an indicative integer and include the assumed account_value or basis in `reason`.)

Quality & selection priorities
- Prefer signals with: clear Elliott-wave confirmation + price action confirmation (breakout/retest, momentum), adequate liquidity, reasonable ATR-based SL sizing, and positive historical backtest signals (if provided).
- Penalize: low liquidity, tiny expected move vs spread, earnings events or upcoming corporate actions (if known), or lack of recent confirmation.
- Provide higher confidence for signals that align with both Elliott-wave count and recent price momentum.

Additional instructions for the model
- Use the provided per-symbol features and up to the last K Elliott signals as context. Mention in `reason` which features you used (example: "Elliott wave 3 impulse + price above MA20 + ATR=12 -> TP at X").
- If multiple candidate signals could be returned for a single symbol, return only the best one (unless explicitly asked to return multiple per symbol).
- Keep `reason` concise (one to three short sentences).
- If any numeric field cannot be determined reliably, omit the signal (do not invent unrealistic numbers).
- If you return signals, include only valid rows; otherwise return [].

Example valid output element:
[
  {
    "trading_symbol": "RELIANCE",
    "side": "BUY",
    "entry": 2850.25,
    "stop_loss": 2810.00,
    "take_profit": 2930.00,
    "position_size": 100,
    "risk_perc": 0.5,
    "signal_time": "2025-10-10T09:20:00Z",
    "confidence": 0.87,
    "reason": "Elliott wave 3 confirmed, price above MA20, ATR supports SL distance"
  }
]

Final note
- Only output the JSON array. If you cannot produce any valid signals under the rules above, output an empty JSON array: []'''
    )
    for s in symbols:
        feat = features_map.get(s, {})
        recent = recent_signals_map.get(s, [])
        prompt += f"Symbol: {s}\nFeatures: {json.dumps(feat)}\nRecent Elliot signals (sample): {json.dumps(recent[:max_per_symbol])}\n"
        if backtest_map and s in backtest_map:
            prompt += f"Backtest summary: {json.dumps(backtest_map[s])}\n"
        prompt += "\n"
    prompt += "Return only a JSON array."
    return prompt


def validate_and_normalize_candidates(records: list) -> pd.DataFrame:
    norm = []
    for r in records:
        if not isinstance(r, dict):
            continue
        try:
            sym = (r.get('trading_symbol') or r.get('symbol') or '').strip().upper()
            side = (r.get('side') or 'BUY').upper()
            entry = float(r.get('entry')) if r.get('entry') not in (None, '') else None
            sl = float(r.get('stop_loss')) if r.get('stop_loss') not in (None, '') else None
            tp = float(r.get('take_profit')) if r.get('take_profit') not in (None, '') else None
            pos = int(r.get('position_size')) if r.get('position_size') not in (None, '') else ''
            risk = float(r.get('risk_perc')) if r.get('risk_perc') not in (None, '') else ''
            stime = r.get('signal_time') or datetime.now(timezone.utc).isoformat()
            conf = float(r.get('confidence')) if r.get('confidence') not in (None, '') else 0.0
            reason = r.get('reason') or ''
            # basic sanity
            if not sym or side not in ('BUY','SELL') or entry is None or sl is None:
                continue
            norm.append({'trading_symbol': sym, 'side': side, 'entry': entry, 'stop_loss': sl, 'take_profit': tp,
                         'position_size': pos, 'risk_perc': risk, 'signal_time': stime, 'confidence': conf, 'reason': reason})
        except Exception:
            continue
    if not norm:
        return pd.DataFrame()
    return pd.DataFrame(norm)


def enforce_generated_constraints(df: pd.DataFrame, features_map: dict, max_pct: float = 0.05) -> pd.DataFrame:
    """Drop candidates that violate hard constraints not enforced by the model/prompt:
      - entry must be within ±max_pct of features_map[s]['last_close'] if available
      - stop_loss must be on the opposite side of entry (BUY: SL < entry; SELL: SL > entry)
      - signal_time must be in the future (UTC)
    Returns a filtered dataframe (may be empty).
    """
    if df is None or df.empty:
        return pd.DataFrame()
    kept = []
    rejected_count = 0
    now = datetime.now(timezone.utc)
    for _, r in df.iterrows():
        try:
            sym = str(r.get('trading_symbol') or '').strip().upper()
            entry = float(r.get('entry'))
            sl = float(r.get('stop_loss'))
            side = str(r.get('side') or 'BUY').upper()
            stime_raw = r.get('signal_time') or ''
            # parse ISO timestamp robustly
            try:
                stime = datetime.fromisoformat(stime_raw.replace('Z', '+00:00'))
            except Exception:
                stime = now
            # check entry proximity if last_close known
            last = None
            if sym and features_map and sym in features_map:
                last_val = features_map[sym].get('last_close')
                try:
                    last = float(last_val) if last_val is not None else None
                except Exception:
                    last = None
            if last is not None:
                if last <= 0 or abs(entry - last) / max(abs(last), 1e-9) > max_pct:
                    rejected_count += 1
                    continue
            # stop loss direction
            if side == 'BUY' and not (sl < entry):
                rejected_count += 1
                continue
            if side == 'SELL' and not (sl > entry):
                rejected_count += 1
                continue
            # signal_time must be in future (allow small slack)
            if stime <= now:
                rejected_count += 1
                continue
            kept.append(r)
        except Exception:
            rejected_count += 1
            continue
    if rejected_count:
        print(f'Enforce constraints: rejected generated candidates count={rejected_count}')
    if not kept:
        return pd.DataFrame()
    return pd.DataFrame(kept).reset_index(drop=True)


def score_signal_simple(row: pd.Series, backtest_map: dict) -> float:
    c = float(row.get('confidence') or 0.0)
    score = max(0.0, min(1.0, c))
    if row.get('risk_perc'):
        try:
            r = float(row.get('risk_perc'))
            if r <= 1.0:
                score *= 1.0
        except Exception:
            pass
    sym = str(row.get('trading_symbol') or '').strip().upper()
    if sym and backtest_map and sym in backtest_map:
        try:
            wr = float(backtest_map[sym].get('win_rate') or 0.0)
            wr_norm = max(0.0, min(1.0, wr/100.0))
            score = score * (1.0 + 0.5 * wr_norm)
        except Exception:
            pass
    return float(score)


def pick_top_n_generated(df: pd.DataFrame, backtest_map: dict, features_map: dict = None, recent_map: dict = None, top_n: int = 5) -> pd.DataFrame:
    """Score candidates, pick top-N and attach a short analysis explaining the rationale.

    The analysis summarizes confidence, backtest win-rate, ATR/MA20 context and simple RR calculation.
    """
    if df.empty:
        return df
    df2 = df.copy()

    # compute base score using existing confidence/backtest logic
    df2['_score'] = df2.apply(lambda r: score_signal_simple(r, backtest_map), axis=1)

    # enrich score slightly based on presence of take_profit and reasonable rr
    def _enrich_score(row):
        score = float(row.get('_score') or 0.0)
        try:
            entry = float(row.get('entry') or 0)
            sl = float(row.get('stop_loss') or 0)
            tp = row.get('take_profit')
            if tp not in (None, ''):
                tp = float(tp)
                rr = abs((tp - entry) / max(abs(entry - sl), 1e-6)) if entry and sl is not None else None
                if rr and rr >= 1.0:
                    score += 0.05
                elif rr and rr < 0.5:
                    score -= 0.03
        except Exception:
            pass
        return max(0.0, min(2.0, score))

    df2['_score'] = df2.apply(_enrich_score, axis=1)

    # sort by score then confidence
    df2 = df2.sort_values(by=['_score', 'confidence'], ascending=[False, False])
    out = df2.head(top_n).copy()
    out['_selected_score'] = out['_score']

    # Build analysis string per selected row using features_map and backtest_map
    analyses = []
    for _, r in out.iterrows():
        sym = str(r.get('trading_symbol') or '').strip().upper()
        conf = float(r.get('confidence') or 0.0)
        score = float(r.get('_selected_score') or 0.0)
        bt = backtest_map.get(sym, {}) if backtest_map else {}
        wr = bt.get('win_rate') if bt else None
        avg_rr = bt.get('avg_rr') if bt else None
        feat = (features_map.get(sym) if features_map and sym in features_map else {})
        atr = feat.get('atr14') if feat else None
        ma20 = feat.get('ma20') if feat else None
        recent = (recent_map.get(sym) if recent_map and sym in recent_map else [])
        recent_cnt = len(recent) if recent is not None else 0

        # compute simple rr if tp present
        rr_text = ''
        try:
            entry = float(r.get('entry'))
            sl = float(r.get('stop_loss'))
            tp = r.get('take_profit')
            if tp not in (None, ''):
                tp = float(tp)
                rr = abs((tp - entry) / max(abs(entry - sl), 1e-6))
                rr_text = f'RR~{rr:.2f}; '
        except Exception:
            rr_text = ''

        parts = []
        parts.append(f'confidence={conf:.2f}')
        parts.append(f'score={score:.3f}')
        if wr is not None:
            try:
                parts.append(f'backtest_wr={float(wr):.1f}%')
            except Exception:
                parts.append(f'backtest_wr={wr}')
        if avg_rr is not None:
            try:
                parts.append(f'backtest_avgRR={float(avg_rr):.2f}')
            except Exception:
                parts.append(f'backtest_avgRR={avg_rr}')
        if atr is not None:
            try:
                parts.append(f'ATR={float(atr):.2f}')
            except Exception:
                parts.append(f'ATR={atr}')
        if ma20 is not None:
            try:
                parts.append(f'MA20={float(ma20):.2f}')
            except Exception:
                parts.append(f'MA20={ma20}')
        parts.append(f'recent_signals={recent_cnt}')
        if rr_text:
            parts.insert(2, rr_text.strip())

        analysis = '; '.join(parts)
        analyses.append(analysis)

    out = out.reset_index(drop=True)
    out['analysis'] = analyses

    # ensure output columns
    cols = ['trading_symbol', 'side', 'entry', 'stop_loss', 'take_profit', 'position_size', 'risk_perc', 'signal_time', 'confidence', '_selected_score', 'analysis', 'reason']
    for c in cols:
        if c not in out.columns:
            out[c] = ''
    return out[cols]


def main():
    p = argparse.ArgumentParser(description='Generate future signals using Azure LLM + history/features')
    p.add_argument('--top', type=int, default=5)
    p.add_argument('--symbols', type=str, default='', help='Comma-separated symbols to consider (defaults to actionable_signals.csv symbols)')
    p.add_argument('--max-per-symbol', type=int, default=5)
    p.add_argument('--dry-run', action='store_true')
    args = p.parse_args()

    # load history
    hist = None
    if os.path.exists(HIST_PATH):
        try:
            hist = pd.read_csv(HIST_PATH, dtype=str)
        except Exception as e:
            print('Failed to read historical candles:', e)
            hist = pd.DataFrame()
    else:
        hist = pd.DataFrame()

    features = compute_features_from_history(hist)

    # determine symbols
    symbols = []
    if args.symbols:
        symbols = [s.strip().upper() for s in args.symbols.split(',') if s.strip()]
    else:
        # prefer actionable_signals.csv list
        if os.path.exists(COMBINED_ACTIONABLE):
            try:
                cand = pd.read_csv(COMBINED_ACTIONABLE, dtype=str)
                symbols = list(cand['trading_symbol'].astype(str).str.strip().str.upper().unique())
            except Exception:
                symbols = []
        if not symbols:
            # fall back to per-symbol files
            import glob
            for f in glob.glob(PER_SYMBOL_SIGNALS_GLOB):
                name = os.path.basename(f).split('_signals.csv')[0]
                symbols.append(name.strip().upper())
    if not symbols:
        print('No symbols found to generate signals for')
        return

    # collect recent per-symbol signals
    recent_map = {s: read_recent_elliott_signals(OUT_DIR, s, n=args.max_per_symbol) for s in symbols}

    # load lightweight backtest map if available
    backmap = {}
    backtest_file = os.path.join(OUT_DIR, 'backtest_results_from_actionable.csv')
    if os.path.exists(backtest_file):
        try:
            bdf = pd.read_csv(backtest_file, dtype=str)
            for _, r in bdf.iterrows():
                key = str(r.get('trading_symbol') or r.get('symbol') or '').strip().upper()
                if not key:
                    continue
                backmap[key] = {'win_rate': float(r.get('win_rate') or 0),'avg_rr': float(r.get('avg_rr') or 0)}
        except Exception:
            backmap = {}

    # build prompt and call Azure
    prompt = build_prompt_for_symbols(symbols, features, recent_map, backtest_map=backmap, max_per_symbol=args.max_per_symbol)

    generated_df = pd.DataFrame()
    if AZ_KEY and AZ_ENDPOINT and AZ_DEPLOY:
        try:
            content = call_azure_chat_simple(prompt, AZ_DEPLOY, AZ_KEY, AZ_ENDPOINT)
            print('\n--- RAW MODEL OUTPUT START ---')
            print(content)
            print('--- RAW MODEL OUTPUT END ---\n')

            # attempt to extract JSON array from model text
            try:
                recs = extract_json_from_model(content)
                print('extract_json_from_model ->', type(recs), 'len=', len(recs) if hasattr(recs, '__len__') else 'N/A')
                if isinstance(recs, list) and len(recs) > 0:
                    print('sample extracted record keys:', list(recs[0].keys()) if isinstance(recs[0], dict) else 'not-dict')
                else:
                    print('No JSON array extracted from model output')
            except Exception as ex:
                recs = []
                print('extract_json_from_model raised:', ex)

            # validate/normalize
            try:
                gen = validate_and_normalize_candidates(recs)
                if isinstance(gen, pd.DataFrame):
                    print('validate_and_normalize_candidates -> dataframe shape', gen.shape)
                    if not gen.empty:
                        print('validated sample:\n', gen.head().to_string())
                else:
                    print('validate_and_normalize_candidates returned non-dataframe:', type(gen))
            except Exception as ex:
                gen = pd.DataFrame()
                print('validate_and_normalize_candidates raised:', ex)

            # enforce programmatic hard constraints (entry near last_close, SL side, future time)
            if isinstance(gen, pd.DataFrame) and not gen.empty:
                gen = enforce_generated_constraints(gen, features, max_pct=0.05)
                if gen.empty:
                    print('All generated candidates were rejected by hard constraints')
                else:
                    generated_df = gen
        except Exception as e:
            print('Azure generation failed:', e)
    else:
        print('Azure not configured - no generation performed. You can still use features/backtest offline.')

    if generated_df.empty:
        print('No generated signals')
        return

    # save generated candidates
    if not args.dry_run:
        generated_df.to_csv(OUT_GENERATED, index=False)
        print('Wrote generated candidates ->', OUT_GENERATED)

    # pick top
    topn = pick_top_n_generated(generated_df, backmap, features_map=features, recent_map=recent_map, top_n=args.top)
    if topn.empty:
        print('No top signals selected')
        return
    if not args.dry_run:
        topn.to_csv(OUT_BEST, index=False)
        print('Wrote selected top signals ->', OUT_BEST)
    print(topn.to_string(index=False))


if __name__ == '__main__':
    main()