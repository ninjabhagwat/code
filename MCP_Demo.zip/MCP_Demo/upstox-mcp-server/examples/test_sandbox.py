import requests

# Replace with your actual sandbox access token
ACCESS_TOKEN = "eyJ0eXAiOiJKV1QiLCJrZXlfaWQiOiJza192MS4wIiwiYWxnIjoiSFMyNTYifQ.eyJzdWIiOiI0MkJOVUMiLCJqdGkiOiI2OGRkMzkyYjJiNWI4MDcyOGY1OWMyODAiLCJpc011bHRpQ2xpZW50IjpmYWxzZSwiaXNQbHVzUGxhbiI6dHJ1ZSwiaWF0IjoxNzU5MzI4NTU1LCJpc3MiOiJ1ZGFwaS1nYXRld2F5LXNlcnZpY2UiLCJleHAiOjE3NjE4NjE2MDB9.LAkshHvoxXdFR3Dkul5TyW5uusRWID3EKXF2q-MqBVk"

# Correct GTT endpoint
url = "https://https://api.upstox.com/v3/gtt/order"

# Headers
headers = {
    "Authorization": f"Bearer {ACCESS_TOKEN}",
    "Content-Type": "application/json",
    "Accept": "application/json"
}

# GTT bracket order payload
payload = {
  "type": "MULTIPLE",
  "quantity": 28,
  "product": "D",
  "instrument_token": "NSE_EQ|INE095A01012",
  "transaction_type": "BUY",
  "rules": [
    {
      "strategy": "ENTRY",
      "trigger_type": "BELOW",
      "trigger_price": 712.75
    },
    {
      "strategy": "STOPLOSS",
      "trigger_type": "IMMEDIATE",
      "trigger_price": 709.18
    },
    {
      "strategy": "TARGET",
      "trigger_type": "IMMEDIATE",
      "trigger_price": 724.28
    }
  ],
  "tag": "elliott-scanner-bracket"
}

# Send request
response = requests.post(url, headers=headers, json=payload)

# Output response
print("Status Code:", response.status_code)
