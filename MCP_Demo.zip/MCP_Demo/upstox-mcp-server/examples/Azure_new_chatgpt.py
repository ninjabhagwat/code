"""
generate_future_signals_with_azure.py

Hybrid signal generator that uses deterministic features (from historical candles and existing
Elliott-wave signals) + Azure OpenAI to propose actionable future trading signals whose datetime 
must be greater than the latest datetime of each stock since the signal is future one.

Outputs:
 - examples/outputs/actionable_signals_generated.csv  (all generated candidates)
 - examples/outputs/actionable_signals_generated_best.csv (top-N selected)
"""

import os
import json
import argparse
from datetime import datetime, timezone
import pandas as pd
import numpy as np
import requests
import glob

ROOT = r"c:\Niranjan\Personal\MCP_Demo\upstox-mcp-server"
OUT_DIR = os.path.join(ROOT, 'elliott-wave-indicator', 'examples', 'outputs')
HIST_PATH = os.path.join(ROOT, 'historical_candles_latest.csv')
PER_SYMBOL_SIGNALS_GLOB = os.path.join(OUT_DIR, '*_signals.csv')
COMBINED_ACTIONABLE = os.path.join(OUT_DIR, 'actionable_signals.csv')
OUT_GENERATED = os.path.join(OUT_DIR, 'actionable_signals_generated.csv')
OUT_BEST = os.path.join(OUT_DIR, 'actionable_signals_generated_best.csv')

# Load dotenv if present
try:
    from dotenv import load_dotenv
    dotenv_path = os.path.join(ROOT, 'examples', '.env')
    if os.path.exists(dotenv_path):
        load_dotenv(dotenv_path)
except Exception:
    pass

# Azure config
AZ_KEY = os.getenv('AZURE_OPENAI_API_KEY')
AZ_ENDPOINT = os.getenv('AZURE_OPENAI_ENDPOINT')
AZ_DEPLOY = os.getenv('AZURE_OPENAI_DEPLOYMENT_NAME')
AZ_API_VERSION = '2025-01-01-preview'

if not all([AZ_KEY, AZ_ENDPOINT, AZ_DEPLOY]):
    print("Warning: Azure OpenAI not fully configured. No AI generation will occur.")

# ---------------- HELPERS ---------------- #

def call_azure_chat_simple(prompt: str, deployment: str, api_key: str, endpoint: str, api_version: str = AZ_API_VERSION, timeout: int = 60) -> str:
    if not (api_key and endpoint and deployment):
        raise RuntimeError('Azure OpenAI not configured properly')
    url = f"{endpoint}/openai/deployments/{deployment}/chat/completions?api-version={api_version}"
    headers = {'api-key': api_key, 'Content-Type': 'application/json'}
    body = {
        'messages': [
            {'role': 'system', 'content': 'You are a precise signal generator. Return only a JSON array.'},
            {'role': 'user', 'content': prompt}
        ],
        'max_tokens': 800,
        'temperature': 0.0,
        'n': 1
    }
    r = requests.post(url, headers=headers, json=body, timeout=timeout)
    r.raise_for_status()
    j = r.json()
    try:
        return j['choices'][0]['message']['content']
    except Exception:
        return json.dumps(j)

def extract_json_from_model(text: str) -> list:
    """Attempt to parse JSON array from model output."""
    txt = str(text).strip()
    try:
        j = json.loads(txt)
        return j if isinstance(j, list) else ([j] if isinstance(j, dict) else [])
    except Exception:
        pass
    start = txt.find('[')
    end = txt.rfind(']')
    if start != -1 and end != -1 and end > start:
        try:
            return json.loads(txt[start:end+1])
        except Exception:
            pass
    # fallback
    return []

def compute_features_from_history(hist_df: pd.DataFrame) -> dict:
    """Compute simple per-symbol features: last_close, atr14, vol20, ret1, ma20"""
    out = {}
    if hist_df.empty:
        return out
    symbol_col = next((c for c in ['symbol','trading_symbol','ticker','instrument'] if c in hist_df.columns), None)
    time_col = next((c for c in ['timestamp','time','datetime','date'] if c in hist_df.columns), None)
    price_col = next((c for c in ['close','Close','price'] if c in hist_df.columns), None)
    high_col = next((c for c in ['high','High'] if c in hist_df.columns), None)
    low_col = next((c for c in ['low','Low'] if c in hist_df.columns), None)
    if not symbol_col or not price_col:
        return out
    for sym, g in hist_df.groupby(hist_df[symbol_col].astype(str).str.strip().str.upper()):
        try:
            g2 = g.sort_values(by=time_col) if time_col in g.columns else g
            close = pd.to_numeric(g2[price_col], errors='coerce').dropna()
            if close.empty:
                continue
            last = float(close.iloc[-1])
            ret1 = float((close.pct_change().iloc[-1]) if len(close) > 1 else 0.0)
            vol20 = float(close.pct_change().rolling(window=20, min_periods=1).std().iloc[-1])
            ma20 = float(close.rolling(window=20, min_periods=1).mean().iloc[-1])
            atr14 = None
            if high_col and low_col:
                high = pd.to_numeric(g2[high_col], errors='coerce')
                low = pd.to_numeric(g2[low_col], errors='coerce')
                tr = (high - low).abs()
                atr14 = float(tr.rolling(window=14, min_periods=1).mean().iloc[-1])
            out[sym] = {'last_close': last, 'ret1': ret1, 'vol20': vol20, 'ma20': ma20, 'atr14': atr14}
        except Exception:
            continue
    return out

def read_recent_elliott_signals(outputs_dir: str, symbol: str, n: int = 5) -> list:
    path = os.path.join(outputs_dir, f"{symbol}_signals.csv")
    if not os.path.exists(path):
        return []
    try:
        df = pd.read_csv(path, dtype=str)
        return df.tail(n).to_dict(orient='records')
    except Exception:
        return []

def build_prompt_for_symbols(symbols: list, features_map: dict, recent_signals_map: dict, top_n: int = 5) -> str:
    """Build prompt asking AI to generate future actionable signals beyond last CSV datetime"""
    prompt = "You are a senior quantitative trader. Generate future actionable BUY/SELL signals. " \
             "All signal_time must be strictly after the latest signal timestamp for each symbol.\n"
    for s in symbols:
        feat = features_map.get(s, {})
        recent = recent_signals_map.get(s, [])
        latest_dt = None
        if recent:
            try:
                latest_dt = max([r.get('signal_time') for r in recent if r.get('signal_time')])
            except:
                latest_dt = None
        prompt += f"\nSymbol: {s}\nFeatures: {json.dumps(feat)}\nRecent signals (last {len(recent)}): {json.dumps(recent)}\n"
        if latest_dt:
            prompt += f"All generated signals must have signal_time strictly after {latest_dt} (UTC).\n"
    prompt += f"Return at most {top_n} signals overall. Return ONLY a JSON array with fields: " \
              "trading_symbol, side, entry, stop_loss, take_profit, position_size, risk_perc, signal_time, confidence, reason."
    return prompt

def validate_and_normalize_candidates(records: list) -> pd.DataFrame:
    norm = []
    for r in records:
        if not isinstance(r, dict):
            continue
        try:
            sym = (r.get('trading_symbol') or '').strip().upper()
            side = (r.get('side') or 'BUY').upper()
            entry = float(r.get('entry')) if r.get('entry') not in (None, '') else None
            sl = float(r.get('stop_loss')) if r.get('stop_loss') not in (None, '') else None
            tp = float(r.get('take_profit')) if r.get('take_profit') not in (None, '') else None
            pos = int(r.get('position_size')) if r.get('position_size') not in (None, '') else ''
            risk = float(r.get('risk_perc')) if r.get('risk_perc') not in (None, '') else ''
            stime = r.get('signal_time') or datetime.now(timezone.utc).isoformat()
            conf = float(r.get('confidence') or 0.0)
            reason = r.get('reason') or ''
            if not sym or side not in ('BUY','SELL') or entry is None or sl is None:
                continue
            norm.append({'trading_symbol': sym, 'side': side, 'entry': entry, 'stop_loss': sl, 'take_profit': tp,
                         'position_size': pos, 'risk_perc': risk, 'signal_time': stime, 'confidence': conf, 'reason': reason})
        except Exception:
            continue
    return pd.DataFrame(norm)

def score_signal_simple(row: pd.Series, backtest_map: dict) -> float:
    c = float(row.get('confidence') or 0.0)
    score = max(0.0, min(1.0, c))
    sym = str(row.get('trading_symbol') or '').strip().upper()
    if sym and backtest_map and sym in backtest_map:
        try:
            wr = float(backtest_map[sym].get('win_rate') or 0.0)
            score = score * (1.0 + 0.5 * max(0.0, min(1.0, wr/100.0)))
        except Exception:
            pass
    return float(score)

def pick_top_n_generated(df: pd.DataFrame, backtest_map: dict, top_n: int = 5) -> pd.DataFrame:
    if df.empty:
        return df
    df2 = df.copy()
    df2['_score'] = df2.apply(lambda r: score_signal_simple(r, backtest_map), axis=1)
    df2 = df2.sort_values(by=['_score', 'confidence'], ascending=[False, False])
    return df2.head(top_n)

# ---------------- MAIN ---------------- #

def main():
    p = argparse.ArgumentParser(description='Generate future signals using Azure LLM + history/features')
    p.add_argument('--top', type=int, default=5)
    p.add_argument('--dry-run', action='store_true')
    args = p.parse_args()

    # Load historical features
    hist = pd.read_csv(HIST_PATH, dtype=str) if os.path.exists(HIST_PATH) else pd.DataFrame()
    features = compute_features_from_history(hist)

    # Determine symbols from actionable CSV or per-symbol files
    symbols = []
    if os.path.exists(COMBINED_ACTIONABLE):
        try:
            cand = pd.read_csv(COMBINED_ACTIONABLE, dtype=str)
            symbols = list(cand['trading_symbol'].astype(str).str.strip().str.upper().unique())
        except:
            pass
    if not symbols:
        for f in glob.glob(PER_SYMBOL_SIGNALS_GLOB):
            name = os.path.basename(f).split('_signals.csv')[0]
            symbols.append(name.strip().upper())
    if not symbols:
        print('No symbols found')
        return

    # Collect recent per-symbol signals
    recent_map = {s: read_recent_elliott_signals(OUT_DIR, s) for s in symbols}

    # Load simple backtest map if exists
    backmap = {}
    backtest_file = os.path.join(OUT_DIR, 'backtest_results_from_actionable.csv')
    if os.path.exists(backtest_file):
        try:
            bdf = pd.read_csv(backtest_file, dtype=str)
            for _, r in bdf.iterrows():
                key = str(r.get('trading_symbol') or r.get('symbol') or '').strip().upper()
                if key:
                    backmap[key] = {'win_rate': float(r.get('win_rate') or 0), 'avg_rr': float(r.get('avg_rr') or 0)}
        except:
            pass

    # Build prompt
    prompt = build_prompt_for_symbols(symbols, features, recent_map, top_n=args.top)

    # Call Azure
    generated_df = pd.DataFrame()
    if AZ_KEY and AZ_ENDPOINT and AZ_DEPLOY:
        try:
            content = call_azure_chat_simple(prompt, AZ_DEPLOY, AZ_KEY, AZ_ENDPOINT)
            recs = extract_json_from_model(content)
            gen = validate_and_normalize_candidates(recs)
            if not gen.empty:
                generated_df = gen
        except Exception as e:
            print('Azure generation failed:', e)
    else:
        print('Azure not configured - no generation performed.')

    if generated_df.empty:
        print('No generated signals')
        return

    # Save generated candidates
    if not args.dry_run:
        generated_df.to_csv(OUT_GENERATED, index=False)
        print('Wrote generated candidates ->', OUT_GENERATED)

    # Pick top-N
    topn = pick_top_n_generated(generated_df, backmap, top_n=args.top)
    if not topn.empty and not args.dry_run:
        topn.to_csv(OUT_BEST, index=False)
        print('Wrote selected top signals ->', OUT_BEST)
    print(topn.to_string(index=False))

if __name__ == '__main__':
    main()
