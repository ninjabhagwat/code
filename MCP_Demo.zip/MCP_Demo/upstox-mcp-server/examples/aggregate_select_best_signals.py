r"""
examples/aggregate_select_best_signals.py

Read per-symbol signals and combined actionable_signals in
`elliott-wave-indicator/examples/outputs/` and select the best future signal per symbol.
The script uses simple, explainable heuristics based on:
 - prefer confirmed signals
 - prefer higher model confidence
 - boost confidence using backtest stats (if available) from backtest_results_from_actionable.csv
 - require entry and stop_loss (or sensible fallback) and sensible prices

Writes:

 - actionable_signals_best.csv in the same outputs folder (top-N best overall signals)
 - prints a short summary

Usage (PowerShell):
  python .\upstox-mcp-server\examples\aggregate_select_best_signals.py --top 5

No arguments required; paths are discovered from repository layout.
"""

import os
import json
import math
import re
import argparse
import pandas as pd
from datetime import datetime, timezone
import requests

OUT_DIR = r'C:\Niranjan\Personal\MCP_Demo\upstox-mcp-server\elliott-wave-indicator\examples\outputs'
PER_SYMBOL_GLOB = os.path.join(OUT_DIR, '*_signals.csv')
COMBINED_ACTIONABLE = os.path.join(OUT_DIR, 'actionable_signals.csv')
BACKTEST_RESULTS = os.path.join(OUT_DIR, 'backtest_results_from_actionable.csv')
OUTPUT_BEST = os.path.join(OUT_DIR, 'actionable_signals_best.csv')

# Azure OpenAI configuration (optional). Script will use Azure only if env vars are set.
AZ_KEY = os.getenv('AZURE_OPENAI_KEY') or os.getenv('AZURE_OPENAI_API_KEY')
AZ_ENDPOINT = os.getenv('AZURE_OPENAI_ENDPOINT')
AZ_DEPLOY = os.getenv('AZURE_OPENAI_DEPLOYMENT') or os.getenv('AZURE_OPENAI_DEPLOYMENT_VERSION')
AZ_API_VERSION = os.getenv('AZURE_OPENAI_API_VERSION', '2023-05-15')


def load_all_signals(outputs_dir: str) -> pd.DataFrame:
    # read combined actionable if exists, otherwise read per-symbol files
    dfs = []
    if os.path.exists(COMBINED_ACTIONABLE):
        try:
            df = pd.read_csv(COMBINED_ACTIONABLE, dtype=str)
            dfs.append(df)
        except Exception:
            pass
    # load all per-symbol *_signals.csv files as fallback/augmentation
    import glob
    for p in glob.glob(PER_SYMBOL_GLOB):
        try:
            df = pd.read_csv(p, dtype=str)
            dfs.append(df)
        except Exception:
            continue
    if not dfs:
        return pd.DataFrame()
    alldf = pd.concat(dfs, ignore_index=True, sort=False)
    return alldf


def normalize_df(df: pd.DataFrame) -> pd.DataFrame:
    # ensure canonical columns and types
    if df.empty:
        return df
    df = df.copy()
    # normalize symbol column name
    sym_cols = [c for c in df.columns if c.lower() in ('trading_symbol','tradingsymbol','symbol','ticker','asset_symbol')]
    if sym_cols:
        df['trading_symbol'] = df[sym_cols[0]]
    else:
        df['trading_symbol'] = df.get('trading_symbol', '')

    # numeric fields
    for c in ('entry','stop_loss','take_profit','confidence'):
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors='coerce')
        else:
            df[c] = pd.NA

    # confirmed flag
    if 'confirmed' in df.columns:
        df['confirmed'] = df['confirmed'].astype(str).str.lower().isin(('1','true','yes','y','t'))
    else:
        df['confirmed'] = False

    # ensure signal_time
    if 'signal_time' not in df.columns:
        df['signal_time'] = datetime.now(timezone.utc).isoformat()
    return df


def load_backtest_map(path: str) -> dict:
    if not os.path.exists(path):
        return {}
    try:
        bdf = pd.read_csv(path, dtype=str)
    except Exception:
        return {}
    mapping = {}
    # attempt common columns: trading_symbol/symbol and win_rate/accuracy/avg_rr
    for _, r in bdf.iterrows():
        sym = None
        for c in r.index:
            if c.lower() in ('trading_symbol','symbol','tradingsymbol','ticker'):
                sym = str(r[c]).strip().upper()
                break
        if not sym:
            continue
        try:
            win = float(r.get('win_rate') or r.get('winrate') or r.get('accuracy') or r.get('win_pct') or 0)
        except Exception:
            win = 0.0
        try:
            rr = float(r.get('avg_rr') or r.get('rr') or 0)
        except Exception:
            rr = 0.0
        mapping[sym] = {'win_rate': win, 'avg_rr': rr}
    return mapping


def score_signal(row: pd.Series, backtest_map: dict) -> float:
    # base score = confidence (0-1) with fallback
    c = float(row.get('confidence') or 0.0)
    conf = max(0.0, min(1.0, c))
    score = conf
    # boost if confirmed
    if row.get('confirmed'):
        score += 0.25
    # apply backtest boost (win_rate in 0-100 -> normalize to 0-1)
    sym = str(row.get('trading_symbol') or '').strip().upper()
    if sym and sym in backtest_map:
        try:
            wr = float(backtest_map[sym].get('win_rate') or 0.0)
            wr_norm = max(0.0, min(1.0, wr/100.0))
            score = score * (1.0 + 0.5 * wr_norm)
        except Exception:
            pass
    # penalize if entry or stop_loss missing or invalid
    entry = row.get('entry')
    sl = row.get('stop_loss')
    try:
        if not (entry and not pd.isna(entry)):
            score *= 0.2
        if not (sl and not pd.isna(sl)):
            score *= 0.6
    except Exception:
        score *= 0.1
    return float(score)


def pick_best_per_symbol(df: pd.DataFrame, backtest_map: dict) -> pd.DataFrame:
    if df.empty:
        return df
    results = []
    for sym, group in df.groupby(df['trading_symbol'].astype(str).str.strip().str.upper()):
        g = group.copy()
        # compute scores
        g['__score'] = g.apply(lambda r: score_signal(r, backtest_map), axis=1)
        # sort by score desc then confidence desc then most recent signal_time
        if 'signal_time' in g.columns:
            try:
                g['__signal_time_parsed'] = pd.to_datetime(g['signal_time'], errors='coerce')
            except Exception:
                g['__signal_time_parsed'] = pd.NaT
        else:
            g['__signal_time_parsed'] = pd.NaT
        g = g.sort_values(by=['__score','confidence','__signal_time_parsed'], ascending=[False, False, False])
        top = g.iloc[0].to_dict()
        top['_selected_score'] = float(g.iloc[0]['__score'])
        results.append(top)
    if not results:
        return pd.DataFrame()
    out = pd.DataFrame(results)
    # ensure columns order
    cols = ['trading_symbol','side','entry','stop_loss','take_profit','position_size','risk_perc','signal_time','confidence']
    for c in cols:
        if c not in out.columns:
            out[c] = ''
    # keep additional metadata
    out['_selected_score'] = out.get('_selected_score', 0.0)
    return out[cols + ['_selected_score']]


def pick_top_n_overall(df: pd.DataFrame, backtest_map: dict, top_n: int = 5) -> pd.DataFrame:
    """Score all candidate signals and return the top N overall across all symbols."""
    if df.empty:
        return df
    g = df.copy()
    g['__score'] = g.apply(lambda r: score_signal(r, backtest_map), axis=1)
    if 'signal_time' in g.columns:
        try:
            g['__signal_time_parsed'] = pd.to_datetime(g['signal_time'], errors='coerce')
        except Exception:
            g['__signal_time_parsed'] = pd.NaT
    else:
        g['__signal_time_parsed'] = pd.NaT
    g = g.sort_values(by=['__score','confidence','__signal_time_parsed'], ascending=[False, False, False])
    top = g.head(top_n).copy()
    if top.empty:
        return pd.DataFrame()
    top['_selected_score'] = top['__score'].astype(float)
    # ensure columns order
    cols = ['trading_symbol','side','entry','stop_loss','take_profit','position_size','risk_perc','signal_time','confidence']
    for c in cols:
        if c not in top.columns:
            top[c] = ''
    return top[cols + ['_selected_score']].reset_index(drop=True)


def extract_json_from_model(text: str) -> list:
    """Attempt to extract JSON array from model text."""
    txt = str(text).strip()
    try:
        j = json.loads(txt)
        if isinstance(j, list):
            return j
        if isinstance(j, dict):
            return [j]
    except Exception:
        pass
    # regex fallback
    m = re.search(r"(\[\s*\{.*\}\s*\])", txt, flags=re.S)
    if m:
        try:
            return json.loads(m.group(1))
        except Exception:
            pass
    if '[' in txt and ']' in txt:
        try:
            start = txt.index('[')
            end = txt.rindex(']')
            return json.loads(txt[start:end+1])
        except Exception:
            pass
    raise ValueError('Unable to extract JSON array from model output')


def filter_candidates_for_today(df: pd.DataFrame, require_future: bool = True) -> pd.DataFrame:
    """Return subset of df where signal_time is on the current UTC date and optionally >= now.

    Expects `signal_time` to be an ISO timestamp; rows with unparseable times are removed.
    """
    if df.empty:
        return df
    d = df.copy()
    # parse to UTC datetimes
    try:
        d['__signal_dt'] = pd.to_datetime(d['signal_time'], errors='coerce', utc=True)
    except Exception:
        d['__signal_dt'] = pd.NaT
    now_utc = datetime.now(timezone.utc)
    # keep rows whose date equals today (UTC)
    mask = d['__signal_dt'].notna() & (d['__signal_dt'].dt.date == now_utc.date())
    if require_future:
        mask = mask & (d['__signal_dt'] >= now_utc)
    out = d[mask].copy()
    if out.empty:
        return pd.DataFrame()
    # drop helper column
    out = out.drop(columns=['__signal_dt'])
    return out


def filter_upcoming_signals(df: pd.DataFrame, require_future: bool = True, include_missing: bool = True) -> pd.DataFrame:
    """Return subset of df where signal_time is >= now (UTC).

    Rows with unparseable or missing times are removed unless include_missing=True, in which case they are
    treated as 'upcoming' (included).
    """
    if df.empty:
        return df
    d = df.copy()
    try:
        d['__signal_dt'] = pd.to_datetime(d.get('signal_time'), errors='coerce', utc=True)
    except Exception:
        d['__signal_dt'] = pd.NaT
    now_utc = datetime.now(timezone.utc)
    if require_future:
        if include_missing:
            # include rows with missing/unparseable signal_time as candidates
            mask = (d['__signal_dt'].isna()) | (d['__signal_dt'] >= now_utc)
        else:
            mask = d['__signal_dt'].notna() & (d['__signal_dt'] >= now_utc)
    else:
        if include_missing:
            mask = d['__signal_dt'].isna() | d['__signal_dt'].notna()
        else:
            mask = d['__signal_dt'].notna()
    out = d[mask].copy()
    if out.empty:
        return pd.DataFrame()
    out = out.drop(columns=['__signal_dt'])
    return out


def call_azure_chat_simple(prompt: str, deployment: str, api_key: str, endpoint: str, api_version: str = AZ_API_VERSION) -> str:
    """Call Azure OpenAI chat completions (simple wrapper)."""
    if not (api_key and endpoint and deployment):
        raise RuntimeError('Azure OpenAI not configured (missing key/endpoint/deployment)')
    url = endpoint.rstrip('/') + f"/openai/deployments/{deployment}/chat/completions?api-version={api_version}"
    headers = {'api-key': api_key, 'Content-Type': 'application/json'}
    body = {
        'messages': [
            {'role': 'system', 'content': 'You are a strict selector that returns only a JSON array of best signals when given candidates.'},
            {'role': 'user', 'content': prompt}
        ],
        'max_tokens': 500,
        'temperature': 0.0,
        'n': 1
    }
    r = requests.post(url, headers=headers, json=body, timeout=60)
    r.raise_for_status()
    j = r.json()
    try:
        return j['choices'][0]['message']['content']
    except Exception:
        return json.dumps(j)


def ask_azure_to_select_best(candidates_df: pd.DataFrame, backtest_map: dict, top_n: int = 5, max_per_symbol: int = 5) -> pd.DataFrame:
    """Send candidates to Azure to pick the best signals overall (up to top_n). Returns DataFrame or empty on failure."""
    if candidates_df.empty:
        return pd.DataFrame()
    # build compact prompt: include candidates (limited) and ask for top_n overall
    symbols = sorted(candidates_df['trading_symbol'].astype(str).str.strip().str.upper().unique())
    prompt = (
        f'You are given candidate trading signals for multiple symbols.\n'
        f'Return a JSON array of up to {top_n} best signals overall (across symbols) using the schema:\n'
        f'trading_symbol, side, entry, stop_loss, take_profit, position_size, risk_perc, signal_time, confidence, reason\n'
        f'Only return the JSON array, no explanation.\n'
    )
    # include sample candidates to help the model
    sample_rows = []
    for s in symbols:
        rows = candidates_df[candidates_df['trading_symbol'].str.strip().str.upper() == s]
        sample = rows.head(max_per_symbol).to_dict(orient='records')
        if sample:
            prompt += f"\nSymbol: {s} - Candidates:\n" + json.dumps(sample) + "\n"
            sample_rows.extend(sample)
        if s in backtest_map:
            prompt += f"Backtest summary: {json.dumps(backtest_map[s])}\n"
    # also include a short summary table of all candidates (compact)
    try:
        prompt += "\nAll candidates summary:\n" + json.dumps(sample_rows)
    except Exception:
        pass
    # call Azure
    try:
        content = call_azure_chat_simple(prompt, AZ_DEPLOY, AZ_KEY, AZ_ENDPOINT, AZ_API_VERSION)
        records = extract_json_from_model(content)
        # normalize to dataframe
        norm = []
        for r in records:
            if not isinstance(r, dict):
                continue
            rec = {
                'trading_symbol': r.get('trading_symbol') or r.get('symbol'),
                'side': (r.get('side') or 'BUY').upper(),
                'entry': float(r.get('entry')) if r.get('entry') not in (None, '') else None,
                'stop_loss': float(r.get('stop_loss')) if r.get('stop_loss') not in (None, '') else None,
                'take_profit': float(r.get('take_profit')) if r.get('take_profit') not in (None, '') else None,
                'position_size': int(r.get('position_size')) if r.get('position_size') not in (None, '') else '',
                'risk_perc': float(r.get('risk_perc')) if r.get('risk_perc') not in (None, '') else '',
                'signal_time': r.get('signal_time') or datetime.now(timezone.utc).isoformat(),
                'confidence': float(r.get('confidence')) if r.get('confidence') not in (None, '') else 0.0,
                'reason': r.get('reason') or ''
            }
            norm.append(rec)
        if not norm:
            return pd.DataFrame()
        out = pd.DataFrame(norm)
        # limit to top_n if model returned more
        out = out.head(top_n)
        return out
    except Exception as e:
        print('Azure selection failed:', e)
        return pd.DataFrame()


def ask_azure_to_generate_signals_from_history(outputs_dir: str, symbols: list = None, backtest_map: dict = None, per_symbol_history: int = 20, max_new: int = 50) -> pd.DataFrame:
    """Ask Azure to generate new actionable future signals based on recent historical signals stored in outputs_dir.

    Returns DataFrame of generated candidate signals or empty DataFrame on failure.
    """
    if not (AZ_KEY and AZ_ENDPOINT and AZ_DEPLOY):
        raise RuntimeError('Azure OpenAI not configured (missing key/endpoint/deployment)')
    import glob
    # collect symbol history samples
    samples = {}
    if symbols is None:
        # discover symbols from per-symbol files
        files = glob.glob(os.path.join(outputs_dir, '*_signals.csv'))
        symbols = [os.path.basename(f).split('_signals.csv')[0] for f in files]
    for s in sorted(set(symbols)):
        path = os.path.join(outputs_dir, f'{s}_signals.csv')
        if not os.path.exists(path):
            continue
        try:
            hdf = pd.read_csv(path, dtype=str)
            # take last N rows as history
            sample = hdf.tail(per_symbol_history).to_dict(orient='records')
            samples[s] = sample
        except Exception:
            continue
    if not samples:
        return pd.DataFrame()
    # build prompt
    prompt = (
        "You are an expert trading signal generator. You are given recent historical signals for many symbols. "
        "For each symbol, propose up to 1 new actionable future signal for today (UTC) that could be executed now. "
        "Return a JSON array of signals using the schema: trading_symbol, side, entry, stop_loss, take_profit, "
        "position_size, risk_perc, signal_time (ISO), confidence (0-1), reason.\n"
        "Only return the JSON array, no explanation.\n"
    )
    # include short backtest summaries if available
    for s, rows in samples.items():
        prompt += f"\nSymbol: {s} - Recent signals sample:\n" + json.dumps(rows[:5]) + "\n"
        if backtest_map and s in backtest_map:
            prompt += f"Backtest summary: {json.dumps(backtest_map[s])}\n"
    # ask for up to max_new signals overall
    prompt += f"\nReturn up to {max_new} candidate signals overall.\n"
    try:
        content = call_azure_chat_simple(prompt, AZ_DEPLOY, AZ_KEY, AZ_ENDPOINT, AZ_API_VERSION)
        records = extract_json_from_model(content)
        norm = []
        for r in records:
            if not isinstance(r, dict):
                continue
            rec = {
                'trading_symbol': r.get('trading_symbol') or r.get('symbol'),
                'side': (r.get('side') or 'BUY').upper(),
                'entry': float(r.get('entry')) if r.get('entry') not in (None, '') else None,
                'stop_loss': float(r.get('stop_loss')) if r.get('stop_loss') not in (None, '') else None,
                'take_profit': float(r.get('take_profit')) if r.get('take_profit') not in (None, '') else None,
                'position_size': int(r.get('position_size')) if r.get('position_size') not in (None, '') else '',
                'risk_perc': float(r.get('risk_perc')) if r.get('risk_perc') not in (None, '') else '',
                'signal_time': r.get('signal_time') or datetime.now(timezone.utc).isoformat(),
                'confidence': float(r.get('confidence')) if r.get('confidence') not in (None, '') else 0.0,
                'reason': r.get('reason') or 'generated_from_history'
            }
            norm.append(rec)
        if not norm:
            return pd.DataFrame()
        out = pd.DataFrame(norm)
        return out.head(max_new)
    except Exception as e:
        print('Azure generation failed:', e)
        return pd.DataFrame()


def main():
    p = argparse.ArgumentParser(description='Aggregate and pick top-N best signals across all symbols')
    p.add_argument('--top', type=int, default=5, help='Number of top signals to output (default 5)')
    p.add_argument('--no-today', dest='today_only', action='store_false', help='Allow signals from any day (do not restrict to today)')
    p.add_argument('--generate-new', dest='generate_new', action='store_true', help='If no today/future signals exist, ask Azure to generate new signals from history')
    p.add_argument('--no-upcoming', dest='filter_upcoming', action='store_false', help='Do not restrict to upcoming (future) signals from actionable_signals.csv')
    args = p.parse_args()
    top_n = max(1, int(args.top))
    today_only = bool(getattr(args, 'today_only', True))
    generate_new = bool(getattr(args, 'generate_new', False))
    filter_upcoming = bool(getattr(args, 'filter_upcoming', True))

    # Prefer the combined actionable_signals.csv if present; otherwise load all per-symbol files.
    if os.path.exists(COMBINED_ACTIONABLE):
        try:
            df = pd.read_csv(COMBINED_ACTIONABLE, dtype=str)
            df = normalize_df(df)
        except Exception:
            df = normalize_df(load_all_signals(OUT_DIR))
    else:
        allraw = load_all_signals(OUT_DIR)
        if allraw.empty:
            print('No signal files found in outputs; ensure per-symbol *_signals.csv or actionable_signals.csv exist')
            return
        df = normalize_df(allraw)

    # By default prefer upcoming (future) signals from actionable_signals.csv. This selects candidates whose
    # signal_time is >= now (UTC). Use --no-upcoming to disable this filter.
    if filter_upcoming:
        df_up = filter_upcoming_signals(df, require_future=True, include_missing=True)
        if df_up.empty:
            # optionally try generating new signals from history if requested
            if generate_new and AZ_KEY and AZ_ENDPOINT and AZ_DEPLOY:
                print('No upcoming candidates in actionable_signals.csv — attempting to generate new signals from history via Azure...')
                gen = ask_azure_to_generate_signals_from_history(OUT_DIR, backtest_map=load_backtest_map(BACKTEST_RESULTS))
                if not gen.empty:
                    df_up = normalize_df(gen)
                else:
                    print('Azure did not return generated signals')
        if df_up.empty:
            print('No upcoming candidate signals found. Use --no-upcoming to disable upcoming-only filtering or --generate-new to request generation.')
            return
        df = df_up

    backmap = load_backtest_map(BACKTEST_RESULTS)

    # If Azure configured, try Azure selection (ask for top_n overall). Fallback to heuristic top-N.
    best = pd.DataFrame()
    if AZ_KEY and AZ_ENDPOINT and AZ_DEPLOY:
        try:
            best = ask_azure_to_select_best(df, backmap, top_n=top_n)
        except Exception as e:
            print('Azure selection raised exception:', e)
            best = pd.DataFrame()

    if best.empty:
        best = pick_top_n_overall(df, backmap, top_n=top_n)

    if best.empty:
        print('No valid best signals computed')
        return
    best.to_csv(OUTPUT_BEST, index=False)
    print(f'Wrote best actionable signals -> {OUTPUT_BEST} (rows: {len(best)})')
    # also print top N summary
    print(best.sort_values(by='_selected_score', ascending=False).to_string(index=False))


if __name__ == '__main__':
    main()
