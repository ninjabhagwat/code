import os
from openai import AzureOpenAI
from langchain_openai import AzureChatOpenAI
 
api_key = "G21oDrrAhnk5fuaFQuzddeyU2LUCUglnJHWmcvMJyeUBokFzjq2YJQQJ99BHACYeBjFXJ3w3AAAAACOGkmHe"
azure_endpoint = "https://aifoundryattdma.openai.azure.com"
 
HTTP_PROXY="http://genproxy.amdocs.com:8080"
HTTPS_PROXY="http://genproxy.amdocs.com:8080"
 
os.environ["HTTP_PROXY"] = HTTP_PROXY
os.environ["HTTPS_PROXY"] = HTTPS_PROXY
os.environ["http_proxy"] = HTTP_PROXY
os.environ["https_proxy"] = HTTPS_PROXY
 
client = AzureOpenAI(
    azure_endpoint=azure_endpoint,
    api_key=api_key,
    api_version="2025-01-01-preview"
)
 
 
llm = AzureChatOpenAI(
    api_key=api_key,
    azure_endpoint=azure_endpoint,
    api_version="2025-01-01-preview",
    model="gpt-4o-mini"
)
 
res = llm.invoke("Does Azure OpenAI support customer managed keys?")
print(res)