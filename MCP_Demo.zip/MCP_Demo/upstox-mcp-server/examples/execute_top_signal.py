import os
import json
import argparse
from typing import Optional
import requests
import pandas as pd

# ensure .env in project root is loaded so users don't have to set env vars manually
try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(__file__), '..', '.env'))
except Exception:
    # dotenv not installed or .env missing; fall back to environment variables
    pass

# Example: examples/execute_top_signal.py
# Safe, sandbox-first executor: dry-run by default. Uses signals.csv for sizing/SL/TP.

DEFAULT_SCAN_SUMMARY = os.path.join("examples", "outputs", "scan", r'C:\Niranjan\Personal\MCP_Demo\upstox-mcp-server\elliott-wave-indicator\examples\outputs\scan\scan_summary.csv')
DEFAULT_SIGNALS = os.path.join("elliott-wave-indicator", r"C:\Niranjan\Personal\MCP_Demo\upstox-mcp-server\elliott-wave-indicator\examples\outputs\signals.csv")

# Candidate relative paths to search for scan_summary and signals files
CANDIDATE_SCAN_PATHS = [
    os.path.join(os.path.dirname(__file__), '..', 'elliott-wave-indicator', 'examples', 'outputs', 'scan', 'scan_summary.csv'),
    os.path.join(os.path.dirname(__file__), '..', 'examples', 'outputs', 'scan', 'scan_summary.csv'),
    os.path.join(os.getcwd(), 'upstox-mcp-server', 'elliott-wave-indicator', 'examples', 'outputs', 'scan', 'scan_summary.csv'),
    os.path.join(os.getcwd(), 'examples', 'outputs', 'scan', 'scan_summary.csv'),
]

CANDIDATE_SIGNALS_PATHS = [
    os.path.join(os.path.dirname(__file__), '..', 'elliott-wave-indicator', 'examples', 'outputs', 'signals.csv'),
    os.path.join(os.path.dirname(__file__), '..', 'elliott-wave-indicator', 'signals.csv'),
    os.path.join(os.getcwd(), 'upstox-mcp-server', 'elliott-wave-indicator', 'examples', 'outputs', 'signals.csv'),
    os.path.join(os.getcwd(), 'elliott-wave-indicator', 'examples', 'outputs', 'signals.csv'),
]

# Default to sandbox base; override with UPSTOX_BASE_URL env var for live use only after testing
BASE_URL = os.getenv("UPSTOX_BASE_URL", "https://sandbox-api.upstox.com")
TOKEN = os.getenv("UPSTOX_ACCESS_TOKEN")


def find_first_existing(candidates):
    for p in candidates:
        try:
            ab = os.path.abspath(p)
            if os.path.exists(ab):
                return ab
        except Exception:
            continue
    return None


def load_signals_symbols(signals_csv: str):
    if not signals_csv or not os.path.exists(signals_csv):
        return set()
    df = pd.read_csv(signals_csv, parse_dates=[0])
    if 'trading_symbol' in df.columns:
        return set(df['trading_symbol'].dropna().astype(str).unique())
    if 'symbol' in df.columns:
        return set(df['symbol'].dropna().astype(str).unique())
    return set()


def load_top_symbol(scan_csv: str, signals_csv: Optional[str] = None) -> Optional[str]:
    """Select top-ranked symbol from scan_summary that also appears in signals_csv if possible.
    Falls back to top of scan_summary or most-recent symbol from signals_csv.
    """
    scan_path = scan_csv or find_first_existing(CANDIDATE_SCAN_PATHS)
    signals_path = signals_csv or find_first_existing(CANDIDATE_SIGNALS_PATHS)

    signals_symbols = load_signals_symbols(signals_path)

    if scan_path and os.path.exists(scan_path):
        df = pd.read_csv(scan_path)
        if df.empty:
            return None
        sort_cols = [c for c in ("win_ratio", "total_net_pnl") if c in df.columns]
        df = df.sort_values(sort_cols, ascending=[False] * len(sort_cols)) if sort_cols else df
        # determine symbol column name
        sym_col = 'symbol' if 'symbol' in df.columns else ('trading_symbol' if 'trading_symbol' in df.columns else df.columns[0])
        if signals_symbols:
            # filter to symbols present in signals
            df_filtered = df[df[sym_col].astype(str).isin(signals_symbols)]
            if not df_filtered.empty:
                return str(df_filtered.iloc[0][sym_col])
        # fallback: return top-ranked symbol from scan
        return str(df.iloc[0][sym_col])

    # if no scan summary, pick most recent symbol from signals (if available)
    if signals_path and os.path.exists(signals_path):
        dfsig = pd.read_csv(signals_path, parse_dates=[0])
        # assume trading_symbol column exists
        col = 'trading_symbol' if 'trading_symbol' in dfsig.columns else ('symbol' if 'symbol' in dfsig.columns else None)
        if col:
            dfsig = dfsig.dropna(subset=[col])
            if not dfsig.empty:
                # pick most recent
                dfsig = dfsig.sort_values(by=dfsig.columns[0])
                return str(dfsig.iloc[-1][col])
    return None


def load_latest_signal_for_symbol(signals_csv: str, symbol: str) -> Optional[dict]:
    if not os.path.exists(signals_csv):
        print(f"signals file not found: {signals_csv}")
        return None
    # many signals files include timezone-aware datetimes; don't require trading_symbol column
    df = pd.read_csv(signals_csv, parse_dates=[0])
    # try common symbol columns
    if "trading_symbol" in df.columns:
        sel = df[df["trading_symbol"] == symbol]
    elif "symbol" in df.columns:
        sel = df[df["symbol"] == symbol]
    else:
        # assume signals file holds signals for the asset of interest
        sel = df
    if sel.empty:
        print(f"No signals found for symbol {symbol} in {signals_csv}")
        return None
    sel = sel.sort_values(by=sel.columns[0])
    row = sel.iloc[-1].to_dict()
    # normalize keys to common names
    normalized = {
        "signal_time": row.get("signal_time") or row.get("datetime"),
        "side": (row.get("side") or "BUY").upper(),
        "entry": float(row.get("entry")),
        "sl": float(row.get("stop_loss") or row.get("stoploss") or row.get("stop_loss")) if row.get("stop_loss") or row.get("stoploss") else None,
        "tp": float(row.get("take_profit") or row.get("takeprofit")) if (row.get("take_profit") or row.get("takeprofit")) else None,
        "position_size": row.get("position_size"),
        "confidence": row.get("confidence"),
        "symbol": symbol,
    }
    return normalized


def compute_qty_from_signal(account_size: float, risk_perc: float, entry: float, sl: Optional[float], sig_pos_size) -> int:
    # If signals.csv provides a numeric position_size, prefer it.
    if sig_pos_size is not None and sig_pos_size != "":
        try:
            ps = float(sig_pos_size)
            # If position_size is >= 1 treat it as desired quantity (round to nearest int)
            if ps >= 1:
                qty = int(round(ps))
                print(f"Using position_size from signal as qty: {ps} -> {qty}")
                return max(qty, 0)
            # If position_size < 1 treat as cash allocation (fractional cash amount)
            qty = int(ps // entry) if entry > 0 else 0
            print(f"Using position_size from signal as cash allocation: {ps} -> qty {qty} at entry {entry}")
            return max(qty, 0)
        except Exception:
            pass
    # fallback: compute by risk percent using stoploss distance
    if sl is None or entry is None:
        print("Missing SL or entry for risk-based sizing")
        return 0
    risk_amount = account_size * (risk_perc / 100.0)
    per_unit_risk = abs(entry - sl)
    if per_unit_risk <= 0:
        print("Per-unit risk computed as zero or negative")
        return 0
    qty = int(risk_amount // per_unit_risk)
    max_by_cash = int(account_size // entry) if entry > 0 else 0
    qty = max(0, min(qty, max_by_cash))
    print(f"Risk-based sizing: account_size={account_size}, risk_perc={risk_perc}, risk_amount={risk_amount}, per_unit_risk={per_unit_risk} -> qty={qty} (cap by cash {max_by_cash})")
    return qty


def build_place_order_payload(signal: dict, qty: int, product_type: str = "NRML") -> dict:
    # IMPORTANT: Upstox requires instrument token or instrument_key. You should resolve symbol->instrument_key
    # using Instruments API. This script prepares a minimal payload; adapt fields per your account/product.
    side = "BUY" if signal.get("side", "BUY").upper().startswith("B") else "SELL"
    payload = {
        "symbol": signal.get("symbol"),
        "quantity": qty,
        "price": signal.get("entry"),
        "order_type": "LIMIT",
        "product": product_type,
        "side": side,
        "time_in_force": "GTC",
        # optionally include extra helpful metadata
        "meta": {
            "source": "elliott-scanner",
            "signal_time": str(signal.get("signal_time")),
        }
    }
    # If stoploss/takeprofit are present and you want bracket orders, Upstox supports bracket params - add them only when requested.
    return payload


def place_order(api_base: str, token: str, payload: dict) -> dict:
    endpoint = api_base.rstrip("/") + "/v3/place-order"
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json", "Accept": "application/json"}
    r = requests.post(endpoint, headers=headers, json=payload, timeout=20)
    try:
        r.raise_for_status()
    except Exception:
        print("Order failed:", r.status_code, r.text)
        raise
    return r.json()


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--scan-summary", default=DEFAULT_SCAN_SUMMARY)
    p.add_argument("--signals", default=DEFAULT_SIGNALS)
    p.add_argument("--symbol", default=None)
    p.add_argument("--account-size", type=float, default=10000.0)
    p.add_argument("--risk-perc", type=float, default=1.0)
    p.add_argument("--product", choices=["NRML", "MIS", "CNC"], default="NRML")
    p.add_argument("--dry-run", action="store_true", default=True, help="Do not execute orders; show payload")
    p.add_argument("--place-sl-tp", action="store_true", default=False, help="Also attempt to place SL/TP orders after main order (use with caution)")
    args = p.parse_args()

    chosen_symbol = args.symbol or load_top_symbol(args.scan_summary, args.signals)
    if not chosen_symbol:
        print("No symbol selected. Provide --symbol or create scan_summary.")
        raise SystemExit(1)
    print("Chosen symbol:", chosen_symbol)

    sig = load_latest_signal_for_symbol(args.signals, chosen_symbol)
    if not sig:
        raise SystemExit(1)

    # Prefer values from the signal for sizing and risk
    entry = sig.get("entry")
    sl = sig.get("sl")
    tp = sig.get("tp")
    sig_pos = sig.get("position_size")

    # detect risk_perc in the signal (allow several common keys)
    risk_from_sig = None
    for rk in ("risk_perc", "risk", "risk_pct", "risk_percent"):
        if rk in sig and sig.get(rk) not in (None, ""):
            try:
                risk_from_sig = float(sig.get(rk))
                break
            except Exception:
                risk_from_sig = None

    # prefer the signal's risk percentage when available; otherwise fall back to CLI
    effective_risk_perc = float(risk_from_sig) if risk_from_sig is not None else float(args.risk_perc)
    print(f"Using risk_perc={effective_risk_perc} (from_signal={risk_from_sig is not None})")

    qty = compute_qty_from_signal(args.account_size, effective_risk_perc, entry, sl, sig_pos)

    if qty <= 0:
        print("Quantity computed as 0. Check account-size, risk-perc, entry and stop loss or provide position_size in signals.csv")
        raise SystemExit(1)

    order_payload = build_place_order_payload(sig, qty, product_type=args.product)
    print("Prepared order payload (will not be sent unless --dry-run False and UPSTOX_ACCESS_TOKEN set):")
    print(json.dumps(order_payload, indent=2))

    if args.dry_run:
        print("Dry-run - exiting. Remove --dry-run to execute (test in sandbox first).")
        raise SystemExit(0)

    if not TOKEN:
        print("UPSTOX_ACCESS_TOKEN env var is required to execute. Obtain a sandbox token and set it in the environment.")
        raise SystemExit(1)

    print("Placing order to:", BASE_URL)
    resp = place_order(BASE_URL, TOKEN, order_payload)
    print("Order response:", json.dumps(resp, indent=2))

    # Optional: place SL/TP as separate orders (very broker-specific). Use with caution.
    if args.place_sl_tp and (sl is not None or tp is not None):
        print("Placing SL/TP orders (separate conditional orders). This behavior is highly broker-specific; verify in sandbox.)")
        # Implementers should translate symbol->instrument_key and use correct stop/limit order types per Upstox docs.
        # This script leaves the exact SL/TP implementation as an exercise to avoid accidental live losses.
        pass