from matplotlib import pyplot as plt
import numpy as np
import pandas as pd
import os

def plot_elliott_waves(prices, waves, signals=None, title='Elliott Waves', xlabel='Time', ylabel='Price', save_path=None):
    plt.figure(figsize=(12, 6))

    # Normalize prices input to a pandas Series of numeric values
    if isinstance(prices, pd.DataFrame):
        if 'close' in prices.columns:
            series = prices['close']
        else:
            # pick first numeric column
            numeric_cols = prices.select_dtypes(include=[np.number]).columns
            if len(numeric_cols) > 0:
                series = prices[numeric_cols[0]]
            else:
                # fallback: try first column
                series = prices.iloc[:, 0]
    elif isinstance(prices, pd.Series):
        series = prices
    else:
        # assume sequence-like
        series = pd.Series(list(prices))

    # Ensure numeric y-values for plotting
    try:
        y_vals = series.astype(float).values
    except Exception:
        # attempt coercion with to_numeric
        y_vals = pd.to_numeric(series, errors='coerce').values

    x_vals = series.index

    plt.plot(x_vals, y_vals, label='Price', color='blue')

    # Helper to map wave x entries to actual x-axis coordinates
    def map_x_item(item):
        # If item is integer, treat it as positional index into series
        try:
            if isinstance(item, (int, np.integer)):
                if 0 <= int(item) < len(x_vals):
                    return x_vals[int(item)]
                # negative indices allowed
                if -len(x_vals) <= int(item) < 0:
                    return x_vals[int(item)]
        except Exception:
            pass
        # otherwise, return the item itself (could be a datetime or matching index label)
        return item

    # Plot each wave ensuring x and y are compatible with the axis
    for wave in waves:
        wx = wave.get('x', [])
        wy = wave.get('y', [])

        # map x coordinates
        plot_x = [map_x_item(v) for v in wx]

        # coerce y values to numeric
        try:
            plot_y = [float(v) for v in wy]
        except Exception:
            plot_y = pd.to_numeric(pd.Series(wy), errors='coerce').tolist()

        # only plot if lengths match and at least 2 points
        if len(plot_x) == len(plot_y) and len(plot_x) >= 2:
            plt.plot(plot_x, plot_y, label=f'Wave {wave.get("label","?")}', linestyle='--')

    # If signals provided, plot entries, stops and take-profits
    if signals is not None:
        try:
            sig_df = signals if isinstance(signals, pd.DataFrame) else pd.DataFrame(signals)

            # normalize signal_time to datetime and drop obviously invalid times
            if 'signal_time' in sig_df.columns:
                sig_df['signal_time'] = pd.to_datetime(sig_df['signal_time'], errors='coerce')

            # Map signals to positions in the price series and filter out ones outside the visible range
            mapped = []
            for _, row in sig_df.iterrows():
                side = str(row.get('side', '')).upper()
                entry = row.get('entry')
                stop = row.get('stop_loss') if 'stop_loss' in row else row.get('stop')
                tp = row.get('take_profit')
                ts = row.get('signal_time') if 'signal_time' in row else None

                pos = None
                timestamp = None
                try:
                    if pd.notna(ts):
                        # find nearest position in series index
                        pos_arr = series.index.get_indexer([pd.to_datetime(ts)], method='nearest')
                        if len(pos_arr) and pos_arr[0] >= 0:
                            pos = int(pos_arr[0])
                            timestamp = series.index[pos]
                    else:
                        # fallback: nearest price match by entry value
                        if entry is not None:
                            entry_f = float(entry)
                            # compute argmin on y_vals
                            idx_closest = int(np.nanargmin(np.abs(y_vals - entry_f)))
                            pos = idx_closest
                            timestamp = series.index[pos]
                except Exception:
                    pos = None

                # ensure pos is within range
                if pos is None or pos < 0 or pos >= len(series):
                    continue

                mapped.append({'pos': pos, 'timestamp': timestamp, 'side': side, 'entry': float(entry) if entry is not None else None, 'stop': float(stop) if stop is not None else None, 'tp': float(tp) if tp is not None else None, 'confidence': float(row.get('confidence', 0.0)), 'entry_type': row.get('entry_type'), 'wave_type': row.get('wave_type')})

            if len(mapped) == 0:
                raise ValueError('no valid signals mapped to price index')

            mapped_df = pd.DataFrame(mapped)

            # Limit to top-N signals by confidence to reduce clutter
            top_n = 12
            if 'confidence' in mapped_df.columns:
                mapped_df = mapped_df.sort_values('confidence', ascending=False).drop_duplicates(subset=['pos']).head(top_n)
            else:
                mapped_df = mapped_df.drop_duplicates(subset=['pos']).head(top_n)

            plotted_signal_labels = set()

            # small delta for short TP horizontal segments (in index units)
            delta_idx = max(1, int(len(x_vals) * 0.02))

            for _, srow in mapped_df.iterrows():
                pos = int(srow['pos'])
                x_signal = series.index[pos]
                entry = srow['entry']
                stop = srow['stop']
                tp = srow['tp']
                side = srow['side']

                try:
                    if side == 'BUY':
                        m = '^'
                        c = 'green'
                    else:
                        m = 'v'
                        c = 'red'

                    plt.scatter([x_signal], [float(entry)], marker=m, color=c, zorder=5, s=80)

                    # draw short vertical line between entry and stop
                    if stop is not None:
                        try:
                            plt.vlines(x_signal, ymin=float(stop), ymax=float(entry), colors=c, linestyles='dotted', linewidth=1.5)
                        except Exception:
                            pass

                    # draw short horizontal segment for TP around the signal time to avoid full-plot lines
                    if tp is not None:
                        try:
                            left = max(0, pos - delta_idx)
                            right = min(len(series) - 1, pos + delta_idx)
                            plt.hlines(float(tp), xmin=series.index[left], xmax=series.index[right], colors='orange', linestyles='dashdot', alpha=0.6)
                            plt.scatter([x_signal], [float(tp)], marker='o', edgecolors='black', facecolors='none', zorder=5, s=60)
                        except Exception:
                            pass

                    label = f"Signal {side}"
                    if label not in plotted_signal_labels:
                        plt.plot([], [], marker=m, color=c, label=label)
                        plotted_signal_labels.add(label)
                except Exception:
                    continue
        except Exception:
            # if signals cannot be plotted, ignore to avoid breaking the main plot
            pass

    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.legend()
    plt.grid()

    # If a save path is provided, save and close the figure instead of showing it interactively
    if save_path:
        try:
            os.makedirs(os.path.dirname(save_path), exist_ok=True)
            plt.tight_layout()
            plt.savefig(save_path)
        finally:
            plt.close()
        return

    plt.show()