import pandas as pd
import numpy as np

class ElliottWaveIndicator:
    def __init__(self):
        # no-arg constructor so tests can instantiate without data
        self.waves = []

    def calculate_waves(self, ohlc_data, volume_data):
        """
        Simple placeholder implementation that detects local peaks and troughs
        and returns a list of wave dicts. Both ohlc_data and volume_data are
        required (tests expect ValueError when either is None).
        Accepts a pandas.DataFrame or a list of dicts with keys 'open','high','low','close','volume'.
        """
        if ohlc_data is None:
            raise ValueError("ohlc_data must be provided")
        if volume_data is None:
            raise ValueError("volume_data must be provided")

        # normalize prices sequence
        if isinstance(ohlc_data, pd.DataFrame):
            if 'close' in ohlc_data.columns:
                prices = list(ohlc_data['close'].astype(float).values)
                x = list(ohlc_data.index)
            else:
                # fall back to first numeric column
                prices = list(ohlc_data.select_dtypes(include=['number']).iloc[:, 0].astype(float).values)
                x = list(range(len(prices)))
        elif isinstance(ohlc_data, list):
            prices = []
            for row in ohlc_data:
                if isinstance(row, dict):
                    prices.append(float(row.get('close', row.get('price', 0))))
                else:
                    prices.append(float(row))
            x = list(range(len(prices)))
        else:
            # try to coerce sequence
            try:
                prices = [float(v) for v in ohlc_data]
                x = list(range(len(prices)))
            except Exception:
                raise ValueError("Unsupported ohlc_data format")

        waves = []
        # detect simple local extrema (exclude endpoints)
        for i in range(1, len(prices) - 1):
            prev_p = prices[i - 1]
            cur_p = prices[i]
            next_p = prices[i + 1]
            if cur_p > prev_p and cur_p > next_p:
                waves.append({
                    'type': 'peak',
                    'index': i,
                    'label': len(waves) + 1,
                    'x': [x[i - 1], x[i], x[i + 1]],
                    'y': [prev_p, cur_p, next_p],
                })
            elif cur_p < prev_p and cur_p < next_p:
                waves.append({
                    'type': 'trough',
                    'index': i,
                    'label': len(waves) + 1,
                    'x': [x[i - 1], x[i], x[i + 1]],
                    'y': [prev_p, cur_p, next_p],
                })

        self.waves = waves
        return waves

    def identify_patterns(self, waves_or_data):
        """Return a small summary dict to satisfy tests and example usage.
        If a list of waves is passed, return wave_count. If ohlc data is
        passed, return basic metadata.
        """
        if waves_or_data is None:
            return {}

        if isinstance(waves_or_data, list):
            return {'wave_count': len(waves_or_data)}

        if isinstance(waves_or_data, pd.DataFrame):
            return {
                'rows': len(waves_or_data),
                'columns': list(waves_or_data.columns),
            }

        # fallback
        return {'type': str(type(waves_or_data))}

    def get_waves(self):
        return self.waves

    def generate_signals(self, ohlc_data, waves=None, risk_perc: float = 1.0, account_size: float = None, produce_breakout: bool = True, lookahead_bars: int = 5, require_confirmation: bool = False, rsi_period: int = 14, rsi_min: float = 40.0, rsi_max: float = 60.0, vol_ma_period: int = 20, vol_multiplier: float = 1.0):
        """
        Generate trade signals from detected waves.

        New parameters for confirmation:
        - require_confirmation: if True, adds 'confirmed' boolean and 'confirm_reasons' text and only marks confirmed when RSI/volume checks pass
        - rsi_period, rsi_min, rsi_max: RSI parameters (BUY preferred RSI > rsi_min, SELL preferred RSI < rsi_max)
        - vol_ma_period, vol_multiplier: volume must be >= vol_multiplier * rolling_mean(volume, vol_ma_period)
        """
        if waves is None:
            waves = self.waves
        if waves is None or len(waves) == 0:
            cols = ['signal_time','side','entry','stop_loss','take_profit','rr','position_size','confidence','wave_label','note','entry_type','wave_type','confirmed','confirm_reasons']
            return pd.DataFrame(columns=cols)

        rows = []

        # If confirmation is requested and we have ohlc_data, precompute RSI and volume MA
        rsi_series = None
        vol_ma = None
        df = None
        if require_confirmation and isinstance(ohlc_data, pd.DataFrame):
            try:
                df = ohlc_data.copy()
                # ensure close and volume numeric
                if 'close' in df.columns:
                    df['close'] = pd.to_numeric(df['close'], errors='coerce')
                if 'volume' in df.columns:
                    df['volume'] = pd.to_numeric(df['volume'], errors='coerce')

                # compute RSI (simple Wilder's RSI with smoothed averages)
                delta = df['close'].diff()
                up = delta.clip(lower=0)
                down = -1 * delta.clip(upper=0)
                roll_up = up.ewm(alpha=1.0/rsi_period, adjust=False).mean()
                roll_down = down.ewm(alpha=1.0/rsi_period, adjust=False).mean()
                rs = roll_up / (roll_down.replace(0, 1e-8))
                rsi_series = 100 - (100 / (1 + rs))

                # compute volume moving average
                if 'volume' in df.columns:
                    vol_ma = df['volume'].rolling(window=vol_ma_period, min_periods=1).mean()
            except Exception:
                rsi_series = None
                vol_ma = None

        # helper to safely extract numeric center price from a wave
        def center_price(w):
            try:
                return float(w.get('y')[1])
            except Exception:
                return None

        # simple classifier for wave type (impulse vs corrective) based on magnitude
        def classify_wave(w, reference_price=None):
            try:
                cen = center_price(w)
                if cen is None:
                    return 'unknown'
                if reference_price is None:
                    reference_price = cen
                try:
                    neigh = w.get('y')
                    amp = max(neigh) - min(neigh) if neigh and len(neigh) >= 3 else 0.0
                except Exception:
                    amp = 0.0
                rel = abs(amp) / max(1.0, float(reference_price))
                return 'impulse' if rel >= 0.015 else 'corrective'
            except Exception:
                return 'unknown'

        # helper to map a datetime-like or positional x to positional index into ohlc_data
        def map_to_pos(ts_or_pos, df_index):
            if df_index is None:
                return None
            try:
                if isinstance(ts_or_pos, (int, np.integer)):
                    return int(ts_or_pos) if 0 <= int(ts_or_pos) < len(df_index) else None
                if hasattr(ts_or_pos, 'tzinfo') or isinstance(ts_or_pos, (pd.Timestamp,)):
                    pos = df_index.get_indexer([pd.to_datetime(ts_or_pos)], method='nearest')
                    if len(pos) and pos[0] >= 0:
                        return int(pos[0])
            except Exception:
                pass
            try:
                pos = df_index.get_loc(pd.to_datetime(ts_or_pos))
                if isinstance(pos, int):
                    return pos
            except Exception:
                return None

        for i, w in enumerate(waves):
            p = center_price(w)
            if p is None:
                continue

            wave_type = classify_wave(w, reference_price=p)

            # find a counterpart (next peak for a trough, next trough for a peak)
            counterpart = None
            for j in range(i+1, len(waves)):
                if w['type'] == 'trough' and waves[j]['type'] == 'peak':
                    counterpart = waves[j]
                    break
                if w['type'] == 'peak' and waves[j]['type'] == 'trough':
                    counterpart = waves[j]
                    break

            if counterpart is not None:
                cp = center_price(counterpart)
                amplitude = cp - p if w['type'] == 'trough' else p - cp
            else:
                amplitude = max(0.01 * p, 1e-6)

            # build base pullback signal (reactive)
            if w['type'] == 'trough':
                side = 'BUY'
                entry = p
                stop = p - abs(amplitude) * 0.5
                take_profit = cp if counterpart is not None else p + abs(amplitude) * 1.618
            else:
                side = 'SELL'
                entry = p
                stop = p + abs(amplitude) * 0.5
                take_profit = cp if counterpart is not None else p - abs(amplitude) * 1.618

            sl_dist = abs(entry - stop)
            tp_dist = abs(take_profit - entry)
            rr = (tp_dist / sl_dist) if sl_dist > 0 else None

            position_size = None
            if account_size is not None and sl_dist and sl_dist > 0:
                risk_amount = account_size * (float(risk_perc) / 100.0)
                try:
                    position_size = float(risk_amount) / float(sl_dist)
                except Exception:
                    position_size = None

            # approximate timestamp
            ts = None
            try:
                if isinstance(ohlc_data, pd.DataFrame):
                    winx = w.get('index')
                    if winx is not None and int(winx) < len(ohlc_data.index):
                        ts = ohlc_data.index[int(winx)]
                    else:
                        xv = w.get('x')
                        if xv:
                            ts = xv[1]
                else:
                    xv = w.get('x')
                    if xv:
                        ts = xv[1]
            except Exception:
                ts = None

            confidence = 0.5
            try:
                confidence += min(0.5, 0.1 * len(w.get('y') or []))
            except Exception:
                pass

            # prepare confirmation defaults
            confirmed = None
            confirm_reasons = ''
            if require_confirmation and df is not None:
                try:
                    # map timestamp to position
                    pos = map_to_pos(ts, df.index)
                    if pos is None:
                        # if we cannot map, treat as unconfirmed
                        confirmed = False
                        confirm_reasons = 'no_timestamp_map'
                    else:
                        checks = []
                        # RSI check
                        try:
                            rsi_val = float(rsi_series.iloc[pos]) if rsi_series is not None else None
                            if side == 'BUY':
                                checks.append((rsi_val is not None and rsi_val >= float(rsi_min), f'rsi{rsi_val:.1f}'))
                            else:
                                checks.append((rsi_val is not None and rsi_val <= float(rsi_max), f'rsi{rsi_val:.1f}'))
                        except Exception:
                            checks.append((False, 'rsi_err'))

                        # volume check
                        try:
                            if vol_ma is not None and 'volume' in df.columns:
                                vol_val = float(df['volume'].iloc[pos])
                                vol_ma_val = float(vol_ma.iloc[pos]) if not pd.isna(vol_ma.iloc[pos]) else 0.0
                                checks.append((vol_val >= vol_multiplier * vol_ma_val, f'vol{vol_val:.0f}/{vol_ma_val:.0f}'))
                            else:
                                checks.append((True, 'vol_na'))
                        except Exception:
                            checks.append((False, 'vol_err'))

                        # final decision: all checks must pass
                        passed = all([c[0] for c in checks])
                        confirmed = bool(passed)
                        confirm_reasons = ','.join([c[1] for c in checks])
                except Exception:
                    confirmed = False
                    confirm_reasons = 'confirm_err'
            else:
                # if confirmation not required, we can set confirmed to None (unknown) or True by default
                confirmed = None
                confirm_reasons = ''

            rows.append({
                'signal_time': ts,
                'side': side,
                'entry': float(entry),
                'stop_loss': float(stop),
                'take_profit': float(take_profit),
                'rr': float(rr) if rr is not None else None,
                'position_size': float(position_size) if position_size is not None else None,
                'confidence': float(confidence),
                'wave_label': w.get('label'),
                'note': 'pullback',
                'entry_type': 'pullback',
                'wave_type': wave_type,
                'confirmed': confirmed,
                'confirm_reasons': confirm_reasons,
            })

            # produce a breakout/early signal when requested by scanning forward in ohlc_data
            if produce_breakout and isinstance(ohlc_data, pd.DataFrame) and counterpart is not None:
                try:
                    # Use original DataFrame index for correct timestamps
                    df_ohlc = ohlc_data
                    # determine base position in the original index
                    base_pos = None
                    try:
                        if ts is not None and not pd.isna(ts):
                            pos_arr = df_ohlc.index.get_indexer([pd.to_datetime(ts)], method='nearest')
                            if len(pos_arr) and pos_arr[0] >= 0:
                                base_pos = int(pos_arr[0])
                        if base_pos is None:
                            winx = w.get('index')
                            if isinstance(winx, (int, np.integer)) and 0 <= int(winx) < len(df_ohlc):
                                base_pos = int(winx)
                    except Exception:
                        base_pos = None

                    if base_pos is None:
                        # cannot locate starting position; skip breakout search
                        raise RuntimeError('unable to map wave to dataframe position')

                    # scan next lookahead_bars bars for breakout using the original df_ohlc
                    for k in range(1, int(lookahead_bars) + 1):
                        cand_idx = base_pos + k
                        if cand_idx >= len(df_ohlc):
                            break
                        # prefer 'close' column for price
                        try:
                            price_close = float(df_ohlc.iloc[cand_idx]['close'])
                        except Exception:
                            # fallback to first numeric column
                            price_close = float(pd.to_numeric(df_ohlc.select_dtypes(include=[np.number]).iloc[cand_idx, 0], errors='coerce'))

                        timestamp = df_ohlc.index[cand_idx]

                        # breakout detection relative to counterpart price
                        if side == 'BUY' and price_close > float(cp):
                            # avoid duplicate signal_time for same wave
                            if any([not pd.isna(r.get('signal_time')) and pd.to_datetime(r.get('signal_time')) == pd.to_datetime(timestamp) for r in rows]):
                                break

                            # compute confirmation for breakout if requested
                            b_confirmed = None
                            b_reasons = ''
                            if require_confirmation and df is not None:
                                try:
                                    # check RSI and volume at cand_idx
                                    rsi_val = float(rsi_series.iloc[cand_idx]) if rsi_series is not None else None
                                    vol_val = float(df['volume'].iloc[cand_idx]) if 'volume' in df.columns else None
                                    vol_ma_val = float(vol_ma.iloc[cand_idx]) if vol_ma is not None else None
                                    r_ok = (rsi_val is not None and rsi_val >= float(rsi_min))
                                    v_ok = (vol_val is None) or (vol_ma_val is not None and vol_val >= vol_multiplier * vol_ma_val)
                                    b_confirmed = bool(r_ok and v_ok)
                                    b_reasons = f'rsi{rsi_val if rsi_val is not None else "na"},vol{vol_val if vol_val is not None else "na"}'
                                except Exception:
                                    b_confirmed = False
                                    b_reasons = 'breakout_confirm_err'

                            rows.append({
                                'signal_time': timestamp,
                                'side': side,
                                'entry': float(price_close),
                                'stop_loss': float(stop),
                                'take_profit': float(take_profit),
                                'rr': None,
                                'position_size': None,
                                'confidence': float(min(0.95, confidence + 0.25)),
                                'wave_label': w.get('label'),
                                'note': 'breakout',
                                'entry_type': 'breakout',
                                'wave_type': wave_type,
                                'confirmed': b_confirmed,
                                'confirm_reasons': b_reasons,
                            })
                            break

                        if side == 'SELL' and price_close < float(cp):
                            if any([not pd.isna(r.get('signal_time')) and pd.to_datetime(r.get('signal_time')) == pd.to_datetime(timestamp) for r in rows]):
                                break

                            b_confirmed = None
                            b_reasons = ''
                            if require_confirmation and df is not None:
                                try:
                                    rsi_val = float(rsi_series.iloc[cand_idx]) if rsi_series is not None else None
                                    vol_val = float(df['volume'].iloc[cand_idx]) if 'volume' in df.columns else None
                                    vol_ma_val = float(vol_ma.iloc[cand_idx]) if vol_ma is not None else None
                                    r_ok = (rsi_val is not None and rsi_val <= float(rsi_max))
                                    v_ok = (vol_val is None) or (vol_ma_val is not None and vol_val >= vol_multiplier * vol_ma_val)
                                    b_confirmed = bool(r_ok and v_ok)
                                    b_reasons = f'rsi{rsi_val if rsi_val is not None else "na"},vol{vol_val if vol_val is not None else "na"}'
                                except Exception:
                                    b_confirmed = False
                                    b_reasons = 'breakout_confirm_err'

                            rows.append({
                                'signal_time': timestamp,
                                'side': side,
                                'entry': float(price_close),
                                'stop_loss': float(stop),
                                'take_profit': float(take_profit),
                                'rr': None,
                                'position_size': None,
                                'confidence': float(min(0.95, confidence + 0.25)),
                                'wave_label': w.get('label'),
                                'note': 'breakout',
                                'entry_type': 'breakout',
                                'wave_type': wave_type,
                                'confirmed': b_confirmed,
                                'confirm_reasons': b_reasons,
                            })
                            break
                    # if not found, do nothing (we already emitted pullback)
                except Exception:
                    pass

        df_signals = pd.DataFrame(rows)
        try:
            if 'signal_time' in df_signals.columns:
                df_signals['signal_time'] = pd.to_datetime(df_signals['signal_time'], errors='coerce')
        except Exception:
            pass

        return df_signals

    def evaluate_signals(self, signals, ohlc_data, move_threshold_perc: float = 0.002, lookahead_bars: int = 10):
        """
        Evaluate signals to compute lead/lag statistics.

        - move_threshold_perc: fraction of price used to detect the start of a meaningful move (default 0.2%)
        - lookahead_bars: maximum bars to scan to detect first meaningful move

        Returns a dict with per-signal delays and overall summary.
        """
        if signals is None or len(signals) == 0:
            return {'summary': {}, 'details': pd.DataFrame()}

        details = []
        df = ohlc_data.copy() if isinstance(ohlc_data, pd.DataFrame) else None
        index = df.index if df is not None else None

        # helper to find positional index for a signal_time
        def find_pos_for_time(t):
            try:
                if pd.isna(t):
                    return None
                pos = index.get_indexer([pd.to_datetime(t)], method='nearest')
                if len(pos) and pos[0] >= 0:
                    return int(pos[0])
            except Exception:
                return None

        for _, s in signals.iterrows():
            entry = float(s.get('entry')) if pd.notna(s.get('entry')) else None
            side = str(s.get('side', '')).upper()
            t = s.get('signal_time')
            sig_pos = find_pos_for_time(t) if index is not None else None

            delay = None
            found_move = False
            if df is not None and entry is not None and sig_pos is not None:
                threshold = entry * float(move_threshold_perc)
                for k in range(1, int(lookahead_bars) + 1):
                    cand = sig_pos + k
                    if cand >= len(df):
                        break
                    close = float(df.iloc[cand]['close']) if 'close' in df.columns else float(df.iloc[cand][df.columns[0]])
                    if side == 'BUY' and close >= entry + threshold:
                        delay = k
                        found_move = True
                        break
                    if side == 'SELL' and close <= entry - threshold:
                        delay = k
                        found_move = True
                        break
            details.append({'signal_time': t, 'side': side, 'entry': entry, 'delay_bars': delay, 'found_move': found_move, 'entry_type': s.get('entry_type'), 'wave_type': s.get('wave_type')})

        det_df = pd.DataFrame(details)
        # summary
        delays = det_df['delay_bars'].dropna().astype(float)
        summary = {
            'count': len(det_df),
            'found_moves': int(det_df['found_move'].sum()),
            'mean_delay_bars': float(delays.mean()) if len(delays) > 0 else None,
            'median_delay_bars': float(delays.median()) if len(delays) > 0 else None,
            'pct_leading': float((det_df['delay_bars'] > 0).mean()) if len(det_df) > 0 else None,
            'pct_no_move_within_lookahead': float((det_df['found_move'] == False).mean()) if len(det_df) > 0 else None,
        }

        return {'summary': summary, 'details': det_df}