import os
import pandas as pd
from typing import Optional, Sequence, Dict, Any


def load_csv_data(file_path: str,
                  usecols: Optional[Sequence[str]] = None,
                  nrows: Optional[int] = None,
                  parse_dates: Optional[Sequence[str]] = None,
                  dtype: Optional[Dict[str, Any]] = None,
                  low_memory: bool = True,
                  cache_parquet: Optional[str] = None) -> pd.DataFrame:
    """
    Fast CSV loader with optional column selection, dtype hints and parquet caching.

    Parameters:
    - file_path: path to CSV
    - usecols: subset of columns to read (speeds up IO)
    - nrows: only read this many rows (useful for sampling)
    - parse_dates: list of columns to parse as dates
    - dtype: dict of column dtypes to pass to pandas
    - low_memory: forwarded to pandas.read_csv
    - cache_parquet: if provided, will write a parquet of the read result and use it on subsequent loads

    Returns a pandas.DataFrame.
    """
    # If a parquet cache is provided and exists -> load that first (faster)
    if cache_parquet and os.path.exists(cache_parquet):
        try:
            return pd.read_parquet(cache_parquet)
        except Exception:
            # fall back to CSV read if parquet fails
            pass

    # Protect against usecols containing names that don't exist in the file
    header_cols = None
    if usecols is not None:
        try:
            header_df = pd.read_csv(file_path, nrows=0)
            header_cols = list(header_df.columns)
            # map requested usecols to actual column names (case-insensitive match)
            filtered = []
            for req in usecols:
                for actual in header_cols:
                    if str(actual).lower() == str(req).lower():
                        filtered.append(actual)
                        break
            if len(filtered) == 0:
                # none of the requested columns exist in file; ignore usecols to read all
                usecols = None
            else:
                usecols = filtered

            # also filter parse_dates if provided
            if parse_dates is not None:
                parse_dates = [d for d in parse_dates if d in header_cols]
                if len(parse_dates) == 0:
                    parse_dates = None
        except Exception:
            # if header read fails for any reason, continue and let pandas handle errors
            pass

    read_kwargs = {
        'usecols': list(usecols) if usecols is not None else None,
        'nrows': nrows,
        'parse_dates': list(parse_dates) if parse_dates is not None else None,
        'dtype': dtype,
        'low_memory': low_memory,
    }

    # remove None values to avoid pandas warnings
    read_kwargs = {k: v for k, v in read_kwargs.items() if v is not None}

    df = pd.read_csv(file_path, **read_kwargs)

    # Optionally cache to parquet for faster subsequent loads
    if cache_parquet:
        try:
            df.to_parquet(cache_parquet, index=True)
        except Exception:
            pass

    return df


def load_api_data(api_url: str):
    import requests
    response = requests.get(api_url)
    return response.json()


def load_data(source, identifier, **kwargs):
    if source == 'csv':
        return load_csv_data(identifier, **kwargs)
    elif source == 'api':
        return load_api_data(identifier)
    else:
        raise ValueError("Unsupported data source. Use 'csv' or 'api'.")


# Enhanced OHLC loader with performance-focused options
def load_ohlc_data(file_path: str,
                   datetime_col: str = 'datetime',
                   usecols: Optional[Sequence[str]] = None,
                   nrows: Optional[int] = None,
                   asset_symbol: Optional[str] = None,
                   symbol_col_candidates: Sequence[str] = ('symbol', 'ticker', 'asset_symbol', 'instrument', 'code', 'trading_symbol', 'tradingsymbol'),
                   dtype: Optional[Dict[str, Any]] = None,
                   cache_parquet: Optional[str] = None,
                   downcast_numeric: bool = True,
                   year: Optional[int] = None,
                   start_date: Optional[str] = None,
                   end_date: Optional[str] = None,
                   chunksize: int = 100_000) -> pd.DataFrame:
    """
    Load OHLCV data efficiently with sensible defaults for large CSVs.

    - Reads only requested columns (defaults to datetime + OHLCV + symbol candidates)
    - Parses datetime column
    - Sets symbol columns as categorical to speed unique() and comparisons
    - Optionally filters by asset_symbol before returning
    - Optionally caches a parquet copy for future fast loads

    Backwards compatible: called with only file_path returns full parsed DataFrame when possible.
    """
    # Prepare default columns to read when usecols not provided
    ohlc_cols = ['open', 'high', 'low', 'close', 'volume']

    # flag to indicate whether chunked read path performed symbol filtering already
    chunk_filter_applied = False

    # build candidate list of columns to request from disk
    if usecols is None:
        usecols_read = [datetime_col] + ohlc_cols + list(symbol_col_candidates)
        # de-duplicate and ensure strings
        usecols_read = [c for i, c in enumerate(usecols_read) if c and c not in usecols_read[:i]]
    else:
        usecols_read = list(usecols)

    # dtype hints: default symbol -> category
    dtype_hints = {} if dtype is None else dict(dtype)
    for sym in symbol_col_candidates:
        if sym in usecols_read and sym not in dtype_hints:
            dtype_hints[sym] = 'category'

    # If a year or date range filter is requested, read the CSV in chunks and filter early
    try:
        if year is not None or start_date is not None or end_date is not None:
            # build read_csv kwargs for chunked reading (no cache used for chunking)
            # Protect against requesting usecols that don't exist in the file
            try:
                hdr = pd.read_csv(file_path, nrows=0)
                available_cols = list(hdr.columns)
                # case-insensitive match of usecols_read to available_cols
                filtered_usecols = []
                if usecols_read is not None:
                    for req in usecols_read:
                        for actual in available_cols:
                            if str(actual).lower() == str(req).lower():
                                filtered_usecols.append(actual)
                                break
                else:
                    filtered_usecols = None
                if filtered_usecols is not None and len(filtered_usecols) == 0:
                    filtered_usecols = None

                # Force-include canonical trading symbol header if present so chunked
                # reads can always apply symbol filtering. This ensures we don't
                # miss the trading_symbol column due to earlier usecols selection.
                if filtered_usecols is not None:
                    for cand in ('trading_symbol', 'tradingsymbol'):
                        for actual in available_cols:
                            if str(actual).lower() == cand:
                                if actual not in filtered_usecols:
                                    filtered_usecols.append(actual)
                                break
            except Exception:
                # if header inspection fails, fall back to original list
                filtered_usecols = usecols_read

            rd_kwargs = {
                'usecols': filtered_usecols,
                'parse_dates': [datetime_col] if filtered_usecols is not None and datetime_col in filtered_usecols else ([datetime_col] if datetime_col in available_cols else None),
                'dtype': dtype_hints if dtype_hints else None,
                'low_memory': True,
                'chunksize': chunksize,
            }

            pieces = []
            # pre-parse start/end dates once
            sd_parsed = pd.to_datetime(start_date) if start_date is not None else None
            ed_parsed = pd.to_datetime(end_date) if end_date is not None else None

            # Instead of picking a single symbol column, include all candidate symbol columns
            # present in the CSV header and later apply a combined symbol mask (OR across columns).
            symbol_cols_to_check = []
            if asset_symbol is not None:
                candidate_actuals = [actual for actual in available_cols if any(actual.lower() == cand.lower() for cand in symbol_col_candidates)]
                if candidate_actuals:
                    # ensure trading_symbol is prioritized in the list
                    candidate_actuals = sorted(candidate_actuals, key=lambda x: 0 if x.lower() in ('trading_symbol', 'tradingsymbol') else 1)
                    symbol_cols_to_check = candidate_actuals
                    # append these symbol cols to filtered_usecols so we can read and filter by them inside chunks
                    if filtered_usecols is not None:
                        for symc in symbol_cols_to_check:
                            if symc not in filtered_usecols:
                                filtered_usecols.append(symc)
                    # update rd_kwargs so the upcoming pd.read_csv uses the new list
                    rd_kwargs['usecols'] = filtered_usecols
                    rd_kwargs['parse_dates'] = [datetime_col] if datetime_col in filtered_usecols else None

            # optional debug counters (enable for diagnostic runs)
            debug = True
            rows_scanned = 0
            rows_after_filters = 0

            # diagnostic print of resolved usecols and detected symbol column
            if debug:
                try:
                    print(f"DEBUG: filtered_usecols before chunking: {filtered_usecols}")
                    print(f"DEBUG: symbol_cols_to_check: {symbol_cols_to_check}")
                except Exception:
                    pass

            # iterate chunks and apply both date and symbol filtering inside the loop
            for chunk in pd.read_csv(file_path, **{k: v for k, v in rd_kwargs.items() if v is not None}):
                # count rows scanned
                if debug:
                    try:
                        rows_scanned += len(chunk)
                    except Exception:
                        rows_scanned += 1
                # ensure datetime parsed
                if datetime_col in chunk.columns and not pd.api.types.is_datetime64_any_dtype(chunk[datetime_col]):
                    chunk[datetime_col] = pd.to_datetime(chunk[datetime_col], errors='coerce')

                mask = pd.Series(True, index=chunk.index)

                # year filter (fast path)
                if year is not None and datetime_col in chunk.columns:
                    try:
                        mask = mask & (chunk[datetime_col].dt.year == int(year))
                    except Exception:
                        # if dt.year fails (e.g., NaT), coerce to datetime and retry
                        chunk[datetime_col] = pd.to_datetime(chunk[datetime_col], errors='coerce')
                        mask = mask & (chunk[datetime_col].dt.year == int(year))

                # Robust date-range filtering by calendar date to avoid tz-aware/naive mismatch
                if datetime_col in chunk.columns and (sd_parsed is not None or ed_parsed is not None):
                    try:
                        # ensure chunk datetimes are parsed
                        chunk[datetime_col] = pd.to_datetime(chunk[datetime_col], errors='coerce')
                        # compare by calendar date (this is timezone-agnostic for our use-case)
                        chunk_dates = chunk[datetime_col].dt.date
                        if sd_parsed is not None:
                            sd_day = pd.to_datetime(sd_parsed).date()
                            mask = mask & (chunk_dates >= sd_day)
                        if ed_parsed is not None:
                            ed_day = pd.to_datetime(ed_parsed).date()
                            mask = mask & (chunk_dates <= ed_day)
                    except Exception:
                        # fallback to previous UTC-aware comparison if date-based fails
                        try:
                            if sd_parsed is not None:
                                if getattr(sd_parsed, 'tzinfo', None) is None:
                                    sd_cmp = pd.Timestamp(sd_parsed).tz_localize('UTC')
                                else:
                                    sd_cmp = pd.Timestamp(sd_parsed).tz_convert('UTC')
                            else:
                                sd_cmp = None
                            if ed_parsed is not None:
                                if getattr(ed_parsed, 'tzinfo', None) is None:
                                    ed_cmp = pd.Timestamp(ed_parsed).tz_localize('UTC')
                                else:
                                    ed_cmp = pd.Timestamp(ed_parsed).tz_convert('UTC')
                            else:
                                ed_cmp = None

                            if pd.api.types.is_datetime64tz_dtype(chunk[datetime_col]):
                                chunk_dt_utc = chunk[datetime_col].dt.tz_convert('UTC')
                            else:
                                chunk_dt_utc = chunk[datetime_col].dt.tz_localize('UTC')

                            if sd_cmp is not None:
                                mask = mask & (chunk_dt_utc >= sd_cmp)
                            if ed_cmp is not None:
                                mask = mask & (chunk_dt_utc <= ed_cmp)
                        except Exception:
                            # as last resort, compare string representations
                            if sd_parsed is not None:
                                mask = mask & (chunk[datetime_col].astype(str) >= str(sd_parsed))
                            if ed_parsed is not None:
                                mask = mask & (chunk[datetime_col].astype(str) <= str(ed_parsed))

                # Apply symbol filtering inside the chunk loop if requested across all candidate symbol columns
                if asset_symbol is not None and symbol_cols_to_check:
                    try:
                        target = str(asset_symbol).strip().lower()
                        sym_mask_combined = pd.Series(False, index=chunk.index)
                        for symc in symbol_cols_to_check:
                            if symc in chunk.columns:
                                ser = chunk[symc].astype(str).str.strip().str.lower()
                                exact = ser == target
                                contains = ser.str.contains(target, na=False)
                                sym_mask_combined = sym_mask_combined | exact | contains
                        mask = mask & sym_mask_combined
                        # mark that we applied symbol filtering during chunking
                        chunk_filter_applied = True
                    except Exception:
                        # if something goes wrong, skip symbol filtering for this chunk
                        pass

                if mask.any():
                    sel = chunk.loc[mask]
                    pieces.append(sel)
                    if debug:
                        try:
                            rows_after_filters += len(sel)
                        except Exception:
                            rows_after_filters += mask.sum()

            if debug:
                print(f"Chunked read debug: rows_scanned={rows_scanned}, rows_after_filters={rows_after_filters}")

            if len(pieces) == 0:
                if debug:
                    print(f"Chunked read debug: rows_scanned={rows_scanned}, rows_after_filters={rows_after_filters}")
                # As a robust fallback, attempt a single-pass read of the key columns (symbol + datetime + ohlc)
                try:
                    fb_usecols = filtered_usecols if filtered_usecols is not None else usecols_read
                    if datetime_col not in fb_usecols:
                        fb_usecols = list(fb_usecols) + [datetime_col]
                    print("DEBUG: chunking returned no pieces, performing fallback full read of key columns...")
                    full_df = pd.read_csv(file_path, usecols=fb_usecols, parse_dates=[datetime_col] if datetime_col in fb_usecols else None, dtype=dtype_hints if dtype_hints else None, low_memory=False)
                    # ensure datetime
                    if datetime_col in full_df.columns and not pd.api.types.is_datetime64_any_dtype(full_df[datetime_col]):
                        full_df[datetime_col] = pd.to_datetime(full_df[datetime_col], errors='coerce')

                    # apply the same year/date/symbol filters
                    mask_full = pd.Series(True, index=full_df.index)
                    if year is not None and datetime_col in full_df.columns:
                        mask_full = mask_full & (full_df[datetime_col].dt.year == int(year))
                    if start_date is not None and datetime_col in full_df.columns:
                        try:
                            sd_day = pd.to_datetime(start_date).date()
                            mask_full = mask_full & (full_df[datetime_col].dt.date >= sd_day)
                        except Exception:
                            mask_full = mask_full & (full_df[datetime_col].astype(str) >= str(start_date))
                    if end_date is not None and datetime_col in full_df.columns:
                        try:
                            ed_day = pd.to_datetime(end_date).date()
                            mask_full = mask_full & (full_df[datetime_col].dt.date <= ed_day)
                        except Exception:
                            mask_full = mask_full & (full_df[datetime_col].astype(str) <= str(end_date))

                    if asset_symbol is not None and symbol_cols_to_check:
                        target = str(asset_symbol).strip().lower()
                        sym_mask_combined = pd.Series(False, index=full_df.index)
                        for symc in symbol_cols_to_check:
                            if symc in full_df.columns:
                                ser = full_df[symc].astype(str).str.strip().str.lower()
                                exact = ser == target
                                contains = ser.str.contains(target, na=False)
                                sym_mask_combined = sym_mask_combined | exact | contains
                        mask_full = mask_full & sym_mask_combined
                        # mark that fallback full read also applied symbol filtering
                        chunk_filter_applied = True

                    filtered_full = full_df.loc[mask_full]
                    if len(filtered_full) == 0:
                        df = pd.DataFrame(columns=usecols_read)
                    else:
                        df = filtered_full.reset_index(drop=True)
                except Exception as e:
                    if debug:
                        print("Fallback full read failed:", e)
                    df = pd.DataFrame(columns=usecols_read)
            else:
                df = pd.concat(pieces, ignore_index=True)
        else:
            # attempt to read CSV (use cache if provided)
            df = load_csv_data(file_path,
                               usecols=usecols_read,
                               nrows=nrows,
                               parse_dates=[datetime_col] if datetime_col in usecols_read else None,
                               dtype=dtype_hints if dtype_hints else None,
                               low_memory=True,
                               cache_parquet=cache_parquet)
    except FileNotFoundError:
        # keep behavior expected by tests/examples
        raise

    # If datetime_col wasn't parsed (missing name), try to detect common date columns
    if datetime_col not in df.columns:
        for candidate in ('datetime', 'date', 'time', 'timestamp'):
            if candidate in df.columns:
                try:
                    df[candidate] = pd.to_datetime(df[candidate], errors='coerce')
                    df = df.set_index(candidate)
                    break
                except Exception:
                    pass
    else:
        try:
            if not pd.api.types.is_datetime64_any_dtype(df[datetime_col]):
                df[datetime_col] = pd.to_datetime(df[datetime_col], errors='coerce')
            df = df.set_index(datetime_col)
        except Exception:
            # if setting index fails, continue without index
            pass

    # Downcast numeric columns to reduce memory
    if downcast_numeric:
        for col in ['open', 'high', 'low', 'close', 'volume']:
            if col in df.columns:
                try:
                    if pd.api.types.is_integer_dtype(df[col]) or pd.api.types.is_float_dtype(df[col]):
                        df[col] = pd.to_numeric(df[col], errors='coerce')
                        # downcast floats to float32 where possible
                        df[col] = pd.to_numeric(df[col], downcast='float')
                except Exception:
                    df[col] = pd.to_numeric(df[col], errors='coerce')

    # If asset_symbol filtering requested, detect symbol column and filter early
    if asset_symbol is not None:
        # if we already applied filtering during chunked/fallback full read, skip re-filtering
        if 'chunk_filter_applied' in locals() and chunk_filter_applied:
            # skip final filtering since it was already applied while chunking
            pass
        else:
            # prefer trading_symbol/tradingsymbol explicitly when available
            preferred = [s for s in ['trading_symbol', 'tradingsymbol'] if s in df.columns]
            if preferred:
                symbol_col = preferred[0]
            else:
                # fallback to first available candidate
                symbol_col = next((c for c in df.columns if str(c).lower() in [s.lower() for s in symbol_col_candidates]), None)

            if symbol_col is not None:
                # Normalize symbol strings and the requested asset_symbol to avoid
                # missing matches due to casing, trailing spaces or small suffixes.
                try:
                    ser = df[symbol_col].astype(str).str.strip()
                    target = str(asset_symbol).strip()
                    # first try exact case-insensitive match
                    mask = ser.str.lower() == target.lower()
                    # if no exact matches, try contains (partial) match as a fallback
                    if mask.sum() == 0:
                        mask = ser.str.lower().str.contains(target.lower(), na=False)

                    df = df.loc[mask]

                    # convert to categorical on the filtered result for performance
                    if len(df) > 0 and not pd.api.types.is_categorical_dtype(df[symbol_col]):
                        df[symbol_col] = df[symbol_col].astype('category')
                except Exception:
                    # fallback to combined symbol columns OR-match if single-column filtering fails
                    try:
                        candidate_actuals = [c for c in df.columns if any(c.lower() == cand.lower() for cand in symbol_col_candidates)]
                        if candidate_actuals:
                            target = str(asset_symbol).strip().lower()
                            sym_mask_combined = pd.Series(False, index=df.index)
                            for symc in candidate_actuals:
                                ser = df[symc].astype(str).str.strip().str.lower()
                                exact = ser == target
                                contains = ser.str.contains(target, na=False)
                                sym_mask_combined = sym_mask_combined | exact | contains
                            df = df.loc[sym_mask_combined]
                    except Exception:
                        pass
            else:
                # no symbol column found; silently continue
                pass

    # Final sort by index if datetime index present
    try:
        if isinstance(df.index, pd.DatetimeIndex):
            df = df.sort_index()
    except Exception:
        pass

    return df