def get_sample_ohlc_data():
    return [
        {"open": 100, "high": 105, "low": 95, "close": 102, "volume": 1000},
        {"open": 102, "high": 106, "low": 98, "close": 104, "volume": 1500},
        {"open": 104, "high": 107, "low": 101, "close": 105, "volume": 1200},
        {"open": 105, "high": 110, "low": 103, "close": 108, "volume": 1300},
        {"open": 108, "high": 112, "low": 107, "close": 111, "volume": 1600},
    ]

def get_sample_volume_data():
    return [1000, 1500, 1200, 1300, 1600]


# Provide objects that are both callable and implement __len__ so tests
# that expect either a function or a sequence will work.
class _CallableSample:
    def __init__(self, data):
        self._data = data

    def __call__(self):
        return self._data

    def __len__(self):
        return len(self._data)


sample_ohlc_data = _CallableSample(get_sample_ohlc_data())
sample_volume_data = _CallableSample(get_sample_volume_data())