# Elliott Wave Indicator

This project implements an Elliott Wave Indicator based on OHLC (Open, High, Low, Close) and volume data. The indicator calculates Elliott Waves and provides visualization tools to help users analyze market trends.

## Overview

The Elliott Wave Theory is a method of technical analysis that traders use to analyze financial market cycles and forecast future price movements. This project aims to provide a comprehensive toolset for calculating and visualizing Elliott Waves using Python.

## Features

- Load OHLC and volume data from various sources.
- Calculate Elliott Waves based on the loaded data.
- Visualize the identified waves on charts.
- Experiment with different datasets and parameters using Jupyter notebooks.

## Installation

To install the required dependencies, run:

```
pip install -r requirements.txt
```

## Usage

1. **Load Data**: Use the functions in `src/data/loader.py` to load your OHLC and volume data.
2. **Calculate Waves**: Utilize the `ElliottWaveIndicator` class in `src/indicators/elliott.py` to calculate the waves.
3. **Visualize**: Use the plotting functions in `src/visualization/plotter.py` to visualize the results.
4. **Experiment**: Open the Jupyter notebook in `src/experiments/notebook.ipynb` to experiment with different datasets and parameters.

## Examples

Refer to the `examples/run_example.py` file for a simple demonstration of how to use the Elliott Wave Indicator.

## Testing

To run the tests, use the following command:

```
pytest
```

This will execute the unit tests defined in the `tests` directory.

## Contributing

Contributions are welcome! Please feel free to submit a pull request or open an issue for any suggestions or improvements.

## License

This project is licensed under the MIT License. See the LICENSE file for more details.