import unittest
from src.indicators.elliott import ElliottWaveIndicator
from src.data.fixtures import sample_ohlc_data, sample_volume_data

class TestElliottWaveIndicator(unittest.TestCase):

    def setUp(self):
        self.indicator = ElliottWaveIndicator()
        self.ohlc_data = sample_ohlc_data()
        self.volume_data = sample_volume_data()

    def test_calculate_waves(self):
        waves = self.indicator.calculate_waves(self.ohlc_data, self.volume_data)
        self.assertIsNotNone(waves)
        self.assertIsInstance(waves, list)

    def test_identify_patterns(self):
        patterns = self.indicator.identify_patterns(self.ohlc_data)
        self.assertIsNotNone(patterns)
        self.assertIsInstance(patterns, dict)

    def test_invalid_data(self):
        with self.assertRaises(ValueError):
            self.indicator.calculate_waves(None, self.volume_data)

        with self.assertRaises(ValueError):
            self.indicator.calculate_waves(self.ohlc_data, None)

if __name__ == '__main__':
    unittest.main()