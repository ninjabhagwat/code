import unittest
from src.data.loader import load_ohlc_data
from src.data.fixtures import sample_ohlc_data

class TestLoader(unittest.TestCase):

    def test_load_ohlc_data(self):
        data = load_ohlc_data('path/to/data.csv')
        self.assertIsNotNone(data)
        self.assertEqual(len(data), len(sample_ohlc_data))

    def test_load_ohlc_data_invalid_file(self):
        with self.assertRaises(FileNotFoundError):
            load_ohlc_data('invalid/path/to/data.csv')

    def test_load_ohlc_data_format(self):
        data = load_ohlc_data('path/to/data.csv')
        self.assertIn('open', data.columns)
        self.assertIn('high', data.columns)
        self.assertIn('low', data.columns)
        self.assertIn('close', data.columns)
        self.assertIn('volume', data.columns)

if __name__ == '__main__':
    unittest.main()