"""
examples/run_for_nifty50.py

Non-interactive runner that computes Elliott-wave signals for a fixed NIFTY50 symbol list.
Writes per-symbol `signals.csv` and combined `actionable_signals.csv` to the examples/outputs folder
so downstream scripts (place_bracket_order_sandbox.py) can consume them.

Usage (PowerShell):
  python run_for_nifty50.py

Environment / CLI:
  --months N    : number of recent months to include (default 3)
  --out DIR     : output directory (defaults to examples/outputs)
  --account-size : account size used for position sizing (default 10000)
  --min-confidence : min confidence to include actionable (default 0.0)

This script mirrors the non-interactive parts of run_example.py and processes a fixed
NIFTY50 symbol list declared below.
"""

import os
import math
import argparse
from datetime import datetime
import pandas as pd
from src.data.loader import load_ohlc_data
from src.indicators.elliott import ElliottWaveIndicator
from src.visualization.plotter import plot_elliott_waves

# Hard-coded NIFTY50 list (common canonical trading_symbol values used in this workspace)
NIFTY50 = [
    'ADANIENT','ADANIPORTS','APOLLOHOSP','ASIANPAINT','AXISBANK','BAJAJ-AUTO','BAJAJFINSV','BAJFINANCE',
    'BPCL','BRITANNIA','CIPLA','COALINDIA','DIVISLAB','DRREDDY','EICHERMOT','GRASIM','HCLTECH','HDFCBANK',
    'HDFCLIFE','HEROMOTOCO','HINDALCO','HINDUNILVR','ICICIBANK','INDUSINDBK','INFY','ITC','JSWSTEEL',
    'KOTAKBANK','LT','M&M','MARUTI','NESTLEIND','NTPC','ONGC','POWERGRID','RELIANCE','SBILIFE','SBIN',
    'SHREECEM','SUNPHARMA','TATAMOTORS','TATASTEEL','TCS','TECHM','TITAN','ULTRACEMCO','UPL','WIPRO',"POONAWALLA"
]

# CSV_PATH = os.path.join(os.path.dirname(__file__), '..', '..', 'historical_candles_latest.csv')
CSV_PATH=r'C:\Niranjan\Personal\Stock_Price_pridiction\intraday_15min_latest.csv'
# OUTPUTS_DIR_DEFAULT = os.path.join(os.path.dirname(__file__), 'outputs')
OUTPUTS_DIR_DEFAULT = r'C:\Niranjan\Personal\MCP_Demo\upstox-mcp-server\elliott-wave-indicator\examples\outputs\signals\intraday_15min'

def process_symbol(symbol: str, csv_path: str, start_date, end_date, account_size: float, outputs_dir: str):
    """Load data, run indicator and produce signals/actionable rows for one symbol."""
    print(f"Processing {symbol} from {start_date} to {end_date}")
    try:
        ohlc = load_ohlc_data(csv_path, asset_symbol=symbol, start_date=start_date, end_date=end_date)
    except Exception as e:
        print(f"Failed to load data for {symbol}: {e}")
        return None

    if ohlc is None or len(ohlc) == 0:
        print(f"No OHLC rows for {symbol} in range; skipping")
        return None

    volume = ohlc['volume'] if 'volume' in ohlc.columns else None
    indicator = ElliottWaveIndicator()
    try:
        waves = indicator.calculate_waves(ohlc, volume)
        patterns = indicator.identify_patterns(waves)
        signals = indicator.generate_signals(ohlc, waves, risk_perc=1.0, account_size=account_size)
    except Exception as e:
        print(f"Indicator failed for {symbol}: {e}")
        return None

    # normalize signals to DataFrame
    if signals is None:
        return None
    if not isinstance(signals, pd.DataFrame):
        try:
            signals = pd.DataFrame(signals)
        except Exception:
            signals = pd.DataFrame([signals])

    if 'trading_symbol' not in signals.columns:
        signals['trading_symbol'] = symbol

    # ensure signal_time exists
    if 'signal_time' not in signals.columns:
        signals['signal_time'] = pd.Timestamp.now()

    # Save per-symbol signals file
    try:
        os.makedirs(outputs_dir, exist_ok=True)
        per_path = os.path.join(outputs_dir, f'{symbol}_signals.csv')
        signals.to_csv(per_path, index=False)
    except Exception as e:
        print(f"Failed to save per-symbol signals for {symbol}: {e}")

    # Save Elliott-wave chart for the symbol (PNG) into outputs/elliot_wave
    try:
        chart_dir = os.path.join(outputs_dir, 'elliot_wave')
        os.makedirs(chart_dir, exist_ok=True)
        chart_path = os.path.join(chart_dir, f'{symbol}_elliott.png')
        # use the plotter's save_path arg to save without showing the interactive window
        plot_elliott_waves(ohlc, waves, signals=signals, title=f'Elliott Waves - {symbol} ({start_date} to {end_date})', save_path=chart_path)
    except Exception as e:
        print(f"Failed to save elliott wave chart for {symbol}: {e}")

    # Build actionable variant (simple filter: ensure confidence column exists)
    actionable = signals.copy()
    if 'confidence' not in actionable.columns:
        actionable['confidence'] = 0.0
    # position_size_int handling
    if 'position_size' in actionable.columns:
        actionable['position_size_int'] = pd.to_numeric(actionable['position_size'], errors='coerce')
        actionable['position_size_int'] = actionable['position_size_int'].apply(lambda x: int(x) if pd.notna(x) else None)
    else:
        actionable['position_size_int'] = None

    # signal_time_ist
    try:
        st = pd.to_datetime(actionable['signal_time'], errors='coerce', utc=True)
        if st.isna().all():
            st = pd.Timestamp.now(tz='UTC')
        st = st.dt.tz_convert('Asia/Kolkata')
        actionable['signal_time_ist'] = st.astype(str)
    except Exception:
        actionable['signal_time_ist'] = pd.to_datetime(actionable['signal_time'], errors='coerce').astype(str)

    # ensure trading_symbol and numeric columns
    actionable['trading_symbol'] = actionable.get('trading_symbol', symbol)
    return actionable


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--months', type=int, default=3)
    p.add_argument('--out', type=str, default=OUTPUTS_DIR_DEFAULT)
    p.add_argument('--account-size', type=float, default=10000.0)
    p.add_argument('--min-confidence', type=float, default=0.0)
    args = p.parse_args()

    # Determine date window using CSV max date sample per symbol by reading a small subset first
    # Use end_date = latest datetime in CSV overall
    try:
        df_hdr = pd.read_csv(CSV_PATH, nrows=1000)
        dt_cols = [c for c in df_hdr.columns if 'date' in c.lower() or 'time' in c.lower() or 'datetime' in c.lower()]
        if dt_cols:
            # parse full CSV datetime column just for max date (could be large; do a chunked read)
            full = pd.read_csv(CSV_PATH, usecols=[dt_cols[0]], parse_dates=[dt_cols[0]])
            max_date = full[dt_cols[0]].max()
        else:
            max_date = pd.Timestamp.now()
    except Exception:
        max_date = pd.Timestamp.now()

    # compute start_date
    try:
        start_candidate = (max_date - pd.DateOffset(months=args.months - 1)).replace(day=1)
        start_date = start_candidate.replace(hour=0, minute=0, second=0, microsecond=0)
        print(start_date)
    except Exception:
        start_date = max_date - pd.DateOffset(months=args.months)
    end_date = max_date.replace(hour=23, minute=59, second=59, microsecond=0)

    all_actionable = []
    for sym in NIFTY50:
        try:
            act = process_symbol(sym, CSV_PATH, start_date, end_date, args.account_size, args.out)
            if act is not None and len(act) > 0:
                # filter by min confidence
                if args.min_confidence > 0.0 and 'confidence' in act.columns:
                    act = act[pd.to_numeric(act['confidence'], errors='coerce') >= args.min_confidence]
                if len(act) > 0:
                    all_actionable.append(act)
        except Exception as e:
            print(f"Error processing {sym}: {e}")

    if not all_actionable:
        print('No actionable signals generated for NIFTY50 list')
        return

    out_df = pd.concat(all_actionable, ignore_index=True)
    out_path = os.path.join(args.out, 'actionable_signals.csv')
    os.makedirs(args.out, exist_ok=True)
    out_df.to_csv(out_path, index=False)
    print(f'Wrote combined actionable_signals.csv -> {out_path}')


if __name__ == '__main__':
    main()
