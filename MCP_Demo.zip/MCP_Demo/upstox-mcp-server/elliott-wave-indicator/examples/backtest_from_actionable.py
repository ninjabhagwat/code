"""
Backtest actionable_signals against an OHLC CSV with provenance and robust duplicate/timestamp handling.

Features added on top of the original prototype:
 - Read trading symbol (trading_symbol/tradingsymbol/symbol/ticker/asset_symbol) from actionable_signals.csv if present.
 - Optionally accept --symbol to override or provide when actionable lacks symbol.
 - If OHLC CSV contains a symbol column, filter OHLC rows to the actionable trading symbol (case-insensitive).
 - If OHLC CSV has no symbol column but actionable contains trading_symbol, require a per-symbol OHLC input or pass --allow-no-symbol to proceed.
 - Detect non-unique OHLC DatetimeIndex and resolve using --dedupe-policy: first|last|avg|offset
 - Nearest-index mapping uses an optional tolerance (--tolerance-seconds) to avoid mapping to distant bars.
 - Added CLI flags: --min-position-size, --dedupe-policy, --debug, default account_size=10000, risk_perc=5.0
 - More detailed skipped diagnostics written to outputs/skipped_actionable_debug.csv

Usage (PowerShell):
  python backtest_from_actionable.py --actionable examples/outputs/actionable_signals.csv \
    --ohlc upstox-mcp-server/historical_candles_data_from_2008.csv --year 2024 --months 2

This script writes per-trade results to outputs/backtest_results_from_actionable.csv
and skipped diagnostics to outputs/skipped_actionable_debug.csv
"""

import os
import argparse
import math
import pandas as pd
import numpy as np
from datetime import datetime


def find_file(candidates):
    for p in candidates:
        if p and os.path.exists(p):
            return p
    return None


def read_actionable(path, debug=False):
    df = pd.read_csv(path, dtype=str)
    # common numeric columns
    for col in ('entry','stop_loss','take_profit','rr','confidence','position_size','position_size_int'):
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')
    # parse signal_time
    if 'signal_time' in df.columns:
        df['signal_time'] = pd.to_datetime(df['signal_time'], errors='coerce')
    elif 'signal_time_ist' in df.columns:
        df['signal_time'] = pd.to_datetime(df['signal_time_ist'], errors='coerce')
    else:
        # try to infer first datetime-like column
        for c in df.columns:
            if 'time' in c.lower() or 'date' in c.lower():
                try:
                    df['signal_time'] = pd.to_datetime(df[c], errors='coerce')
                    break
                except Exception:
                    continue

    # Normalize timestamps: if tz-aware, convert to Asia/Kolkata then drop tz to match typical OHLC naive index
    try:
        if 'signal_time' in df.columns:
            st = df['signal_time']
            if getattr(st.dt, 'tz', None) is not None:
                try:
                    st = st.dt.tz_convert('Asia/Kolkata')
                    st = st.dt.tz_localize(None)
                except Exception:
                    try:
                        st = st.dt.tz_localize('Asia/Kolkata').dt.tz_localize(None)
                    except Exception:
                        st = st.dt.tz_convert(None)
            else:
                st = st.dt.tz_localize(None)
            df['signal_time'] = st
    except Exception:
        pass

    # detect trading symbol provenance in actionable
    symbol_cols = [c for c in df.columns if c.lower() in ('trading_symbol','tradingsymbol','symbol','ticker','asset_symbol')]
    trading_symbol = None
    if symbol_cols:
        # prefer exact 'trading_symbol' if present
        pref = None
        for c in symbol_cols:
            if c.lower() == 'trading_symbol' or c.lower() == 'tradingsymbol':
                pref = c
                break
        if pref is None:
            pref = symbol_cols[0]
        # choose the first non-null symbol or the unique value if only one
        vals = df[pref].dropna().unique()
        if len(vals) > 0:
            trading_symbol = str(vals[0])
            if debug:
                print('Detected trading_symbol in actionable:', trading_symbol, 'from column', pref)
    return df, trading_symbol


def read_ohlc(ohlc_path, filter_symbol=None, debug=False):
    # try to read with a datetime column and common names
    parse_cols = ['datetime','date','timestamp','time']
    hdr = pd.read_csv(ohlc_path, nrows=0)
    cols = list(hdr.columns)
    date_col = None
    for c in parse_cols:
        for h in cols:
            if h.lower() == c:
                date_col = h
                break
        if date_col:
            break
    if date_col is None:
        # fallback to first column that looks like a datetime by sampling
        sample = pd.read_csv(ohlc_path, nrows=20)
        for c in sample.columns:
            try:
                pd.to_datetime(sample[c])
                date_col = c
                break
            except Exception:
                continue
    if date_col is None:
        raise RuntimeError('Unable to find a datetime column in OHLC CSV')

    df = pd.read_csv(ohlc_path, parse_dates=[date_col])

    # If there is a symbol-like column and we have a filter_symbol, apply it
    symbol_cols = [h for h in df.columns if h.lower() in ('trading_symbol','tradingsymbol','symbol','ticker','asset_symbol')]
    if filter_symbol is not None:
        if symbol_cols:
            # case-insensitive compare
            mask = None
            for sc in symbol_cols:
                cur = df[sc].astype(str).str.strip()
                cur_mask = cur.str.lower() == str(filter_symbol).lower()
                if mask is None:
                    mask = cur_mask
                else:
                    mask = mask | cur_mask
            if mask is not None:
                df = df.loc[mask].reset_index(drop=True)
                if debug:
                    print(f'Filtered OHLC rows by symbol {filter_symbol}, remaining rows: {len(df)}')
        else:
            # No symbol column in OHLC - caller should handle enforcement. We keep df as-is.
            if debug:
                print('No symbol column found in OHLC CSV to filter by trading_symbol')

    # set index to date_col
    df = df.set_index(date_col)

    # If OHLC index is timezone-aware, convert to Asia/Kolkata then drop tz (assume CSV times are local IST naive)
    try:
        if hasattr(df.index, 'tz') and df.index.tz is not None:
            try:
                df.index = df.index.tz_convert('Asia/Kolkata').tz_localize(None)
            except Exception:
                try:
                    df.index = df.index.tz_localize('Asia/Kolkata').tz_localize(None)
                except Exception:
                    df.index = pd.DatetimeIndex([pd.to_datetime(t).tz_convert(None) for t in df.index])
    except Exception:
        pass

    # ensure common ohlc columns exist
    for c in ['open','high','low','close','volume']:
        if c not in df.columns:
            # try case-insensitive match
            for h in df.columns:
                if h.lower() == c:
                    df.rename(columns={h: c}, inplace=True)
                    break
    # coerce numeric
    for c in ['open','high','low','close','volume']:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors='coerce')

    # sort index
    try:
        df = df.sort_index()
    except Exception:
        pass

    return df


def resolve_duplicate_index(ohlc_df, policy='first', debug=False):
    # If index already unique, return as-is
    if ohlc_df.index.is_unique:
        return ohlc_df

    if debug:
        print('Duplicate OHLC index detected, applying dedupe policy:', policy)

    if policy == 'first':
        res = ohlc_df[~ohlc_df.index.duplicated(keep='first')]
        return res
    if policy == 'last':
        res = ohlc_df[~ohlc_df.index.duplicated(keep='last')]
        return res
    if policy == 'avg':
        # aggregate numeric columns by mean, volume by sum
        numeric_cols = ohlc_df.select_dtypes(include=[np.number]).columns.tolist()
        # ensure volume aggregation uses sum if present
        agg_map = {c: 'mean' for c in numeric_cols}
        if 'volume' in numeric_cols:
            agg_map['volume'] = 'sum'
        grouped = ohlc_df.groupby(ohlc_df.index).agg(agg_map)
        return grouped
    if policy == 'offset':
        # create tiny offsets (microseconds) to make index unique while preserving ordering
        new_index = []
        last_ts = None
        dup_count = 0
        for ts in ohlc_df.index:
            if last_ts is None or ts != last_ts:
                dup_count = 0
                new_index.append(ts)
                last_ts = ts
            else:
                dup_count += 1
                new_ts = ts + pd.Timedelta(microseconds=dup_count)
                new_index.append(new_ts)
        ohlc_df = ohlc_df.copy()
        ohlc_df.index = pd.DatetimeIndex(new_index)
        return ohlc_df

    # fallback: keep first
    return ohlc_df[~ohlc_df.index.duplicated(keep='first')]


def first_touch_exit(ohlc_df, start_pos, entry, sl, tp, side, lookahead_bars=None):
    n = len(ohlc_df)
    if lookahead_bars is None:
        end_pos = n - 1
    else:
        end_pos = min(n - 1, start_pos + int(lookahead_bars) + 1)

    def bar_prices(idx):
        row = ohlc_df.iloc[idx]
        return float(row['open']), float(row['high']), float(row['low']), float(row['close'])

    exit_price = None
    exit_pos = None
    exit_reason = None

    # scan forward bar by bar
    for pos in range(start_pos + 1, end_pos + 1):
        try:
            o,h,l,c = bar_prices(pos)
        except Exception:
            continue
        if side == 'BUY':
            seq = [o,h,l,c]
            for price in seq:
                if tp is not None and price >= tp:
                    exit_price = float(tp)
                    exit_pos = pos
                    exit_reason = 'TP'
                    break
                if sl is not None and price <= sl:
                    exit_price = float(sl)
                    exit_pos = pos
                    exit_reason = 'SL'
                    break
            if exit_price is not None:
                break
        else:
            seq = [o,l,h,c]
            for price in seq:
                if tp is not None and price <= tp:
                    exit_price = float(tp)
                    exit_pos = pos
                    exit_reason = 'TP'
                    break
                if sl is not None and price >= sl:
                    exit_price = float(sl)
                    exit_pos = pos
                    exit_reason = 'SL'
                    break
            if exit_price is not None:
                break

    if exit_price is None:
        last_close = float(ohlc_df.iloc[end_pos]['close'])
        exit_price = last_close
        exit_pos = end_pos
        exit_reason = 'no_exit'

    return exit_price, exit_pos, exit_reason


def run_backtest(actionable_csv=None, ohlc_csv=None, outputs_dir=None, account_size=10000.0, risk_perc=5.0,
                 commission_per_trade=0.0, slippage_pct=0.0, lookahead_bars=None, dedupe_policy='first',
                 min_position_size=1, tolerance_seconds=30, symbol_override=None, debug=False, allow_no_symbol=False):
    # locate files if not provided
    cand_actionable = [actionable_csv,
                       os.path.join(os.path.dirname(__file__), 'outputs', 'actionable_signals.csv'),
                       os.path.join(os.path.dirname(__file__), 'actionable_signals.csv'),
                       os.path.join(os.path.dirname(os.path.dirname(__file__)), 'actionable_signals.csv'),
                       os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'actionable_signals.csv'),
                       'actionable_signals.csv']
    actionable_path = find_file([p for p in cand_actionable if p])
    if actionable_csv is not None and actionable_path is None:
        actionable_path = actionable_csv if os.path.exists(actionable_csv) else None

    if actionable_path is None:
        raise RuntimeError('actionable_signals.csv not found in expected locations; please pass --actionable')

    cand_ohlc = [ohlc_csv,
                 os.path.join(os.path.dirname(os.path.dirname(__file__)), 'historical_candles_data_from_2008.csv'),
                 os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'historical_candles_data_from_2008.csv'),
                 os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))), 'historical_candles_data_from_2008.csv')]
    ohlc_path = find_file([p for p in cand_ohlc if p])
    if ohlc_csv is not None and ohlc_path is None:
        ohlc_path = ohlc_csv if os.path.exists(ohlc_csv) else None

    if ohlc_path is None:
        if os.path.exists('historical_candles_data_from_2008.csv'):
            ohlc_path = 'historical_candles_data_from_2008.csv'
        else:
            raise RuntimeError('OHLC CSV not found; please pass --ohlc')

    if outputs_dir is None:
        outputs_dir = os.path.join(os.path.dirname(__file__), 'outputs')
    os.makedirs(outputs_dir, exist_ok=True)

    if debug:
        print('Using actionable csv:', actionable_path)
        print('Using ohlc csv:', ohlc_path)
        print('Outputs dir:', outputs_dir)

    actionable, detected_symbol = read_actionable(actionable_path, debug=debug)

    # determine trading_symbol to enforce
    trading_symbol = symbol_override or detected_symbol
    if debug:
        print('Symbol override:', symbol_override, 'detected in actionable:', detected_symbol, 'using:', trading_symbol)

    # detect which column in the actionable holds symbol provenance (if any)
    actionable_symbol_col = None
    for c in actionable.columns:
        if c.lower() in ('trading_symbol','tradingsymbol','symbol','ticker','asset_symbol'):
            actionable_symbol_col = c
            break
    if debug:
        print('Actionable symbol column detected:', actionable_symbol_col)

    # read ohlc (pass symbol filter if available)
    ohlc = read_ohlc(ohlc_path, filter_symbol=trading_symbol if trading_symbol is not None else None, debug=debug)

    # If actionable had a trading_symbol but ohlc had no symbol column and was not filtered, enforce requirement
    # detect if ohlc contained symbol columns earlier by reading header
    hdr = pd.read_csv(ohlc_path, nrows=0)
    ohlc_symbol_cols = [h for h in hdr.columns if h.lower() in ('trading_symbol','tradingsymbol','symbol','ticker','asset_symbol')]
    if trading_symbol is not None and not ohlc_symbol_cols:
        if not allow_no_symbol:
            raise RuntimeError('actionable_signals.csv contains a trading symbol but OHLC CSV has no symbol column. Provide per-symbol OHLC or re-run with --allow-no-symbol to bypass this enforcement.')
        else:
            if debug:
                print('Allowing no-symbol OHLC despite actionable specifying trading_symbol')

    # resolve duplicate index if necessary
    if not ohlc.index.is_unique:
        ohlc = resolve_duplicate_index(ohlc, policy=dedupe_policy, debug=debug)

    # Diagnostics: basic counts and time ranges to help explain mapping failures
    try:
        actionable['signal_time'] = pd.to_datetime(actionable.get('signal_time', None), errors='coerce')
    except Exception:
        pass
    if debug:
        print(f"Actionable rows: {len(actionable)}")
        try:
            print('Actionable signal_time min/max:', actionable['signal_time'].min(), actionable['signal_time'].max())
        except Exception:
            pass
        try:
            print('OHLC index min/max:', ohlc.index.min(), ohlc.index.max())
        except Exception:
            pass

    # Collect skipped rows for diagnostics
    skipped = []
    skip_counts = {}

    results = []
    for idx, s in actionable.iterrows():
        try:
            ts = s.get('signal_time')
            skip_reason = None
            if pd.isna(ts):
                skip_reason = 'no_signal_time'
                skipped.append({'actionable_index': idx, 'skip_reason': skip_reason})
                skip_counts[skip_reason] = skip_counts.get(skip_reason, 0) + 1
                continue

            # normalize per-row timestamp to naive timestamps that align with OHLC index
            try:
                ts_ts = pd.to_datetime(ts)
            except Exception:
                ts_ts = pd.to_datetime(ts, errors='coerce')

            # If tz-aware, convert to Asia/Kolkata and drop tz to match most CSVs that are naive IST
            try:
                if isinstance(ts_ts, pd.Timestamp) and getattr(ts_ts, 'tz', None) is not None:
                    try:
                        ts_norm = ts_ts.tz_convert('Asia/Kolkata').tz_localize(None)
                    except Exception:
                        try:
                            ts_norm = ts_ts.tz_localize('Asia/Kolkata').tz_localize(None)
                        except Exception:
                            ts_norm = ts_ts.tz_convert(None)
                else:
                    ts_norm = pd.to_datetime(ts_ts)
            except Exception:
                ts_norm = pd.to_datetime(ts_ts, errors='coerce')

            if pd.isna(ts_norm):
                skip_reason = 'bad_parsed_time'
                skipped.append({'actionable_index': idx, 'skip_reason': skip_reason})
                skip_counts[skip_reason] = skip_counts.get(skip_reason, 0) + 1
                continue

            # quick range check against OHLC data
            try:
                if ts_norm < ohlc.index.min() or ts_norm > ohlc.index.max():
                    skip_reason = 'out_of_range'
                    skipped.append({'actionable_index': idx, 'skip_reason': skip_reason})
                    skip_counts[skip_reason] = skip_counts.get(skip_reason, 0) + 1
                    continue
            except Exception:
                pass

            # map to nearest position in OHLC with tolerance
            try:
                pos_arr = ohlc.index.get_indexer([ts_norm], method='nearest')
            except Exception as e:
                # fallback: use searchsorted on sorted index
                try:
                    i = ohlc.index.searchsorted(ts_norm)
                    if i >= len(ohlc.index):
                        pos = len(ohlc.index) - 1
                    else:
                        pos = i
                    pos_arr = np.array([pos])
                except Exception:
                    skip_reason = 'no_index_match'
                    skipped.append({'actionable_index': idx, 'skip_reason': skip_reason})
                    skip_counts[skip_reason] = skip_counts.get(skip_reason, 0) + 1
                    continue

            if len(pos_arr) == 0 or pos_arr[0] < 0:
                skip_reason = 'no_index_match'
                skipped.append({'actionable_index': idx, 'skip_reason': skip_reason})
                skip_counts[skip_reason] = skip_counts.get(skip_reason, 0) + 1
                continue

            start_pos = int(pos_arr[0])
            # enforce tolerance (seconds)
            try:
                mapped_ts = ohlc.index[start_pos]
                delta = abs(mapped_ts - pd.to_datetime(ts_norm))
                if pd.Timedelta(seconds=tolerance_seconds) < delta:
                    skip_reason = 'index_too_far'
                    skipped.append({'actionable_index': idx, 'skip_reason': skip_reason})
                    skip_counts[skip_reason] = skip_counts.get(skip_reason, 0) + 1
                    if debug:
                        print(f'Row {idx} mapped_ts {mapped_ts} too far from signal {ts_norm} (delta {delta})')
                    continue
            except Exception:
                pass

            entry = float(s.get('entry')) if pd.notna(s.get('entry')) else None
            sl = float(s.get('stop_loss')) if pd.notna(s.get('stop_loss')) else None
            tp = float(s.get('take_profit')) if pd.notna(s.get('take_profit')) else None
            side = str(s.get('side')).upper() if pd.notna(s.get('side')) else 'BUY'

            if entry is None or sl is None or tp is None:
                skip_reason = 'missing_entry_sl_tp'
                skipped.append({'actionable_index': idx, 'skip_reason': skip_reason})
                skip_counts[skip_reason] = skip_counts.get(skip_reason, 0) + 1
                continue

            # determine position size
            pos_size = None
            if 'position_size_int' in actionable.columns and pd.notna(s.get('position_size_int')):
                try:
                    pos_size = int(s.get('position_size_int'))
                except Exception:
                    pos_size = None
            if pos_size is None:
                risk_amount = float(account_size) * (float(risk_perc) / 100.0)
                sl_dist = abs(entry - sl)
                if sl_dist <= 0:
                    pos_size = 0
                else:
                    pos_size = int(math.floor(risk_amount / sl_dist))

            if pos_size <= 0:
                # apply min_position_size as fallback
                if min_position_size and min_position_size > 0:
                    pos_size = int(min_position_size)
                else:
                    skip_reason = 'zero_position_size'
                    skipped.append({'actionable_index': idx, 'skip_reason': skip_reason})
                    skip_counts[skip_reason] = skip_counts.get(skip_reason, 0) + 1
                    continue

            # Enforce cash cap: ensure position_size * entry <= account_size
            try:
                max_by_cash = int(math.floor(float(account_size) / float(entry))) if entry and entry > 0 else 0
            except Exception:
                max_by_cash = 0
            if max_by_cash <= 0:
                skip_reason = 'insufficient_cash'
                skipped.append({'actionable_index': idx, 'skip_reason': skip_reason})
                skip_counts[skip_reason] = skip_counts.get(skip_reason, 0) + 1
                continue
            capped_to_account = False
            if pos_size > max_by_cash:
                pos_size = int(max_by_cash)
                capped_to_account = True

            exit_price, exit_pos, exit_reason = first_touch_exit(ohlc, start_pos, entry, sl, tp, side, lookahead_bars)

            # slippage and commission
            slippage_cost = float(slippage_pct) * float(entry) * float(pos_size)
            commission_cost = float(commission_per_trade)

            if side == 'BUY':
                pnl_per_share = exit_price - entry
            else:
                pnl_per_share = entry - exit_price

            gross_pnl = pnl_per_share * float(pos_size)
            net_pnl = gross_pnl - slippage_cost - commission_cost

            # determine per-row trading symbol to include in results (prefer actionable column, fallback to detected/override)
            try:
                if actionable_symbol_col and pd.notna(s.get(actionable_symbol_col)):
                    per_row_symbol = s.get(actionable_symbol_col)
                else:
                    per_row_symbol = trading_symbol
            except Exception:
                per_row_symbol = trading_symbol

            results.append({
                'signal_time': ts,
                'signal_time_ist': pd.to_datetime(ts).tz_convert('Asia/Kolkata').strftime('%Y-%m-%d %H:%M:%S%z') if hasattr(pd.to_datetime(ts), 'tzinfo') and pd.to_datetime(ts).tzinfo is not None else str(ts),
                'side': side,
                'entry': entry,
                'exit_price': exit_price,
                'exit_reason': exit_reason,
                'entry_pos': start_pos,
                'exit_pos': exit_pos,
                'position_size': pos_size,
                'gross_pnl': gross_pnl,
                'net_pnl': net_pnl,
                'skip_reason': '',
                'trading_symbol': per_row_symbol,
                'capped_to_account': capped_to_account
            })
        except Exception as e:
            try:
                msg = str(e)
                skipped.append({'actionable_index': idx, 'skip_reason': 'exception: ' + msg})
                skip_counts['exception'] = skip_counts.get('exception', 0) + 1
                if debug and skip_counts['exception'] < 6:
                    print(f"Row {idx} exception: {msg}")
            except Exception:
                pass
            continue

    res_df = pd.DataFrame(results)
    if len(res_df) == 0:
        print('No backtest trades produced.')
        try:
            skip_df = pd.DataFrame(skipped)
            skip_out = os.path.join(outputs_dir, 'skipped_actionable_debug.csv')
            skip_df.to_csv(skip_out, index=False)
            print('Wrote skipped actionable diagnostics ->', skip_out)
            print('Skip counts:', skip_counts)
        except Exception:
            pass
        return

    out_path = os.path.join(outputs_dir, 'backtest_results_from_actionable.csv')
    res_df.to_csv(out_path, index=False)
    print('Saved backtest results ->', out_path)

    try:
        if len(skipped) > 0:
            skip_df = pd.DataFrame(skipped)
            skip_out = os.path.join(outputs_dir, 'skipped_actionable_debug.csv')
            skip_df.to_csv(skip_out, index=False)
            if debug:
                print('Wrote skipped actionable diagnostics ->', skip_out)
                print('Skip counts:', skip_counts)
    except Exception:
        pass

    total_net = res_df['net_pnl'].sum()
    total_gross = res_df['gross_pnl'].sum()
    num_trades = len(res_df)
    wins = (res_df['net_pnl'] > 0).sum()
    win_rate = float(wins) / num_trades if num_trades > 0 else 0.0
    avg_net = res_df['net_pnl'].mean()
    ret_pct = (total_net / float(account_size)) * 100.0

    summary = {
        'num_trades': int(num_trades),
        'wins': int(wins),
        'win_rate': float(win_rate),
        'total_net_pnl': float(total_net),
        'total_gross_pnl': float(total_gross),
        'avg_net_pnl': float(avg_net),
        'return_pct': float(ret_pct),
    }

    print('\nBacktest summary:')
    for k,v in summary.items():
        print(f"{k}: {v}")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Backtest actionable_signals against OHLC CSV')
    parser.add_argument('--actionable', help='path to actionable_signals.csv (optional)')
    parser.add_argument('--ohlc', help='path to OHLC CSV (optional)')
    parser.add_argument('--outputs', help='outputs dir (optional)', default=None)
    parser.add_argument('--account-size', type=float, default=10000.0)
    parser.add_argument('--risk-perc', type=float, default=5.0)
    parser.add_argument('--commission', type=float, default=0.0)
    parser.add_argument('--slippage', type=float, default=0.0, help='slippage as fraction of price (e.g. 0.001)')
    parser.add_argument('--lookahead', type=int, default=None, help='number of bars to scan forward for TP/SL')
    parser.add_argument('--dedupe-policy', choices=['first','last','avg','offset'], default='first', help='policy to resolve duplicate OHLC timestamps')
    parser.add_argument('--min-position-size', type=int, default=1, help='minimum position size fallback when computed size is zero')
    parser.add_argument('--tolerance-seconds', type=int, default=30, help='max seconds distance when mapping signal time to OHLC index')
    parser.add_argument('--symbol', help='override trading symbol (optional)')
    parser.add_argument('--allow-no-symbol', action='store_true', help='allow OHLC without symbol column even when actionable has trading_symbol')
    parser.add_argument('--debug', action='store_true', help='enable debug prints')
    args = parser.parse_args()

    run_backtest(actionable_csv=args.actionable, ohlc_csv=args.ohlc, outputs_dir=args.outputs, account_size=args.account_size,
                 risk_perc=args.risk_perc, commission_per_trade=args.commission, slippage_pct=args.slippage,
                 lookahead_bars=args.lookahead, dedupe_policy=args.dedupe_policy, min_position_size=args.min_position_size,
                 tolerance_seconds=args.tolerance_seconds, symbol_override=args.symbol, debug=args.debug,
                 allow_no_symbol=args.allow_no_symbol)
