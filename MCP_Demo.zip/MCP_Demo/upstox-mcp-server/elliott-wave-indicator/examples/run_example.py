from src.data.loader import load_ohlc_data
from src.indicators.elliott import ElliottWaveIndicator
from src.visualization.plotter import plot_elliott_waves
import pandas as pd
import os
import math


def choose_asset_symbol_from_sample(df, preferred_cols=('trading_symbol', 'asset_symbol', 'tradingsymbol', 'symbol', 'ticker')):
    """Choose trading_symbol from a small sample DataFrame and return the canonical CSV value.

    This function now supports:
    - exact case-insensitive matches returning the canonical value from the sample list
    - substring/contains matches with disambiguation if multiple results
    - numeric selection from displayed list
    """
    if df is None or not hasattr(df, 'columns'):
        return None, None

    # prefer trading_symbol column if present
    symbol_col = next((c for c in df.columns if str(c).lower() in [p.lower() for p in preferred_cols]), None)
    if symbol_col is None:
        return None, None

    unique_vals = [v for v in df[symbol_col].dropna().unique()]
    if len(unique_vals) == 0:
        return None, symbol_col

    print(f"Detected symbol column: '{symbol_col}'. Found {len(unique_vals)} unique assets in sample.")
    print("Choose a trading symbol to analyze (enter number, exact symbol text, or partial substring).")

    # helper to show a list with indices
    def show_list(vals):
        for i, v in enumerate(vals[:50], start=1):
            print(f"{i}. {v}")
        if len(vals) > 50:
            print(f"...and {len(vals)-50} more")

    show_list(unique_vals)

    # require explicit valid selection
    while True:
        choice = input("Enter number or symbol (required): ").strip()
        if not choice:
            print("Please enter a trading symbol or a number from the list.")
            continue

        # numeric selection
        try:
            idx = int(choice)
            if 1 <= idx <= len(unique_vals):
                return unique_vals[idx - 1], symbol_col
            else:
                print("Number out of range; try again.")
                continue
        except Exception:
            pass

        # exact case-insensitive match -> return canonical value
        for v in unique_vals:
            try:
                if str(v).strip().lower() == choice.lower():
                    return v, symbol_col
            except Exception:
                continue

        # substring/contains fallback (case-insensitive)
        matches = [v for v in unique_vals if choice.lower() in str(v).strip().lower()]
        if len(matches) == 1:
            return matches[0], symbol_col
        elif len(matches) > 1:
            print(f"Found {len(matches)} matches for '{choice}'. Narrow down by picking a number:")
            show_list(matches)
            # loop will continue and accept a numeric selection
            unique_vals = matches
            continue

        print("Symbol not found in sample; please try again.")


def main():
    csv_path = r'C:\Niranjan\Personal\MCP_Demo\upstox-mcp-server\historical_candles_latest.csv'

    # Try to read trading_symbol list quickly so we can prompt the user immediately
    try:
        sym_df = pd.read_csv(csv_path, usecols=['trading_symbol'], dtype=str, nrows=50000)
        unique_syms = list(pd.Series(sym_df['trading_symbol'].dropna().unique()))
        # build a tiny dataframe for the chooser (one row per symbol)
        sample = pd.DataFrame({'trading_symbol': unique_syms})
    except Exception:
        # fall back to the general loader sample (may be slower)
        sample = load_ohlc_data(csv_path, nrows=5000)
    chosen_symbol, symbol_col = choose_asset_symbol_from_sample(sample)

    # add debug print of the resolved canonical symbol and symbol column
    print(f"Resolved chosen_symbol (canonical): {repr(chosen_symbol)}, symbol_col: {repr(symbol_col)}")

    # Ask year
    year_input = input("Enter year to analyze (e.g. 2025) [default 2025]: ").strip()
    try:
        year = int(year_input) if year_input else 2025
    except Exception:
        print("Invalid year input, defaulting to 2025")
        year = 2025

    # Determine the highest available date for the chosen year (and symbol if provided)
    # Read only datetime for the year/symbol to find the latest date quickly
    # include the resolved symbol column in the quick sample so the loader can
    # apply symbol-based filtering while chunking. If symbol_col is None,
    # fallback to reading only datetime.
    sample_usecols = ['datetime']
    if symbol_col:
        sample_usecols.append(symbol_col)
    sample_year = load_ohlc_data(csv_path, year=year, asset_symbol=chosen_symbol, usecols=sample_usecols)

    # diagnostic info after sample_year read
    if sample_year is None:
        print("sample_year read returned None")
        return
    print(f"sample_year rows: {len(sample_year)}")
    if hasattr(sample_year, 'index') and isinstance(sample_year.index, pd.DatetimeIndex):
        print("sample_year index is a DatetimeIndex and was parsed")
    else:
        print(f"sample_year columns: {list(sample_year.columns)}")

    # additional diagnostic: if symbol column is present in the sample, show basic counts
    try:
        if symbol_col and symbol_col in sample_year.columns:
            ser = sample_year[symbol_col].astype(str).str.strip()
            total_sample = len(ser)
            exact = (ser.str.lower() == str(chosen_symbol).strip().lower()).sum()
            contains = ser.str.lower().str.contains(str(chosen_symbol).strip().lower(), na=False).sum()
            print(f"Diagnostic: sample symbol col '{symbol_col}': total_rows_in_sample={total_sample}, exact_matches={exact}, contains={contains}")
    except Exception:
        pass

    if sample_year is None or len(sample_year) == 0:
        print(f"No data found for year {year} (and symbol {chosen_symbol or 'ALL'}).")
        return

    # sample_year will have datetime as index if load_ohlc_data parsed it
    if hasattr(sample_year, 'index') and isinstance(sample_year.index, pd.DatetimeIndex):
        max_date = sample_year.index.max()
    elif 'datetime' in sample_year.columns:
        max_date = pd.to_datetime(sample_year['datetime']).max()
    else:
        # try to infer from any datetime-like column
        dt_cols = [c for c in sample_year.columns if 'date' in c.lower() or 'time' in c.lower()]
        if dt_cols:
            max_date = pd.to_datetime(sample_year[dt_cols[0]]).max()
        else:
            print("Unable to determine max date from sample; aborting.")
            return

    # Ask how many last months to include relative to max_date
    months_input = input(f"Enter how many last months to include ending at {max_date.date()} (e.g. 3) [default 3]: ").strip()
    try:
        last_months = int(months_input) if months_input else 3
        if last_months < 1:
            raise ValueError()
    except Exception:
        print("Invalid months input, defaulting to 3")
        last_months = 3

    # Compute start_date as first day of the month that is (last_months-1) months before max_date's month
    start_candidate = (max_date - pd.DateOffset(months=last_months - 1)).replace(day=1)
    # create timezone-aware start/end timestamps (preserve tzinfo from max_date)
    try:
        start_ts = start_candidate.replace(hour=0, minute=0, second=0, microsecond=0)
    except Exception:
        # fallback if replace fails (e.g., naive datetime)
        start_ts = pd.Timestamp(start_candidate).replace(hour=0, minute=0, second=0, microsecond=0)
    try:
        end_ts = max_date.replace(hour=23, minute=59, second=59, microsecond=0)
    except Exception:
        end_ts = pd.Timestamp(max_date).replace(hour=23, minute=59, second=59, microsecond=0)

    # use Timestamp objects (tz-aware if max_date was tz-aware) when calling the loader
    start_date = start_ts
    end_date = end_ts

    print(f"Loading data for symbol: {chosen_symbol or 'ALL'} from {start_date} to {end_date} (based on max date {max_date.date()})")

    # Load only the requested date range and symbol to speed up processing
    # pass Timestamp objects so loader can detect/align timezones with the CSV datetimes
    ohlc_data = load_ohlc_data(csv_path, asset_symbol=chosen_symbol, start_date=start_date, end_date=end_date)

    if ohlc_data is None or len(ohlc_data) == 0:
        print("No data found for the selected symbol and date range.")
        # run a small diagnostic read to show counts and help debug matching
        try:
            dbg_usecols = [c for c in ['datetime', symbol_col] if c in pd.read_csv(csv_path, nrows=0).columns]
            dbg = pd.read_csv(csv_path, usecols=dbg_usecols, dtype=str, nrows=200000, parse_dates=['datetime'] if 'datetime' in dbg_usecols else None)
            # show basic counts
            if symbol_col in dbg.columns:
                sym_series = dbg[symbol_col].astype(str).str.strip()
                total = len(dbg)
                matching = (sym_series.str.lower() == str(chosen_symbol).strip().lower()).sum()
                contains = sym_series.str.lower().str.contains(str(chosen_symbol).strip().lower(), na=False).sum()
                print(f"Diagnostic read rows scanned: {total}")
                print(f"Exact-case-insensitive matches in sample scan: {matching}")
                print(f"Substring matches in sample scan: {contains}")
                print("Top unique symbols (head 20):", list(sym_series.dropna().unique()[:20]))
            else:
                print("Symbol column not found in diagnostic read; header cols:", list(dbg.columns))
        except Exception as e:
            print("Diagnostic read failed:", e)
        return

    # Prepare volume data
    volume_data = ohlc_data['volume'] if 'volume' in ohlc_data.columns else None

    # Initialize the Elliott Wave Indicator
    indicator = ElliottWaveIndicator()

    # Calculate Elliott Waves (pass both ohlc and volume)
    waves = indicator.calculate_waves(ohlc_data, volume_data)

    # Identify patterns
    patterns = indicator.identify_patterns(waves)

    # Generate trading signals from detected waves (simple heuristic)
    try:
        account_size_var = 10000
        signals = indicator.generate_signals(ohlc_data, waves, risk_perc=1.0, account_size=account_size_var)
    except Exception:
        signals = None

    # Print and optionally persist signals for inspection
    if signals is not None and len(signals) > 0:
        # normalize signals to DataFrame and ensure provenance column `trading_symbol` exists
        if not isinstance(signals, pd.DataFrame):
            try:
                signals = pd.DataFrame(signals)
            except Exception:
                signals = pd.DataFrame([signals])
        if 'trading_symbol' not in signals.columns:
            signals['trading_symbol'] = chosen_symbol

        # Print and save signals.csv (with fallback to temp dir)
        try:
            print("\nGenerated signals:")
            print(signals.to_string(index=False))
            outputs_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), 'outputs'))
            os.makedirs(outputs_dir, exist_ok=True)
            signals_path = os.path.join(outputs_dir, 'signals.csv')
            signals.to_csv(signals_path, index=False)
            print(f"Saved signals.csv -> {signals_path}")
        except Exception:
            try:
                import tempfile
                tmp = tempfile.gettempdir()
                signals_path = os.path.join(tmp, 'signals.csv')
                signals.to_csv(signals_path, index=False)
                print(f"Saved signals.csv -> {signals_path} (temp dir fallback)")
            except Exception as e:
                print(f"Failed to save signals.csv to both outputs dir and temp dir: {e}")

        # --- create actionable_signals (keep original signals.csv intact) ---
        try:
            actionable = signals.copy()
            # ensure numeric confidence
            if 'confidence' in actionable.columns:
                actionable['confidence'] = pd.to_numeric(actionable['confidence'], errors='coerce')
            else:
                actionable['confidence'] = 0.0

            if 'trading_symbol' not in actionable.columns:
                actionable['trading_symbol'] = chosen_symbol

            # convert signal_time to timezone-aware IST timestamps for display and export
            try:
                # Ensure there is a fresh signal_time for actionable signals so executors pick the latest
                if 'signal_time' not in actionable.columns:
                    actionable['signal_time'] = pd.Timestamp.now(tz='UTC')
                else:
                    try:
                        parsed_check = pd.to_datetime(actionable['signal_time'], errors='coerce', utc=True)
                        if parsed_check.isna().all():
                            actionable['signal_time'] = pd.Timestamp.now(tz='UTC')
                    except Exception:
                        actionable['signal_time'] = pd.Timestamp.now(tz='UTC')

                st = pd.to_datetime(actionable['signal_time'], errors='coerce')
                if getattr(st.dt, 'tz', None) is None:
                    try:
                        st = st.dt.tz_localize('UTC')
                    except Exception:
                        pass
                st = st.dt.tz_convert('Asia/Kolkata')
                actionable['signal_time_ist'] = st.astype(str)
            except Exception:
                actionable['signal_time_ist'] = actionable.get('signal_time', '').astype(str)

            # compute integer position sizes and enforce per-trade cash cap so position_size * entry <= account_size_var
            if 'position_size' in actionable.columns:
                actionable['position_size'] = pd.to_numeric(actionable['position_size'], errors='coerce')
                actionable['position_size_int'] = actionable['position_size'].apply(lambda x: int(x) if pd.notna(x) else None)
            else:
                actionable['position_size_int'] = None

            # enforce cash cap per row using account_size_var defined above
            def _cap_row(row):
                psz = row.get('position_size_int')
                try:
                    entry_price = float(row.get('entry')) if pd.notna(row.get('entry')) else None
                except Exception:
                    entry_price = None
                if psz is None or pd.isna(psz):
                    return pd.Series({'position_size_int': psz, 'capped_to_account': False})
                try:
                    psz_int = int(psz)
                except Exception:
                    return pd.Series({'position_size_int': psz, 'capped_to_account': False})
                if entry_price is None or entry_price <= 0:
                    return pd.Series({'position_size_int': psz_int, 'capped_to_account': False})
                max_by_cash = int(math.floor(account_size_var / entry_price)) if entry_price and entry_price > 0 else 0
                if max_by_cash <= 0:
                    return pd.Series({'position_size_int': 0, 'capped_to_account': True})
                if psz_int > max_by_cash:
                    return pd.Series({'position_size_int': max_by_cash, 'capped_to_account': True})
                return pd.Series({'position_size_int': psz_int, 'capped_to_account': False})

            try:
                caps = actionable.apply(_cap_row, axis=1)
                actionable['position_size_int'] = caps['position_size_int']
                actionable['capped_to_account'] = caps['capped_to_account']
            except Exception:
                actionable['capped_to_account'] = False

            # filter actionable signals: confirmed True OR high-confidence (>= 0.8)
            min_conf = 0.8
            cond_confirmed = actionable['confirmed'] == True if 'confirmed' in actionable.columns else False
            cond_conf = actionable['confidence'] >= float(min_conf)
            actionable_filtered = actionable.loc[cond_confirmed | cond_conf].copy()

            # select and reorder columns for a compact printable table
            display_cols = ['signal_time_ist', 'wave_label', 'entry_type', 'side', 'entry', 'stop_loss', 'take_profit', 'rr', 'confidence', 'position_size_int']
            display_cols = [c for c in display_cols if c in actionable_filtered.columns]

            print('\nActionable signals (confirmed OR confidence >= {:.2f}):'.format(min_conf))
            if len(actionable_filtered) == 0:
                print('No actionable signals found with the current filters.')
            else:
                af = actionable_filtered.copy()
                for c in ['entry','stop_loss','take_profit','rr','confidence']:
                    if c in af.columns:
                        af[c] = pd.to_numeric(af[c], errors='coerce').round(4)
                print(af[display_cols].to_string(index=False))

            # save actionable signals as a separate CSV (timestamps converted to IST string)
            try:
                actionable_path = os.path.join(outputs_dir, 'actionable_signals.csv')
                if 'trading_symbol' not in actionable_filtered.columns:
                    actionable_filtered['trading_symbol'] = chosen_symbol
                actionable_filtered.to_csv(actionable_path, index=False)
                print(f"Saved actionable_signals.csv -> {actionable_path}")
            except Exception:
                try:
                    import tempfile
                    tmp = tempfile.gettempdir()
                    actionable_path = os.path.join(tmp, 'actionable_signals.csv')
                    actionable_filtered.to_csv(actionable_path, index=False)
                    print(f"Saved actionable_signals.csv -> {actionable_path} (temp dir fallback)")
                except Exception as e:
                    print(f"Failed to save actionable_signals.csv to outputs or temp dir: {e}")

        except Exception as e:
            print('Failed to build actionable_signals:', e)
    else:
        print("No signals generated from the detected waves.")

    # Plot the Elliott Waves (include signals so entries/SL/TP are annotated)
    plot_elliott_waves(ohlc_data, waves, signals=signals, title=f'Elliott Waves - {chosen_symbol or "All"} ({start_date} to {end_date})')


if __name__ == "__main__":
    main()