r"""
Quick universe scanner for Elliott-wave strategy.

This script scans an OHLC CSV (multi-symbol) or a provided symbol list and runs
- Elliott-wave signal generator (via `src.indicators.elliott.ElliottWaveIndicator`)
- A quick per-symbol backtest using the existing `examples/backtest_from_actionable.py` logic

It produces `examples/outputs/scan/scan_summary.csv` with per-symbol metrics so you can pick the best symbols.

Usage (PowerShell):
  python .\examples\scan_universe.py --ohlc ..\historical_candles_latest.csv --top-n 30 --account-size 10000 --risk-perc 5

Notes:
- This is a prototype: it runs each symbol sequentially (no parallelism). For large universes, run in batches or add multiprocessing.
- The scanner creates temporary actionable CSVs per symbol and calls the backtest module to evaluate performance; per-symbol outputs are stored under outputs/scan/<SYMBOL>/ .
"""

import os
import argparse
import tempfile
import math
import pandas as pd
import runpy
from src.data.loader import load_ohlc_data
from src.indicators.elliott import ElliottWaveIndicator


def discover_symbols_from_ohlc(ohlc_csv, sample_rows=10000, symbol_col_candidates=None):
    if symbol_col_candidates is None:
        symbol_col_candidates = ['trading_symbol','asset_symbol','tradingsymbol','symbol','ticker']

    # Read header to preserve original column names
    try:
        hdr = pd.read_csv(ohlc_csv, nrows=0)
        orig_cols = list(hdr.columns)
    except Exception:
        small = pd.read_csv(ohlc_csv, nrows=5, dtype=str)
        orig_cols = list(small.columns)

    print(f"[debug] header columns: {orig_cols}")

    # Preferred candidate order to try (explicit)
    preferred = ['trading_symbol', 'tradingsymbol', 'asset_symbol', 'symbol', 'ticker']

    # Helper: collect unique symbols from a column using chunked reads to avoid file-head bias
    def collect_unique_for_column(col, max_chunks=10, chunksize=20000):
        uniq_set = set()
        try:
            for i, chunk in enumerate(pd.read_csv(ohlc_csv, usecols=[col], dtype=str, chunksize=chunksize)):
                vals = chunk[col].dropna().astype(str).str.strip()
                vals = vals[~vals.isin(['', 'nan', 'None', 'NONE', 'NA', 'N/A'])]
                uniq_set.update(vals.unique())
                if (i + 1) >= max_chunks:
                    break
                # small early exit if we already have a reasonably large universe
                if len(uniq_set) > 500:
                    break
        except Exception:
            return []
        uniq_list = sorted([s for s in uniq_set if s is not None and str(s).strip() != ''])
        return uniq_list

    # Try preferred candidates using chunked sampling
    for pref in preferred:
        matches = [c for c in orig_cols if c.strip().lower() == pref]
        for cand in matches:
            uniq = collect_unique_for_column(cand)
            print(f"[debug] tested column '{cand}': unique_symbols={len(uniq)}")
            if uniq:
                print('Detected symbol column for scanning:', cand)
                return uniq, cand

    # If no preferred candidate yielded values, fall back to scanning all columns heuristically
    print('[debug] preferred columns yielded no symbols; falling back to heuristic scan across columns')
    # Probe first few chunks of the file to score columns
    try:
        chunk_iter = pd.read_csv(ohlc_csv, dtype=str, chunksize=20000)
        probe_chunks = []
        for i, ch in enumerate(chunk_iter):
            probe_chunks.append(ch)
            if i >= 2:  # probe first 3 chunks (head, mid-ish, further) to get diverse sample
                break
        probe = pd.concat(probe_chunks, ignore_index=True)
    except Exception:
        probe = pd.read_csv(ohlc_csv, nrows=5000, dtype=str)

    best_col = None
    best_score = 0
    for c in probe.columns:
        vals = probe[c].dropna().astype(str).str.strip()
        if vals.empty:
            continue
        score = vals.nunique() * (1.0 / (max(1.0, vals.str.len().mean())))
        if score > best_score:
            best_score = score
            best_col = c
    if best_col is None:
        raise RuntimeError('No symbol column found or inferred in OHLC CSV')

    uniq = collect_unique_for_column(best_col, max_chunks=20)
    print('Detected symbol column for scanning (heuristic):', best_col)
    print(f"[debug] tested heuristic column '{best_col}': unique_symbols={len(uniq)}")
    return uniq, best_col


def build_actionable_from_signals(signals_df, symbol):
    # minimal actionable format expected by the backtest script
    if signals_df is None or len(signals_df) == 0:
        return None
    actionable = signals_df.copy()
    # ensure numeric columns
    for c in ('entry','stop_loss','take_profit','position_size','confidence'):
        if c in actionable.columns:
            actionable[c] = pd.to_numeric(actionable[c], errors='coerce')
    actionable['trading_symbol'] = symbol
    # produce position_size_int if possible
    if 'position_size' in actionable.columns:
        actionable['position_size_int'] = actionable['position_size'].apply(lambda x: int(x) if pd.notna(x) else None)
    else:
        actionable['position_size_int'] = None
    # try to ensure signal_time column exists
    if 'signal_time' not in actionable.columns and 'signal_time_ist' in actionable.columns:
        actionable['signal_time'] = actionable['signal_time_ist']
    return actionable


def call_backtest_for_actionable(actionable_df, ohlc_csv, outputs_root, account_size, risk_perc, dedupe_policy, min_position_size, tolerance_seconds, debug=False):
    # save actionable to a temp file
    if actionable_df is None or len(actionable_df) == 0:
        return None
    os.makedirs(outputs_root, exist_ok=True)
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix='.csv', prefix='actionable_')
    tmp_path = tmp.name
    tmp.close()
    actionable_df.to_csv(tmp_path, index=False)

    # import the backtest script as module and call run_backtest
    backtest_path = os.path.abspath(os.path.join(os.path.dirname(__file__), 'backtest_from_actionable.py'))
    mod = runpy.run_path(backtest_path)
    run_backtest = mod.get('run_backtest')
    if run_backtest is None:
        raise RuntimeError('Unable to find run_backtest in backtest_from_actionable.py')

    # prepare per-symbol outputs directory
    # run_backtest will write backtest_results_from_actionable.csv into outputs_root
    run_backtest(actionable_csv=tmp_path, ohlc_csv=ohlc_csv, outputs_dir=outputs_root, account_size=account_size,
                 risk_perc=risk_perc, commission_per_trade=0.0, slippage_pct=0.0, lookahead_bars=None,
                 dedupe_policy=dedupe_policy, min_position_size=min_position_size, tolerance_seconds=tolerance_seconds,
                 symbol_override=None, debug=debug, allow_no_symbol=True)

    # read produced results if any
    res_path = os.path.join(outputs_root, 'backtest_results_from_actionable.csv')
    if not os.path.exists(res_path):
        return None
    try:
        res_df = pd.read_csv(res_path)
    except Exception:
        return None
    return res_df


def summarize_backtest_df(res_df, account_size):
    if res_df is None or len(res_df) == 0:
        return {'num_trades': 0, 'total_net_pnl': 0.0, 'gross_pnl': 0.0, 'wins': 0, 'win_rate': 0.0, 'avg_net': 0.0, 'return_pct': 0.0}
    total_net = float(res_df['net_pnl'].sum())
    total_gross = float(res_df['gross_pnl'].sum())
    num_trades = len(res_df)
    wins = (res_df['net_pnl'] > 0).sum()
    win_rate = float(wins) / num_trades if num_trades > 0 else 0.0
    avg_net = float(res_df['net_pnl'].mean())
    ret_pct = (total_net / float(account_size)) * 100.0
    return {'num_trades': int(num_trades), 'total_net_pnl': float(total_net), 'gross_pnl': float(total_gross), 'wins': int(wins), 'win_rate': float(win_rate), 'avg_net': float(avg_net), 'return_pct': float(ret_pct)}


def main():
    parser = argparse.ArgumentParser(description='Scan universe of symbols to find best Elliott-wave performers')
    parser.add_argument('--ohlc', help='path to OHLC multi-symbol CSV', default=os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'historical_candles_latest.csv')))
    parser.add_argument('--universe', help='optional CSV file with one symbol per line (column header symbol)')
    parser.add_argument('--top-n', type=int, default=50, help='return top-N symbols by score')
    parser.add_argument('--max-symbols', type=int, default=200, help='limit number of symbols to scan')
    parser.add_argument('--account-size', type=float, default=10000.0)
    parser.add_argument('--risk-perc', type=float, default=5.0)
    parser.add_argument('--dedupe-policy', choices=['first','last','avg','offset'], default='first')
    parser.add_argument('--min-position-size', type=int, default=1)
    parser.add_argument('--tolerance-seconds', type=int, default=30)
    parser.add_argument('--debug', action='store_true')
    args = parser.parse_args()

    ohlc_csv = args.ohlc
    # robustly search for the OHLC CSV in a few likely locations relative to this script and the workspace
    if not ohlc_csv or not os.path.exists(ohlc_csv):
        candidates = [
            ohlc_csv,
            os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'historical_candles_latest.csv')),
            os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'historical_candles_latest.csv')),
            os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'historical_candles_latest.csv')),
            os.path.abspath(os.path.join(os.getcwd(), 'historical_candles_latest.csv')),
            os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'historical_candles_latest.csv')),
            'historical_candles_latest.csv'
        ]
        found = None
        for p in candidates:
            try:
                if p and os.path.exists(p):
                    found = p
                    break
            except Exception:
                continue
        if found:
            ohlc_csv = found
            print('Using OHLC CSV:', ohlc_csv)
        else:
            raise RuntimeError('OHLC CSV not found: %s' % args.ohlc)

    # determine symbols to scan
    if args.universe and os.path.exists(args.universe):
        uni_df = pd.read_csv(args.universe, dtype=str)
        if 'symbol' in uni_df.columns:
            symbols = list(uni_df['symbol'].dropna().astype(str).str.strip().unique())
        else:
            # assume single column file
            symbols = list(uni_df.iloc[:,0].dropna().astype(str).str.strip().unique())
    else:
        symbols, symbol_col = discover_symbols_from_ohlc(ohlc_csv)

    # limit universe
    symbols = symbols[:args.max_symbols]
    print(f'Will scan {len(symbols)} symbols (max {args.max_symbols}).')

    indicator = ElliottWaveIndicator()

    summary_rows = []
    outputs_base = os.path.abspath(os.path.join(os.path.dirname(__file__), 'outputs', 'scan'))
    os.makedirs(outputs_base, exist_ok=True)

    for i, sym in enumerate(symbols, start=1):
        print(f'[{i}/{len(symbols)}] Scanning {sym} ...')
        try:
            # Load per-symbol OHLC (loader will filter by symbol and date ranges if provided)
            try:
                # load an adequate slice for faster processing; here we load all for simplicity
                ohlc_sym = load_ohlc_data(ohlc_csv, asset_symbol=sym)
            except Exception:
                # fallback: try to read with pandas and filter
                df_all = pd.read_csv(ohlc_csv, dtype=str)
                cand_cols = [c for c in df_all.columns if c.lower() in ('trading_symbol','asset_symbol','symbol','tradingsymbol','ticker')]
                if cand_cols:
                    df_sym = df_all[df_all[cand_cols[0]].astype(str).str.strip().str.lower() == str(sym).strip().lower()]
                    # attempt to parse datetime index
                    dt_col = next((c for c in df_sym.columns if c.lower() in ('datetime','date','timestamp','time')), None)
                    if dt_col:
                        df_sym[dt_col] = pd.to_datetime(df_sym[dt_col], errors='coerce')
                        df_sym = df_sym.set_index(dt_col)
                    ohlc_sym = df_sym
                else:
                    print(f'  Skipping {sym}: unable to filter OHLC for symbol')
                    continue

            if ohlc_sym is None or len(ohlc_sym) == 0:
                print(f'  No OHLC rows for {sym}; skipping')
                continue

            # compute waves and signals
            try:
                waves = indicator.calculate_waves(ohlc_sym, ohlc_sym['volume'] if 'volume' in ohlc_sym.columns else None)
                signals = indicator.generate_signals(ohlc_sym, waves, risk_perc=args.risk_perc, account_size=args.account_size)
            except Exception as e:
                print(f'  Failed to generate signals for {sym}:', e)
                continue

            actionable = build_actionable_from_signals(signals, sym)
            if actionable is None or len(actionable) == 0:
                print(f'  No actionable signals for {sym}; skipping')
                continue

            # per-symbol outputs directory
            sym_out = os.path.join(outputs_base, sym)
            if os.path.exists(sym_out):
                # clear old outputs to avoid mixing
                try:
                    for f in os.listdir(sym_out):
                        os.remove(os.path.join(sym_out, f))
                except Exception:
                    pass
            os.makedirs(sym_out, exist_ok=True)

            res_df = call_backtest_for_actionable(actionable, ohlc_csv, sym_out, args.account_size, args.risk_perc, args.dedupe_policy, args.min_position_size, args.tolerance_seconds, debug=args.debug)
            stats = summarize_backtest_df(res_df, args.account_size)
            stats['symbol'] = sym
            stats['scanned_rows'] = len(ohlc_sym)
            summary_rows.append(stats)
            print(f"  {sym} -> trades={stats['num_trades']}, net_pnl={stats['total_net_pnl']:.2f}, win_rate={stats['win_rate']:.2f}")

        except Exception as e:
            print(f'  Exception scanning {sym}:', e)
            continue

    # aggregate and save summary
    summary_df = pd.DataFrame(summary_rows)
    if summary_df is None or len(summary_df) == 0:
        print('No symbols produced backtest results.')
        return

    # compute score (simple: sort by total_net_pnl). You can customize weighting here.
    summary_df = summary_df.sort_values(by='total_net_pnl', ascending=False).reset_index(drop=True)
    out_path = os.path.join(outputs_base, 'scan_summary.csv')
    summary_df.to_csv(out_path, index=False)
    print('Saved scan summary ->', out_path)
    print('\nTop results:')
    print(summary_df.head(args.top_n).to_string(index=False))


if __name__ == '__main__':
    main()
